#!/usr/bin/env node
/* Local calculator and fixed interactive report. No model/network calls. */
const fs=require('node:fs');
const {render,cvss}=require('./lib/render.cjs');
const args=process.argv.slice(2),command=args.shift();
try{
  if(command==='score'){
    if(args.length!==1)throw Error('Usage: node cvss.cjs score "CVSS:4.0/..."');
    console.log(JSON.stringify(cvss.score(args[0]),null,2));
  }else if(command==='catalog'){
    const group=args[0];if(group&&!['base','threat','environmental','supplemental'].includes(group))throw Error('Unknown metric group');
    console.log(JSON.stringify(cvss.catalog.filter(m=>!group||m.group===group),null,2));
  }else if(command==='render'){
    const input=args.shift();let output,language='en';
    while(args.length){const flag=args.shift();if(flag==='--output')output=args.shift();else if(flag==='--language')language=args.shift();else throw Error('Unknown option '+flag);}
    if(!input||!output)throw Error('Usage: node cvss.cjs render assessment.json --output report.html --language en|zh-CN');
    const bytes=fs.readFileSync(input);if(bytes.length>300000)throw Error('Assessment input exceeds 300 KB');
    console.log(JSON.stringify(render(JSON.parse(bytes.toString('utf8')),output,language),null,2));
  }else throw Error('Commands: score <vector>; catalog [base|threat|environmental|supplemental]; render <assessment.json> --output <report.html> --language <en|zh-CN>');
}catch(error){console.error(JSON.stringify({error:error.message}));process.exitCode=1;}
