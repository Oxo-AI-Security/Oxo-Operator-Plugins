function mountCVSS(root,payload,cvss){
  'use strict';
  if(!root)return;
  const words=payload.words,initial={...payload.assessment.metrics};
  const selects=Array.from(root.querySelectorAll('select[data-metric]'));
  const element=name=>root.querySelector('[data-role="'+name+'"]');
  const state={...initial};
  const number=value=>value===null?'—':value.toFixed(1);
  function update(){
    const result=cvss.score(state);
    const changed=cvss.order.filter(k=>state[k]!==initial[k]);
    root.dataset.severity=result.severity;
    element('score').textContent=number(result.score);
    element('severity').textContent=words[result.severity]||words.missing;
    element('nomenclature').textContent=result.nomenclature;
    element('base-score').textContent=number(result.base_score);
    element('vector').value=result.vector||words.emptyVector;
    element('meter').style.width=(result.score===null?0:result.score*10)+'%';
    element('status').textContent=changed.length?words.edited+' · '+changed.length+' '+words.changed:payload.assessment.provisional?words.provisional:words.reviewed;
    element('missing').textContent=result.missing.length?words.missingNote+' '+result.missing.join(', '):'';
    element('missing').hidden=!result.missing.length;
    element('copy').disabled=result.vector===null;
    for(const select of selects){const edited=state[select.dataset.metric]!==initial[select.dataset.metric];select.closest('.cvss-metric').querySelector('[data-change]').hidden=!edited;}
    element('notice').textContent=words.interactive;
    element('feedback').textContent='';
    root.dataset.ready='true';
    return result;
  }
  try{
    update();
    for(const select of selects){select.disabled=false;select.addEventListener('change',()=>{
      state[select.dataset.metric]=select.value===''?null:select.value;
      try{update();}catch(error){element('notice').textContent=words.error;root.dataset.ready='error';}
    });}
    element('reset').disabled=false;
    element('reset').addEventListener('click',()=>{
      Object.assign(state,initial);for(const select of selects)select.value=state[select.dataset.metric]===null?'':state[select.dataset.metric];update();
    });
    element('copy').addEventListener('click',async()=>{
      const result=cvss.score(state);if(!result.vector)return;
      try{if(!globalThis.navigator?.clipboard?.writeText)throw Error('Unavailable');await navigator.clipboard.writeText(result.vector);element('feedback').textContent=words.copied;}
      catch(error){element('feedback').textContent=words.copyFailed;element('vector').focus();element('vector').select();}
    });
  }catch(error){element('notice').textContent=words.disabled;}
}
