const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const ROOT=path.resolve(__dirname,'..'),reference=require('../lib/reference.cjs'),catalog=require('../lib/catalog.json');
const cvss=require('../lib/core.cjs')(reference,catalog);
const HIGH='CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N';
const examples=[
 ['Local precondition', 'CVSS:4.0/AV:L/AC:L/AT:P/PR:L/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N',7.3],
 ['Network user passive','CVSS:4.0/AV:N/AC:L/AT:P/PR:N/UI:P/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N',7.7],
 ['Active interaction subsequent impact','CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:A/VC:N/VI:N/VA:N/SC:L/SI:L/SA:N',5.1],
 ['Subsequent confidentiality/integrity','CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:N/VI:N/VA:N/SC:L/SI:L/SA:N',6.9],
 ['High Base',HIGH,9.3],
 ['Availability Base','CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:N/VI:N/VA:H/SC:N/SI:N/SA:L',8.7],
 ['Availability Threat','CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:N/VI:N/VA:H/SC:N/SI:N/SA:L/E:U',6.6],
 ['Environmental interaction','CVSS:4.0/AV:L/AC:L/AT:N/PR:N/UI:P/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N/E:U/MUI:A',5.7],
 ['Requirements and Threat','CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:N/VI:N/VA:N/SC:N/SI:L/SA:N/E:U/CR:L/IR:L/AR:L',2.7]
];
for(const [name,vector,expected] of examples)test('FIRST example: '+name,()=>assert.equal(cvss.score(vector).score,expected));
test('All 32 metrics have exactly the upstream allowed values',()=>{
 assert.equal(catalog.length,32);for(const m of catalog)assert.deepEqual(m.options.map(o=>o.value),reference.order[m.key]);
});
test('Zero impact is zero and missing Base produces no score',()=>{
 const metrics=cvss.parse(HIGH);for(const key of ['VC','VI','VA','SC','SI','SA'])metrics[key]='N';assert.equal(cvss.score(metrics).score,0);
 delete metrics.AV;const result=cvss.score(metrics);assert.equal(result.score,null);assert.equal(result.vector,null);assert.deepEqual(result.missing,['AV']);
});
test('Optional X defaults, groups and Safety are distinct',()=>{
 assert.equal(cvss.score(HIGH).nomenclature,'CVSS-B');assert.equal(cvss.score(HIGH+'/E:A').nomenclature,'CVSS-BT');
 assert.equal(cvss.score(HIGH+'/CR:H').nomenclature,'CVSS-BE');assert.equal(cvss.score(HIGH+'/E:P/MSI:S').nomenclature,'CVSS-BTE');
 assert.equal(cvss.score(HIGH+'/E:X/CR:X').score,cvss.score(HIGH).score);
 for(const m of catalog.filter(m=>m.group==='supplemental'))for(const o of m.options){const metrics=cvss.parse(HIGH);metrics[m.key]=o.value;assert.equal(cvss.score(metrics).score,9.3);assert.equal(cvss.score(metrics).nomenclature,'CVSS-B');}
 assert.throws(()=>cvss.score({...cvss.parse(HIGH),MSC:'S'}));
});
test('Malformed vectors and metric values are rejected rather than guessed',()=>{
 for(const vector of [HIGH+'/E:A/E:X',HIGH.replace('AV:N/AC:L','AC:L/AV:N'),HIGH.replace('/VA:H',''),HIGH.replace('AV:N','AV:F'),HIGH.replace('CVSS:4.0','CVSS:3.1'),HIGH+'/S:P/E:U'])assert.throws(()=>cvss.parse(vector));
 assert.throws(()=>cvss.normalize({AV:'X'}));assert.throws(()=>cvss.normalize({AV:1}));assert.throws(()=>cvss.normalize({BAD:'N'}));
});
test('Evidence, assumptions and unknowns remain separate',()=>{
 const a={schema_version:'cvss-assessment-v1',title:'Test fixture',description:'Facts from a supplied vector.',metrics:cvss.parse(HIGH),reasoning:{}};
 for(const key of cvss.base)a.reasoning[key]={basis:'provided',reason:'User supplied this value.',evidence:[]};
 assert.equal(cvss.assessment(a).provisional,false);
 a.reasoning.AV={basis:'assumption',reason:'Assume network reachability pending confirmation.',evidence:[]};assert.equal(cvss.assessment(a).provisional,true);
 a.metrics.AV=null;a.reasoning.AV={basis:'unknown',reason:'Reachability not stated.',evidence:[]};assert.equal(cvss.assessment(a).result.score,null);
 a.metrics.AV='N';assert.throws(()=>cvss.assessment(a));
 a.reasoning.AV={basis:'evidence',reason:'Claim',evidence:['Invented quotation']};assert.throws(()=>cvss.assessment(a));
 a.reasoning.AV.evidence=['Facts'];assert.equal(cvss.assessment(a).result.score,9.3);
 assert.throws(()=>cvss.assessment({...a,score:10}));
});
test('Vendored source bytes match the pinned upstream manifest',()=>{
 const provenance=require('../vendor/provenance.json');for(const file of provenance.files)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,'vendor/first',file.path))).digest('hex'),file.sha256);
});
test('Scoped wrapper equals original reference on 2500 seeded full-group selections',()=>{
 const raw={};vm.createContext(raw);for(const name of ['metrics.js','cvss_lookup.js','max_composed.js','max_severity.js','cvss_score.js'])vm.runInContext(fs.readFileSync(path.join(ROOT,'vendor/first',name),'utf8'),raw);
 let seed=1729;function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed;}
 for(let i=0;i<2500;i++){
   const metrics=Object.fromEntries(Object.entries(reference.order).map(([k,values])=>[k,values[random()%values.length]]));
   const expected=raw.cvss_score({...metrics},raw.cvssLookup_global,raw.maxSeverity,raw.macroVector(metrics));
   assert.equal(cvss.score(metrics).score,expected,'case '+i);
 }
});
test('Browser reference wrapper does not leak calculation variables',()=>{
 const context={};vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(ROOT,'lib/reference.cjs'),'utf8'),context);
 const keys=Object.keys(context).sort();context.CVSSReference.calculate(cvss.parse(HIGH));context.CVSSReference.calculate(cvss.parse(examples[0][1]));assert.deepEqual(Object.keys(context).sort(),keys);assert.deepEqual(keys,['CVSSReference']);
});
