# Third-party notices

The calculator, metric definitions and tables are derived from the FIRST CVSS v4.0 reference implementation, copyright FIRST.ORG, Inc., Red Hat, and contributors, under the BSD-2-Clause license.

The complete license is retained at `vendor/first/LICENSE`, shown in generated reports, and included unchanged in the package. Source repository, immutable commit and source-file hashes are recorded in `vendor/provenance.json`. The original source files are retained byte for byte in `vendor/first/`; `lib/reference.cjs` scopes their otherwise implicit variables without replacing scoring arithmetic. `lib/catalog.json` derives English definitions from the pinned configuration and adds local Chinese display summaries.

CVSS is a FIRST standard. No FIRST endorsement is claimed.
