# CVSS Assistant

Local CVSS 4.0 assessment and an editable calculator. The host AI proposes metrics and explains evidence or assumptions; a pinned FIRST reference implementation computes all numeric scores. Users can change all 32 metrics and see the score and vector update, while retaining the original AI selections and rationale.

Supports CVSS-B, BT, BE and BTE. Supplemental metrics supply context without changing the numeric score. Missing Base metrics produce no score; assumptions mark the assessment provisional. Reports are generated in the conversation language, with native response HTML first and standalone interactive HTML as fallback. If scripts are blocked, the initial report remains readable and controls stay disabled.

Requires an existing Node.js runtime and has no npm runtime dependencies. No server, MCP runtime, target execution, vulnerability exploitation or additional model API calls. The host itself supplies the AI assessment in its normal conversation.

Use `skills/cvss-assess/SKILL.md` for assessment and delivery, or `node cvss.cjs score "CVSS:4.0/..."` for deterministic vector calculation. Upstream source, license and provenance are bundled under `vendor/`. The generated scope wrapper isolates upstream implicit variables without modifying its scoring arithmetic. Engine/DOM tests are evidence about calculations and event handlers, not proof of the host's actual inline rendering.

Publisher: Quinn Zhang. This plugin is not endorsed by FIRST.

## Oxo distribution

Version 0.1.1-oxo.1 is offered as a Pro Security plugin through the same pinned, on-demand remote package source as the other Oxo Security plugins. Use an existing trusted Node.js runtime. Scoring and report interaction have no npm runtime dependencies or additional model/service calls. Write reports in the task workspace and link the absolute self-contained `.standalone.html` path in the answer for Oxo's isolated inline preview and original-file fallback. The original 0.1.0 calculator, FIRST vendor files and report template remain byte-for-byte unchanged.
