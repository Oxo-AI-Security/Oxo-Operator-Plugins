# CVSS Assistant

- The host AI selects metrics and states evidence/assumptions; only the pinned FIRST CVSS 4.0 calculator computes numeric scores. Do not implement a different approximation.
- Support every Base, Threat, Environmental and Supplemental metric. Supplemental metrics do not change the numeric score. Distinguish CVSS-B, BT, BE and BTE.
- Missing required Base metrics produce no score. Base metrics have no hidden defaults. If an AI selection relies on assumptions, visibly mark the initial assessment as provisional.
- Preserve the AI's original assessment separately from current user edits. Changes immediately update current score/vector; reset restores AI selections. Never present user edits as new AI reasoning.
- Fixed, versioned HTML template with local scoring and no external scripts, assets, APIs, MCP runtime or listening server. Output in conversation language, default inline first and standalone HTML fallback. No Markdown report by default.
- If script execution is disabled, the initial report and all evidence remain readable, controls are disabled, and the standalone interactive HTML is linked.
- Publisher: Quinn Zhang. English listing; purple/white branding. Preserve upstream BSD-2-Clause notices and source provenance.
