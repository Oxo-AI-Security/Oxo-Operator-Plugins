# Metric selection guide

Authoritative sources: [FIRST specification](https://www.first.org/cvss/v4.0/specification-document), [FIRST user guide](https://www.first.org/cvss/v4.0/user-guide), and bundled `catalog` output derived from the pinned FIRST calculator. These summaries guide selection; the bundled implementation computes scores.

| Base metric | Allowed values | Assess |
| --- | --- | --- |
| AV | N, A, L, P | Network, adjacent topology, local access, or physical access required to reach the vulnerability. |
| AC | L, H | Whether security-enhancing mechanisms must be circumvented; not simply whether the exploit is difficult to write. |
| AT | N, P | Deployment/execution preconditions such as races or an on-path position. Distinct from AC. |
| PR | N, L, H | Attacker privileges required before exploitation. Account self-provisioning and the vulnerability's own privilege gains require careful standard-specific treatment. |
| UI | N, P, A | Participation by another user: none, passive, active. Do not transfer CVSS 3.x UI:R blindly. |
| VC / VI / VA | H, L, N | Confidentiality, integrity and availability of the vulnerable system. |
| SC / SI / SA | H, L, N | Separate impacts on a subsequent system beyond the vulnerable system. Do not assume all are High for every code-execution issue. |

Optional groups:

- Threat: E = X/A/P/U. Distinguish actual attacks, public proof of concept and unreported exploitation. Absence of a report is not evidence that exploitation is impossible.
- Environmental: CR/IR/AR = X/H/M/L, plus MAV/MAC/MAT/MPR/MUI/MVC/MVI/MVA/MSC/MSI/MSA. Modified metrics inherit their Base counterpart at X. MSI/MSA additionally permit Safety (S); MSC does not. Use the consumer's actual environment rather than inventing one.
- Supplemental: S, AU, R, V, RE, U. No numeric score changes. Supplemental Safety (S:P) and Environmental MSI:S/MSA:S are distinct.

Show CVSS-B, CVSS-BT, CVSS-BE or CVSS-BTE according to explicitly selected Threat/Environmental groups. The official default handling for optional X values remains part of the calculation. CVSS communicates severity; organizational risk also depends on asset importance, exposure and remediation context.
