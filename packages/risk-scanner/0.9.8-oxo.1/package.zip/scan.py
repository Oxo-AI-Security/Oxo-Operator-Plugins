"""Local CLI used by the installed skill. No network and no scanned-code execution."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

# Installed package bytes stay immutable; Python caches must not change their integrity pin.
sys.dont_write_bytecode = True

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
from risk_plugin.io import read,write,sha

def pending(run_dir):
    return [p for p in sorted((run_dir/'requests').glob('*.json'),key=lambda p:p.stat().st_mtime_ns)
            if not (run_dir/'responses'/p.name).exists()]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='command',required=True)
    start=commands.add_parser('start')
    start.add_argument('kind',choices=['skill','mcp','plugin'])
    start.add_argument('path')
    start.add_argument('--output',required=True)
    worker=commands.add_parser('_worker')
    worker.add_argument('run_dir')
    for name in ['next','status','render']:
        command=commands.add_parser(name)
        command.add_argument('run_dir')
        if name=='next': command.add_argument('--all',action='store_true')
        if name=='render':
            command.add_argument('--output',required=True)
            command.add_argument('--language',choices=['auto','zh-CN','en'],default='auto')
            command.add_argument('--presentation',choices=['auto','inline','markdown','standalone'],default='auto')
            command.add_argument('--description-file', type=Path, help='UTF-8 description of the reviewed target, under 300 characters')
    respond=commands.add_parser('respond')
    respond.add_argument('run_dir')
    respond.add_argument('request_id')
    respond.add_argument('answer_file')
    args=parser.parse_args()
    if args.command=='start':
        source=Path(args.path).resolve(strict=True)
        if not source.is_file() or source.stat().st_size>8_000_000:
            raise ValueError('Input must be a file of at most 8 MB')
        run_dir=Path(args.output).resolve()/('scan-'+uuid.uuid4().hex[:12])
        run_dir.mkdir(parents=True)
        (run_dir/'requests').mkdir()
        (run_dir/'responses').mkdir()
        # Freeze selected input once; later edits cannot change this run.
        frozen=run_dir/source.name
        frozen.write_bytes(source.read_bytes())
        write(run_dir/'input.json',{'kind':args.kind,'path':str(frozen),'source_path':str(source),
                                  'input_sha256':__import__('hashlib').sha256(frozen.read_bytes()).hexdigest()})
        with (run_dir/'worker.log').open('wb') as log:
            process=subprocess.Popen([sys.executable,'-X','utf8',str(Path(__file__).resolve()),'_worker',str(run_dir)],
                                     stdout=log,stderr=subprocess.STDOUT,
                                     creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        write(run_dir/'process.json',{'pid':process.pid,'python':sys.executable,'plugin_root':str(ROOT)})
        print(json.dumps({'run_dir':str(run_dir),'pid':process.pid,'model_calls_by_plugin':0}))
        return
    run_dir=Path(args.run_dir).resolve(strict=True)
    if args.command=='_worker':
        from risk_plugin.worker import main as work
        work(run_dir)
    elif args.command=='next':
        requests=pending(run_dir)
        selected=requests if args.all else requests[:1]
        print(json.dumps({'pending_count':len(requests),'requests':[read(p) for p in selected]},ensure_ascii=False,indent=2))
    elif args.command=='respond':
        if not args.request_id.isalnum(): raise ValueError('Invalid request identity')
        request=read(run_dir/'requests'/(args.request_id+'.json'))
        target=run_dir/'responses'/(args.request_id+'.json')
        if target.exists(): raise ValueError('Answer already submitted; replacement is forbidden')
        answer=read(args.answer_file)
        envelope={'request_sha256':request['request_sha256'],'response':answer,
                  'answer_sha256':sha(answer),'source':'calling-host-session'}
        # Publish complete bytes atomically and exclusively. A worker must not
        # observe a half-written large host answer; hard-link creation refuses
        # an existing identity on Windows and POSIX alike.
        temporary=target.with_name(target.name+'.submission-'+uuid.uuid4().hex)
        with temporary.open('x',encoding='utf-8') as stream:
            json.dump(envelope,stream,ensure_ascii=False,indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary,target)
        finally:
            temporary.unlink()
        print(json.dumps({'submitted':args.request_id,'answer_sha256':sha(answer)}))
    elif args.command=='status':
        print(json.dumps(read(run_dir/'result.json') if (run_dir/'result.json').exists() else {'status':'starting'},ensure_ascii=False,indent=2))
    elif args.command=='render':
        from risk_plugin.report import render
        description = args.description_file.read_text(encoding='utf-8-sig') if args.description_file else None
        render([run_dir],Path(args.output),language=args.language,presentation=args.presentation,description=description)

if __name__=='__main__':
    # The local JSON protocol uses UTF-8 independently of a Windows host's
    # console code page or inherited PYTHONIOENCODING. Never drop source text.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='strict')
    legacy_commands={'start','next','respond','status','render','_worker'}
    if len(sys.argv)<2 or sys.argv[1] not in legacy_commands:
        from risk_plugin.agent_cli import main as agent_main
        try:
            agent_main(sys.argv[1:])
        except (ValueError, TypeError, KeyError, StopIteration, OSError) as error:
            print(json.dumps({'status':'invalid','error':str(error) or 'Unknown workspace unit'},ensure_ascii=False))
            raise SystemExit(2)
    else:
        main()  # Historical request/answer runs remain reproducible.
