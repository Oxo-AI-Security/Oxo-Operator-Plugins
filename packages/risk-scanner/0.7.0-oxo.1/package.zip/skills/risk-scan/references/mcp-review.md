# MCP declaration review

Input is a captured JSON-RPC tools/list response, never a live MCP connection. Use `catalog mcp` for all 38 public rules and the semantic/flow catalogs, and `schema` for the final record. Review every declared Tool, every Tool-level rule and every Server-level FLOW rule. Preserve exact Tool identities.

For each Tool, record matched/excluded/unknown decisions, actual confidence, source rationale, exclusions and review. Positive evidence is a verbatim quotation from the named original metadata field: name, description, inputSchema, outputSchema or annotations. For structured fields, use the same JSON representation exposed by the source. Do not confuse a pagination token with a credential, logging with security-control modification, authenticated private records with public content, or a dangerous noun with a dangerous action.

Record whether untrusted content enters processing and the declared data classes independently of the capability classification. The local scorer retains annotation-derived exposure checks and metadata checks; agent decisions must agree with those observed deterministic facts. Do not synthesize annotations, verified controls, runtime permissions or prior-version history.

Server FLOW requires actual named participant Tools, original evidence for every role and a concrete semantic transfer path supported by current declarations. Same-server presence is not proof of compatibility or runtime reachability. The original scorer validates prerequisites, roles, evidence and completion; an ineligible or rejected flow cannot create a floor. Unknown analysis stays unassessed.

This scan assesses current Tool declarations. Implementation flaws, CVEs, authentication at runtime and actual deployment controls require separate evidence. Do not claim those were tested.
# Interpretation

Use the common v2 assessment/report contract and fixed v5 report: show the deterministic static rule risk score/grade while keeping capabilities/exposure separate from metadata integrity concerns and validated FLOW paths. A powerful Tool declaration is not an implementation vulnerability or maliciousness verdict. Unpinned dependency requirements (META-005) remain supply-chain control concerns; other validated security paths retain their original severity. Historical arithmetic is audit history; current static scoring is in `assessment_summary.scoring`. No target connection, exploit probability or live implementation verification is implied by captured tools/list metadata.

