"""One policy source for agent references, validation and deterministic scoring."""
from .io import sha
from .assessment_policy import POLICY
from .static_scoring import describe_rule


def catalog(kind):
    if kind == 'skill':
        from backend.application.skill_scanner import public_skill_rules, BEHAVIOR_FACT_GUIDANCE
        from backend.domain.skill.profile_policy import PREREQUISITES, OPERATION_SEMANTICS
        value = public_skill_rules()
        result = {'kind': kind, 'version': value['rule_set_version'], 'rules': value['rules'],
                  'behavior_facts': BEHAVIOR_FACT_GUIDANCE, 'formula': value['effective_formula'],
                  'operational_prerequisites':PREREQUISITES, 'operation_semantics':OPERATION_SEMANTICS}
    elif kind == 'mcp':
        from backend.domain.mcp.rules import public_rules, RULE_SET_VERSION, llm_rule_catalog, llm_flow_catalog
        result = {'kind': kind, 'version': RULE_SET_VERSION, 'rules': public_rules(),
                  'semantic_catalog': llm_rule_catalog(), 'flow_catalog': llm_flow_catalog()}
    else:
        raise ValueError('Catalog kind must be skill or mcp')
    if 'formula' in result:
        result['legacy_formula'] = result['formula']
    result['formula'] = POLICY['scoring']['formula']
    result['score_type'] = 'static_rule_risk'
    result['rules'] = [{**rule,'static_scoring':describe_rule(kind,rule['id'])} for rule in result['rules']]
    result['assessment_policy'] = POLICY
    return {**result, 'policy_sha256': sha(result)}
