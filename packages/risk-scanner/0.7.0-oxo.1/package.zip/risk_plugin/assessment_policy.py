"""Versioned interpretation of validated facts, independent of source analysis.

The historical capability index remains auditable. It is not a probability or
an integrity verdict and cannot alone authorize a security blocking decision.
"""
from .static_scoring import SCORING_POLICY, calculate

CONTRACT_VERSION = 'agent-review-v2'
POLICY = {
    'version': 'assessment-context-v2',
    'scoring': SCORING_POLICY,
    'capability_and_exposure': 'Describe declared effects and reach; do not establish malicious intent or a vulnerability.',
    'skill_control_gaps': ['FLOW-004'],
    'mcp_control_gaps': ['META-005'],
    'control_gap_meaning': 'Mutable dependency/code consumption is a supply-chain control concern; mutability alone is not proof of compromise.',
    'security_paths': 'Other accepted FLOW paths retain their original severity and required evidence; coexistence is insufficient.',
    'legacy_index': 'Historical I/E addition remains comparison only; current static risk uses published rule severities without duplicate additive exposure points.',
    'security_boundaries': ['identity', 'resource_access', 'platform_security'],
    'control_boundary_definitions': {
        'identity': 'Accounts, roles, authentication identities or credentials.',
        'resource_access': 'Enforced authorization, ACLs or access scopes for principals and protected resources.',
        'platform_security': 'Host/service security controls such as audit, sandbox, firewall or execution policy.',
        'artifact_editing': 'Content formatting, form modes and editor restriction flags without an authorization boundary.',
        'none': 'No identity, resource authorization, security platform or artifact edit-control effect.',
        'unknown': 'Insufficient original-source evidence; cannot complete the controlled-resource review.',
    },
    'rule_scope_constraints': {
        'CAP-013': {'action': ['permissions'], 'control_boundary': ['identity', 'resource_access', 'platform_security']},
    },
}


def summarize(findings, legacy, *, kind, severity_decision):
    """Group accepted facts and derive disposition from the relevant evidence."""
    groups = {key: [] for key in ('capabilities', 'exposure', 'integrity', 'security_paths', 'control_gaps', 'metadata')}
    control_gaps = set(POLICY[kind + '_control_gaps'])
    for finding in findings:
        identity = finding.get('id') or finding.get('rule_id')
        family = identity.split('-')[0]
        if identity in control_gaps:
            group = 'control_gaps'
        elif family == 'CAP':
            group = 'capabilities'
        elif family == 'EXP':
            group = 'exposure'
        elif family in {'SEM', 'MAL'} or kind == 'mcp' and identity in {'META-001', 'META-002', 'META-003', 'META-004'}:
            group = 'integrity'
        elif family == 'FLOW':
            group = 'security_paths'
        else:
            group = 'metadata'
        groups[group].append(finding)

    scoring = calculate(groups, kind=kind)
    concerns = groups['integrity'] + groups['security_paths']
    if concerns:
        # CAP/EXP maxima and unrelated capabilities cannot increase this severity.
        severity = max(scoring['components'][key]['score'] for key in ('integrity','dangerous_path'))
        disposition = severity_decision(severity)
        status = 'security_concern'
        basis = concerns
    elif groups['control_gaps'] or groups['metadata']:
        severity = None
        disposition = 'Review'
        status = 'control_review'
        basis = groups['control_gaps'] + groups['metadata']
    else:
        severity = None
        disposition = 'Review' if any(f.get('id') != 'CAP-001' for f in groups['capabilities']) else 'Allow'
        status = 'capabilities_reviewed'
        basis = groups['capabilities'] + groups['exposure']

    return {
        'policy_version': POLICY['version'], 'status': status,
        'overall_risk_score': scoring['score'], 'risk_level':scoring['level'],
        'score_reason': SCORING_POLICY['meaning'], 'scoring':scoring,
        'decision': disposition, 'decision_rule_ids': sorted({f.get('id') or f['rule_id'] for f in basis}),
        'confirmed_concern_severity': severity,
        'impact': legacy.get('impact'), 'exposure': legacy.get('exposure'),
        'groups': {key: sorted({f.get('id') or f['rule_id'] for f in rows}) for key, rows in groups.items()},
        'legacy_index': {key: legacy.get(key) for key in (
            'effective_risk', 'base_risk', 'capability_floor', 'integrity_floor', 'flow_floor')},
        'malicious_intent': 'not_determined',
    }
