"""Deterministic static rule risk, distinct from deployment/likelihood estimates.

Use published rule weights once. Exposure guides operational/FLOW checks;
adding its correlated scale to CAP would count arbitrary execution twice.
"""
SCORING_POLICY = {
    'version': 'static-rule-risk-v1',
    'formula': 'max(capability, integrity, dangerous_path, control_concern, metadata)',
    'component_formula': 'maximum published rule severity in each category; no hit-count bonus',
    'weight_formula': 'max(reference_rule.score, reference_rule.floor); control concerns use the declared control-class reference',
    'exposure': 'Retained as a separate profile and FLOW prerequisite, not an additive duplicate of capability control.',
    'control_severity_basis': {'skill': {'FLOW-004': 'CAP-020'}, 'mcp': {'META-005': 'META-005'}},
    'bands': [{'minimum':0,'level':'low'}, {'minimum':40,'level':'medium'},
              {'minimum':60,'level':'high'}, {'minimum':80,'level':'critical'}],
    'meaning': 'Static review index for declared capabilities and validated concerns, not maliciousness probability or residual deployment risk.',
}


def canonical_rules(kind):
    if kind == 'skill':
        from backend.application.skill_scanner import RULE_BY_ID
    elif kind == 'mcp':
        from backend.domain.mcp.rules import RULE_BY_ID
    else:
        raise ValueError('Static scoring supports skill or mcp units')
    return RULE_BY_ID


def risk_level(score):
    if not isinstance(score, int) or isinstance(score, bool) or not 0 <= score <= 100:
        raise ValueError('Static risk score must be an integer in 0..100')
    return next(band['level'] for band in reversed(SCORING_POLICY['bands']) if score >= band['minimum'])


def describe_rule(kind, identity):
    rules = canonical_rules(kind)
    if identity not in rules:
        raise ValueError('Unknown static scoring rule identity')
    if identity.startswith('EXP-'):
        return {'role':'exposure_profile_and_flow_prerequisite','severity':None,'severity_rule_id':None}
    basis = SCORING_POLICY['control_severity_basis'][kind].get(identity, identity)
    rule = rules[basis]
    return {'role':'control_concern' if basis != identity else 'rule_severity',
            'severity':max(int(rule.get('score') or 0),int(rule.get('floor') or 0)), 'severity_rule_id':basis}


def calculate(groups, *, kind):
    rules = canonical_rules(kind)
    for rows in groups.values():
        if any((row.get('id') or row.get('rule_id')) not in rules for row in rows):
            raise ValueError('Unknown static scoring rule identity')

    def component(name):
        contributions = []
        for identity in sorted({row.get('id') or row['rule_id'] for row in groups[name]}):
            rule = describe_rule(kind, identity)
            contributions.append({'rule_id':identity,'severity_rule_id':rule['severity_rule_id'],'severity':rule['severity']})
        maximum = max((row['severity'] for row in contributions), default=0)
        return {'score':maximum,'drivers':[row['rule_id'] for row in contributions if row['severity']==maximum],
                'rules':contributions}

    components = {
        'capability':component('capabilities'), 'integrity':component('integrity'),
        'dangerous_path':component('security_paths'), 'control_concern':component('control_gaps'),
        'metadata':component('metadata'),
    }
    score = max(part['score'] for part in components.values())
    return {'policy_version':SCORING_POLICY['version'],'score':score,'level':risk_level(score),
            'formula':SCORING_POLICY['formula'],'components':components,
            'drivers':sorted({key for part in components.values() if part['score']==score for key in part['drivers']}),
            'exposure_additive_points':0,'runtime_risk':'not_assessed'}
