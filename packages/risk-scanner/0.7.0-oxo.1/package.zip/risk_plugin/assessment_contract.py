"""Final agent-authored evidence contract; it prescribes outcomes, not a loop."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

from backend.application.skill_profile_types import Operation
from backend.application.skill_authority import AuthorityDecision


class Record(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, allow_inf_nan=False)


class Review(Record):
    confidence: float = Field(ge=0, le=1)
    source_reason: str = Field(min_length=1)


class Participant(Record):
    role: str = Field(min_length=1)
    evidence_id: str = Field(min_length=1)


class Flow(Record):
    data_path: str = Field(min_length=1)
    participants: list[Participant] = Field(min_length=1)


class Decision(Record):
    status: Literal['matched', 'excluded', 'unknown']
    confidence: float = Field(ge=0, le=1)
    rationale: str = Field(min_length=1)
    exclusion_analysis: str = Field(min_length=1)
    evidence_ids: list[str]
    operation_ids: list[str]
    review: Review
    flow: Flow | None = None


class ReferenceDecision(Record):
    reference_id: str
    status: Literal['active', 'inert', 'unknown']
    confidence: float = Field(ge=0, le=1)
    rationale: str = Field(min_length=1)
    evidence_ids: list[str] = Field(min_length=1)


class ResourceAuthority(AuthorityDecision):
    control_boundary: Literal['identity', 'resource_access', 'platform_security', 'artifact_editing', 'none', 'unknown'] = Field(
        description='Boundary actually controlled by this effect. Artifact editing/formatting flags are distinct from identity, resource access and platform security policy. Cite original source and explain the scope.')


class SkillAssessment(Record):
    contract_version: Literal['agent-review-v2']
    source_sha256: str
    policy_sha256: str
    operations: list[Operation]
    authority_reviews: list[ResourceAuthority]
    decisions: dict[str, Decision]
    behavior_facts: dict[str, Decision]
    reference_decisions: list[ReferenceDecision]
    unresolved: list[str]
    limitations: list[str]


def schema(kind):
    from .catalog import catalog
    policy = catalog(kind)
    def keyed(identities, definition):
        return {'type':'object','properties':{key:{'$ref':'#/$defs/'+definition} for key in identities},
                'required':identities,'additionalProperties':False}
    if kind == 'skill':
        result = SkillAssessment.model_json_schema()
        result['properties']['decisions'] = keyed([r['id'] for r in policy['rules']], 'Decision')
        result['properties']['behavior_facts'] = keyed(list(policy['behavior_facts']), 'Decision')
        return result
    from .mcp_assessment import McpAssessment
    from backend.domain.mcp.rules import SECURITY_ISSUE_TYPES
    result = McpAssessment.model_json_schema()
    result['$defs']['ToolReview']['properties']['decisions'] = keyed([r['id'] for r in policy['rules'] if r['kind']!='flow'], 'ToolDecision')
    result['properties']['flows'] = keyed([r['id'] for r in policy['rules'] if r['kind']=='flow'], 'McpFlowDecision')
    result['$defs']['ToolDecision']['properties']['issue_type'] = {'anyOf':[{'type':'string','enum':list(SECURITY_ISSUE_TYPES)},{'type':'null'}]}
    return result
