# Risk Scanner presentation decisions

- Keep all scoring rules, evidence, completion gates and persisted scan outcomes unchanged when changing presentation.
- Ship one versioned template and structured result contract. Render data deterministically; never ask the model to redesign HTML per scan.
- Display the engine's risk level and decision explicitly. Pair semantic risk colors with text: low, medium, high and critical; incomplete/failed/partial is a separate neutral status with no risk score.
- Support Chinese and English. Prefer the user's explicit language, then conversation/host language; never infer language from nationality or location. Preserve evidence in its original language and identify untranslated source diagnostics.
- The full report must be readable and evidence expandable without JavaScript or host bridge APIs. Do not display a language switch or a top risk legend. Select report language from the user’s explicit request, then the current conversation; keep per-sample colored risk labels.
- Prefer HTML in the response using the host's available native rendering mechanism. Always generate a standalone HTML fallback; absent, unknown or failed inline support must fall back to that HTML, not Markdown. Generate and deliver Markdown only on explicit request. Do not infer unsupported inline merely because another app cannot render it, and never treat a local report as proof of inline interaction.
- No server, MCP runtime, external assets, target execution or additional model API calls for rendering. Keep diagnostics and raw fields collapsed.

- Publisher/author is Quinn Zhang. Plugin listing text is English and describes security risk review of Skills, MCP tools and plugins; do not use implementation wording as the subtitle. Branding uses purple and white.
