# Risk Scanner 0.3.3-oxo.1

Local Skills + Python scripts. No MCP server, no listening port, no external scan service and no additional model API calls. The current harness model answers the preserved engine's structured stages through local files. Target code is never executed. The worker rejects network connections, DNS resolution, listeners and subprocess launches through a Python audit hook.

The engine fork starts from `mcp-risk-console` v4.29. In 0.3.0 the Skill contract is explicitly versioned `skill-semantic-matcher-v4.30-plugin.1` / `ai-skill-risk-2026.08.10-plugin.1`: fixed tool/API identity is classified by its resource effects, while programs and caller-controlled executable input produce execution facts. Unknown executable control cannot establish purity. CAP-001's ambiguous execution exclusion is aligned with that shared contract. All rule identities, weights, score formulae and completion gates are retained. The original console source remains unchanged. The provider adapter adds an explicit host-session transport seam; no key or provider settings are needed. A host-file schema probe measures local contract acceptance, not provider-native output constraints. Stage review in one host context does not establish independent model judgments.

Inputs: Skill archives, captured MCP tools/list JSON-RPC metadata, plugin ZIP packages. Plugin manifests/hooks/dependencies/declared references are inventory-only; full package scoring and unanchored script semantics are unsupported in this version. No permission is inferred from a plugin manifest or MCP declaration.

The versioned `ui/report-v3-fragment.html` and `ui/result.schema.json` are the fixed interface. Previous templates remain historical assets. `risk_plugin/report.py` renders escaped static content and native details/summary disclosures without JavaScript. No top risk legend or language switch is displayed. The host infers language from the conversation and passes it to the renderer. Per-sample colors reflect the engine's existing risk labels; incomplete scans remain neutral and unassessed. All 96 rule titles have fixed Chinese and English display names; source quotations and raw diagnostics retain their original language.

Every render writes a native inline fragment, standalone HTML and view JSON. Delivery prefers HTML in the response using the current host's native rendering mechanism. Unknown, unsupported or failed inline rendering falls back to the standalone HTML. Markdown is exported only when explicitly requested. No HTTP server, remote asset, model call or new runtime dependency is used for presentation. Native Codex rendering is a host feature; MCP Apps is not bundled.

Use the `risk-scan` skill for the local CLI workflow. Runtime dependencies are declared in `engine/requirements.txt`; installation does not install Python packages or target dependencies.

0.1.1 hardens atomic host-answer publication and corrects the MCP result field projection and inventory-only package visibility. The scoring engine, rules, prompts, completion gates, host transport seam, and `risk-ui-v1` HTML template are byte-identical to the 0.1.0 installed-session real scans. Those scans are retained as 0.1.0 evidence; they are not relabeled as fresh 0.1.1 model runs.

0.2.0 changes presentation and skill routing only. It reuses the existing two real outcomes without rescanning. The engine remains byte-identical to 0.1.1. A user-reported inline internal error is not independently reproduced; removing required script-driven rendering narrows that failure surface, while Markdown remains a dependable fallback. Actual host-inline rendering and clicking still require separate observation.

0.3.1 updates publisher/listing metadata and the purple-and-white icon. Author: Quinn Zhang. Engine, skills, report template and scoring contracts are byte-identical to 0.3.0.

0.3.2 changes report delivery to inline HTML first, standalone HTML fallback, with Markdown only on explicit request. This supersedes the historical Markdown-first behavior described under 0.2.0. Engine, scoring and the fixed HTML template remain unchanged.


## Oxo distribution

0.3.3-oxo.1 packages the verified 0.3.2 engine for the Oxo Security catalog. It changes listing category and portable runtime/report guidance only. Engine source, scoring rules, host-file protocol and fixed report assets remain byte-identical. The package is downloaded on demand through the existing GitHub source and installed only after archive and tree checks plus the existing Pro gate. Python and Python packages are not installed by this package download. Reports stay in the task workspace and can be shown through ordinary HTML file links.
