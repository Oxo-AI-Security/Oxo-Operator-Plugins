"""Versioned deterministic MCP capability, exposure, metadata and flow rules."""

RULE_SET_VERSION = "3.4.0"
RULE_SET_OWNER = "Security Governance"
RULE_SET_DATASET = "mcp-tools-2026q3"
LLM_PROMPT_VERSION = "semantic-rule-matcher-v5.4"
FLOW_PROMPT_VERSION = "semantic-flow-matcher-v1.2"

SOURCES = {
    "mcp_tools": "https://modelcontextprotocol.io/specification/2025-11-25/server/tools",
    "mcp_security": "https://modelcontextprotocol.io/specification/2025-11-25/basic/security_best_practices",
    "nsa": "https://www.nsa.gov/Portals/75/documents/Cybersecurity/CSI_MCP_SECURITY.pdf",
    "fips199": "https://csrc.nist.gov/pubs/fips/199/final",
    "sp80030": "https://csrc.nist.gov/pubs/sp/800/30/r1/final",
    "sp80053": "https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final",
    "owasp_mcp": "https://owasp.org/www-project-mcp-top-10/",
    "owasp_agentic": "https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/",
    "mitre_atlas": "https://atlas.mitre.org/",
}

CAP_RULES = [
    {"id": "CAP-001", "title": "纯计算、格式转换、读取公开静态信息", "impact": 0, "floor": 0, "signals": ["calculate", "calculator", "format", "convert", "transform", "public metadata"], "authority": "MCP readOnlyHint；FIPS 199 低影响思想"},
    {"id": "CAP-002", "title": "搜索或读取开放互联网内容", "impact": 1, "floor": 20, "signals": ["web search", "search web", "fetch url", "crawl", "public api", "public web", "网页搜索", "公开网页"], "authority": "MCP openWorldHint；OWASP Prompt Injection"},
    {"id": "CAP-003", "title": "读取 workspace、内部文档或私有仓库", "impact": 2, "floor": 40, "signals": ["read file", "private repo", "private repository", "internal doc", "workspace", "local file", "内部文档", "私有仓库"], "authority": "NSA 数据分区；FIPS 199 机密性影响"},
    {"id": "CAP-004", "title": "读取 PII、通信记录、财务、医疗或受监管数据", "impact": 4, "floor": 65, "signals": ["pii", "personally identifiable", "email history", "direct message", "bank record", "health record", "medical", "customer data", "regulated", "通信记录", "客户数据"], "authority": "FIPS 199 confidentiality；OWASP MCP1"},
    {"id": "CAP-005", "title": "读取 credential、token、password 或 private key", "impact": 5, "floor": 85, "signals": ["secret", "credential", "api key", "api_key", "token", "password", "private key", "private_key", "vault"], "authority": "OWASP MCP1；NSA token/session security"},
    {"id": "CAP-006", "title": "创建本地文件或可逆本地状态", "impact": 2, "floor": 30, "signals": ["create file", "write file", "save draft", "write cache", "append file", "创建文件", "保存草稿"], "authority": "MCP additive/destructive annotations"},
    {"id": "CAP-007", "title": "修改共享 SaaS、仓库或数据库记录", "impact": 3, "floor": 50, "signals": ["update issue", "create issue", "edit record", "commit", "merge", "change ticket", "update record", "修改工单"], "authority": "OWASP ASI02；Snyk W019"},
    {"id": "CAP-008", "title": "覆盖、删除或破坏本地文件/设置", "impact": 4, "floor": 65, "signals": ["delete file", "remove file", "overwrite", "reset", "clean", "purge local", "删除文件"], "authority": "MCP destructiveHint；Snyk W020"},
    {"id": "CAP-009", "title": "删除共享/生产数据或大范围不可逆变更", "impact": 5, "floor": 85, "signals": ["delete repository", "delete account", "drop table", "truncate", "destroy resource", "purge tenant", "permanently delete", "删除仓库", "删除账户"], "authority": "OWASP ASI02；NSA sandbox/least privilege"},
    {"id": "CAP-010", "title": "向外部主体发送、上传、发布或公开信息", "impact": 4, "floor": 70, "signals": ["send email", "send message", "post message", "publish", "upload", "webhook", "share externally", "recipient", "发送邮件", "外发"], "authority": "MCP openWorldHint；MITRE Exfiltration；NSA DLP"},
    {"id": "CAP-011", "title": "任意 shell、PowerShell、代码、脚本或 eval 执行", "impact": 5, "floor": 90, "signals": ["command", "shell", "bash", "powershell", "exec", "eval", "script", "run code", "execute code", "run workflow", "任意命令", "代码执行"], "authority": "OWASP MCP5/ASI05；NSA Tool Parameter Injection"},
    {"id": "CAP-012", "title": "任意 SQL/query 或数据库管理", "impact": 4, "floor": 75, "signals": ["raw sql", "sql query", "execute statement", "ddl", "database admin", "database query", "数据库管理"], "authority": "NSA 参数验证；OWASP MCP5"},
    {"id": "CAP-013", "title": "修改 identity、role、ACL、scope 或安全策略", "impact": 5, "floor": 90, "signals": ["grant", "revoke", "permission", "role", "acl", "scope", "auth config", "disable control", "change policy", "修改权限"], "authority": "OWASP MCP2/ASI03；NIST AC/IA"},
    {"id": "CAP-014", "title": "支付、转账、交易、退款或法律承诺", "impact": 5, "floor": 90, "signals": ["transfer", "payment", "pay", "purchase", "trade", "refund", "sign contract", "approve contract", "转账", "支付"], "authority": "OWASP ASI02；Snyk W009/W019"},
    {"id": "CAP-015", "title": "控制已登录浏览器、桌面会话或代表用户操作 UI", "impact": 4, "floor": 75, "signals": ["browser automation", "click element", "type text", "authenticated session", "desktop control", "computer use", "控制浏览器"], "authority": "OWASP Tool Misuse；Snyk W019"},
    {"id": "CAP-016", "title": "部署或修改生产、云、网络、集群基础设施", "impact": 5, "floor": 85, "signals": ["deploy", "production config", "kubernetes", "cloud resource", "firewall", "dns", "cluster", "terraform", "生产环境"], "authority": "NSA least privilege/sandbox"},
    {"id": "CAP-017", "title": "控制物理设备、OT、车辆、机器人或健康安全系统", "impact": 5, "floor": 95, "signals": ["actuator", "robot", "vehicle", "industrial control", "medical device", "physical device", "机器人", "车辆控制"], "authority": "FIPS 199 灾难性影响；NIST AI RMF"},
    {"id": "CAP-018", "title": "执行安全攻击或双用途高危能力", "impact": 4, "floor": 80, "signals": ["exploit", "payload", "credential dump", "port scan", "phishing", "malware", "reverse shell", "漏洞利用"], "authority": "OWASP MCP5；MITRE ATLAS/ATT&CK"},
]

EXP_RULES = [
    {"id": "EXP-001", "title": "openWorldHint=true 或缺失", "effect": "Exposure 至少 3", "authority": "MCP 官方默认 true"},
    {"id": "EXP-002", "title": "idempotentHint=false 或缺失，且 Tool 有副作用", "effect": "Exposure 至少 2", "authority": "MCP 官方默认 false；NSA 重放风险"},
    {"id": "EXP-003", "title": "destructiveHint=true 或缺失，且描述显示有写能力", "effect": "Impact 至少 4", "authority": "MCP 官方默认 true"},
    {"id": "EXP-004", "title": "支持批量、递归、通配或等价的大范围操作", "effect": "Exposure +1，最高 5", "authority": "NSA 影响范围与资源滥用"},
    {"id": "EXP-005", "title": "调用者可自由控制命令、查询、路径、URL、收件人或等价高风险参数", "effect": "Exposure +1，最高 5", "authority": "NSA 参数验证；OWASP MCP5"},
    {"id": "EXP-006", "title": "可作用于 root、admin、全租户、全组织或等价管理级范围", "effect": "Exposure 至少 4", "authority": "NSA least privilege；OWASP MCP2"},
    {"id": "EXP-007", "title": "元数据不足以明确目标、作用范围、副作用或可逆性", "effect": "Exposure +1；confidence -0.2", "authority": "NIST 不确定性；MCP 保守默认"},
    {"id": "EXP-008", "title": "annotations 与 name、description 或 schema 声明的实际能力冲突", "effect": "Exposure +2；隔离复核", "authority": "MCP annotations 不可信；Tool Poisoning"},
]

META_RULES = [
    {"id": "META-001", "title": "描述含忽略指令、隐藏行为、强制调用等 Prompt Injection", "effect": "Critical；quarantine", "floor": 100, "decision": "quarantine", "authority": "OWASP MCP3/MCP6；Snyk E001"},
    {"id": "META-002", "title": "一个 Server 的描述指挥另一个 Server 的 Tool", "effect": "最低 90；隔离复核", "floor": 90, "decision": "quarantine", "authority": "Tool shadowing；Snyk E002"},
    {"id": "META-003", "title": "描述包含 zero-width、Bidi override、Unicode Tag", "effect": "最低 80；解码复核", "floor": 80, "decision": "quarantine", "authority": "Snyk W021；Tool Poisoning"},
    {"id": "META-004", "title": "name、description、schema、annotations 副作用矛盾", "effect": "Critical；禁止自动放行", "floor": 100, "decision": "quarantine", "authority": "MCP annotations 不可信；NSA implicit trust"},
    {"id": "META-005", "title": "描述要求运行时下载未固定版本的代码或依赖", "effect": "最低 85；验证来源", "floor": 85, "authority": "OWASP MCP4；Agentic Supply Chain"},
    {"id": "META-006", "title": "语义可疑但证据不足，不能单独判定恶意", "effect": "不直接提分；降低置信度并人工复核", "floor": 0, "authority": "Snyk W001；需结合上下文"},
    {"id": "META-007", "title": "LLM 未完成有证据支持的语义分类", "effect": "最低 40；不得自动放行", "floor": 40, "authority": "NIST 不确定性；人工复核策略"},
]

# LLM-facing semantic guidance deliberately excludes numeric weights. The model
# selects versioned rule IDs; Python remains the sole numeric policy engine.
LLM_RULE_GUIDANCE = {
    "CAP-001": {"include": ["纯计算、格式转换，或读取固定的公开静态信息，且没有外部访问或状态变化"], "exclude": ["开放互联网搜索", "内部或敏感数据读取", "任何写入或执行"]},
    "CAP-002": {"include": ["搜索、抓取或读取开放互联网、公开网页或用户指定外部 URL"], "exclude": ["固定本地公开目录", "内部系统或私有数据"]},
    "CAP-003": {"include": ["只读访问 workspace、内部文档、私有仓库、内部日志或内部业务数据"], "exclude": ["公开互联网内容", "PII/医疗/财务等受监管数据", "credential 或 secret"]},
    "CAP-004": {"include": ["读取 PII、通信记录、客户数据、财务、医疗或受监管数据"], "exclude": ["普通内部非敏感数据", "credential、token、password 或 private key"]},
    "CAP-005": {"include": ["读取或返回 credential、token、password、API key、private key 或 vault secret"], "exclude": ["分页 token、普通 ID 或不包含认证材料的内部数据"]},
    "CAP-006": {"include": ["创建本地文件、草稿、缓存或明确可恢复的本地状态"], "exclude": ["覆盖或删除本地对象", "修改共享 SaaS、仓库或数据库"]},
    "CAP-007": {"include": ["创建或修改共享 SaaS 工单、仓库内容或数据库业务记录"], "exclude": ["纯读取", "删除共享或生产数据", "权限和安全策略变更"]},
    "CAP-008": {"include": ["覆盖、删除或破坏本地文件、目录、设置或本地状态"], "exclude": ["创建可恢复的本地文件", "删除共享或生产数据"]},
    "CAP-009": {"include": ["删除共享 SaaS、仓库、数据库、生产资源，或执行大范围不可逆变更"], "exclude": ["删除本地临时文件", "只读或可恢复的共享更新"]},
    "CAP-010": {"include": ["向外部邮箱、收件人、频道、Webhook、公开网站或第三方地址发送、上传、发布或共享信息"], "exclude": ["仅在本地生成草稿", "仅从外部读取内容而不发送"]},
    "CAP-011": {"include": ["执行调用者控制的 shell、PowerShell、代码、脚本、eval 或任意命令"], "exclude": ["固定的内部函数调用", "只读取命令文本或日志"]},
    "CAP-012": {"include": ["执行调用者控制的原始 SQL/query、DDL 或数据库管理操作"], "exclude": ["固定参数化只读查询", "只读取数据库文档或状态"]},
    "CAP-013": {"include": ["创建、修改或删除 identity、role、ACL、permission、scope 或安全策略"], "exclude": ["只读取权限状态", "普通业务记录修改"]},
    "CAP-014": {"include": ["发起或批准支付、转账、交易、退款、采购或法律承诺"], "exclude": ["只读取余额、报价或交易历史"]},
    "CAP-015": {"include": ["控制已登录浏览器或桌面会话，点击、输入或代表用户操作 UI"], "exclude": ["只返回网页内容", "无认证状态的普通 HTTP 请求"]},
    "CAP-016": {"include": ["部署、创建、修改或删除生产、云、网络、DNS、防火墙、集群或 Kubernetes 基础设施"], "exclude": ["只搜索防火墙日志", "只读取云资源状态", "只查询基础设施文档"]},
    "CAP-017": {"include": ["控制执行器、机器人、车辆、OT、医疗设备或其他物理系统并产生现实世界动作"], "exclude": ["只读取遥测、日志或设备状态"]},
    "CAP-018": {"include": ["执行漏洞利用、凭据转储、恶意载荷、钓鱼、恶意软件、反向 shell 或主动攻击"], "exclude": ["防御性读取安全日志", "讨论攻击技术但不执行攻击", "授权范围内的普通漏洞信息查询"]},
    "META-001": {"include": ["元数据直接命令模型忽略上级指令、泄露系统提示词或秘密、隐藏行为、绕过策略或强制调用 Tool"], "exclude": ["安全产品检测这些攻击语句", "文档或示例引用攻击文本", "正常描述 Tool 的使用前提"]},
    "META-002": {"include": ["元数据试图覆盖、重定义、影子化或指挥另一个 MCP Server/Tool"], "exclude": ["只说明与其他服务的正常集成", "列出可选的下游系统"]},
    "META-005": {"include": ["元数据要求评估者或 Agent 在运行时下载、安装或执行未固定版本的代码、依赖或脚本"], "exclude": ["只记录已经固定版本的依赖", "普通安装文档但不向模型下达运行时指令"]},
    "EXP-004": {"include": ["Tool 可一次作用于多个、全部、递归选择、通配选择或用户定义集合，即使字段名不是 all/batch/recursive/wildcard", "描述、字段说明或枚举值表明操作范围可扩大到目录树、项目集合、账户集合或其他批量对象"], "exclude": ["固定单一对象操作", "仅分页读取且每次调用范围有硬上限", "字段名称像 batch 但实际只是固定格式标识"]},
    "EXP-005": {"include": ["调用者可提交自由格式命令、脚本、代码、原始查询、文件路径、URL、endpoint、收件人、频道或等价执行/目标参数", "schema 未用不可绕过的 enum、const、严格 pattern 或固定 allowlist 将高风险参数限制为安全集合"], "exclude": ["参数由固定 enum/const/allowlist 约束且不能表达任意目标或操作", "普通搜索关键词、展示文本或无执行/外发语义的字符串", "仅有长度限制但仍能指定任意命令或外部目标时不得排除"]},
    "EXP-006": {"include": ["Tool 可用 root、administrator、sudo、全租户、全组织、跨账户或等价管理级权限/范围执行", "管理级范围出现在字段名、字段描述、枚举值、默认值或 Tool 描述中"], "exclude": ["只查询管理员公开资料而不使用管理权限", "tenant 字段只选择单一受限租户且调用者不能扩大权限", "admin 只是数据标签而非权限或作用范围"]},
    "EXP-007": {"include": ["name、description 与 schema 合起来仍无法判断 Tool 作用于什么对象、范围多大、是否产生副作用或能否恢复", "描述使用模糊动作且 schema 也不能补足关键安全语义"], "exclude": ["元数据已清楚说明动作、目标、范围、状态变化和恢复/不可逆边界", "只读无副作用能力已被明确声明并由 schema 支持", "不得仅按字符长度判断"]},
    "EXP-008": {"include": ["readOnlyHint=true 但 name、description 或 schema 明确声明写入、发送、执行、修改或删除", "destructiveHint=false 但实际能力包含覆盖、删除、破坏或不可逆变更", "idempotentHint=true 但元数据明确表明重复调用会产生多次不可去重的副作用", "annotation 的其他安全语义与实际声明行为存在直接矛盾"], "exclude": ["annotations 与完整行为一致", "仅因为 annotation 缺失而不能判定冲突", "证据只是模糊或推测性的潜在实现行为", "必须同时引用 annotation 和与其冲突的 name、description 或 schema 证据"]},
}

SEMANTIC_META_RULE_IDS = ("META-001", "META-002", "META-005")
SEMANTIC_EXPOSURE_RULE_IDS = ("EXP-004", "EXP-005", "EXP-006", "EXP-007", "EXP-008")
SECURITY_ISSUE_TYPES = (
    "prompt_injection", "hidden_instruction", "forced_tool_call", "policy_bypass",
    "secret_exfiltration", "tool_shadowing", "cross_server_instruction",
    "supply_chain_instruction", "other",
)


def llm_rule_catalog() -> dict:
    """Return decision-oriented semantic rules for model classification, without scores."""
    def entry(rule: dict) -> dict:
        guidance = LLM_RULE_GUIDANCE[rule["id"]]
        return {
            "id": rule["id"],
            "definition": rule["title"],
            "decision_question": f"该 Tool 实际声明的行为是否满足：{rule['title']}？",
            "positive_conditions": guidance["include"],
            "exclusions_and_counterexamples": guidance["exclude"],
            "include_when": guidance["include"],
            "exclude_when": guidance["exclude"],
            "evidence_requirements": [
                "必须引用 name、description、inputSchema 或 annotations 中可逐字复核的原文",
                "证据必须同时支持动作、对象/数据及关键范围；只有名词或 Tool 名称不足以证明能力",
                "若 description 与 schema 冲突，应降低置信度并写入 unknowns，不得自行补全缺失语义",
            ],
            "false_positive_policy": "按完整语义判断；检测、记录、搜索、读取或引用某危险行为，不等于执行该行为。",
            "authority_context": rule["authority"],
        }

    return {
        "version": RULE_SET_VERSION,
        "capability_rules": [entry(rule) for rule in CAP_RULES],
        "exposure_rules": [entry(rule) for rule in EXP_RULES if rule["id"] in SEMANTIC_EXPOSURE_RULE_IDS],
        "metadata_security_rules": [entry(rule) for rule in META_RULES if rule["id"] in SEMANTIC_META_RULE_IDS],
        "security_issue_types": list(SECURITY_ISSUE_TYPES),
    }

FLOW_RULES = [
    {"id": "FLOW-001", "title": "私有数据 + 不可信内容 + 对外通信", "score": 100, "effect": "100；默认阻断", "authority": "MCP 官方 lethal trifecta；Snyk Toxic Flows"},
    {"id": "FLOW-002", "title": "credential/secret + 任意外发渠道", "score": 100, "effect": "100；阻断", "authority": "OWASP MCP1；NSA DLP/secret handling"},
    {"id": "FLOW-003", "title": "不可信内容 + 任意 shell/code/browser control", "score": 100, "effect": "100；默认阻断", "authority": "OWASP MCP5/MCP6；ASI05"},
    {"id": "FLOW-004", "title": "敏感数据 + batch/wildcard + 任意 recipient/URL", "score": 95, "effect": "95；强制审批", "authority": "NSA 参数验证和外发控制"},
    {"id": "FLOW-005", "title": "生产/共享基础设施写权限 + 任意命令或自由 query", "score": 100, "effect": "100；隔离执行", "authority": "NSA sandbox/least privilege"},
]

# Server-level FLOW rules need a second semantic pass over the complete Tool
# set. These definitions intentionally describe prerequisites and exclusions in
# detail, but never expose numeric policy values to the model.
FLOW_LLM_GUIDANCE = {
    "FLOW-001": {
        "security_objective": "识别同一 Server 内可形成私有数据读取、接收不可信内容并向外部发送的完整泄露链。",
        "required_facts": ["至少一个 Tool 可读取 private/internal/PII/credential 数据", "至少一个 Tool 会处理开放网络或其他不可信内容", "至少一个 Tool 可向第三方、外部地址或公开位置发送数据"],
        "include_when": ["这些能力可由同一 Agent 工作流顺序调用，且中间数据能从读取/摄取 Tool 传给外发 Tool", "可以由一个 Tool 同时承担多个角色"],
        "exclude_when": ["仅有三个关键词共存但没有可传递的数据对象", "外发 Tool 只能发送固定健康状态且不能接收前序数据", "所谓不可信内容只是安全检测对象，不会进入后续调用参数"],
        "participant_roles": ["private_data_source", "untrusted_content_source", "external_sink"],
    },
    "FLOW-002": {
        "security_objective": "识别 credential/secret 可经可控外发通道离开信任边界的路径。",
        "required_facts": ["存在读取或返回真实凭据、token、password、API key、private key 或 vault secret 的能力", "存在可接收前序内容并发送到外部目标的能力"],
        "include_when": ["外发 payload/body/message/file 等参数可承载 secret Tool 的输出", "目标可由调用者指定或属于第三方服务"],
        "exclude_when": ["token 仅表示分页游标或普通 ID", "外发内容固定且无法包含凭据", "只写入同一受控本地安全存储且不越过信任边界"],
        "participant_roles": ["secret_source", "external_sink"],
    },
    "FLOW-003": {
        "security_objective": "识别不可信内容能够影响命令、代码或已登录 UI 执行的间接提示注入/代码执行链。",
        "required_facts": ["存在来自开放网络、用户上传或第三方系统的不可信内容", "存在执行任意命令/代码或控制已登录浏览器/桌面的能力"],
        "include_when": ["不可信文本或其派生值可进入 command、script、code、URL、selector、instruction 等执行参数", "同一 Tool 读取外部内容后依据内容执行动作"],
        "exclude_when": ["外部内容仅被转义后展示或存档且不能影响执行参数", "执行 Tool 只允许固定 allowlist 动作，且元数据明确证明不存在自由输入", "仅讨论攻击技术而不执行"],
        "participant_roles": ["untrusted_content_source", "execution_sink"],
    },
    "FLOW-004": {
        "security_objective": "识别敏感数据可通过批量选择和任意目标参数被大规模外发的放大路径。",
        "required_facts": ["存在 PII、受监管数据或 secret 的读取能力", "存在 all/batch/recursive/wildcard 等批量范围", "存在自由 recipient、URL、channel、webhook 或等价目标"],
        "include_when": ["批量范围作用于敏感数据源，且结果可进入自由外发目标", "一个批处理 Tool 同时接受数据选择范围和外部目标"],
        "exclude_when": ["batch 只用于公开静态数据", "目标由固定 allowlist/enum 约束且不可任意指定", "敏感数据与批量/外发能力之间没有语义数据路径"],
        "participant_roles": ["sensitive_data_source", "bulk_selector", "arbitrary_external_sink"],
    },
    "FLOW-005": {
        "security_objective": "识别生产/共享基础设施写权限与自由命令或自由查询组合形成的高影响控制路径。",
        "required_facts": ["存在生产、云、网络、DNS、防火墙、集群或 Kubernetes 的写能力", "存在调用者可控的 command/script/code/raw query/statement"],
        "include_when": ["自由命令/查询可以直接操作基础设施，或其输出可驱动基础设施变更", "一个 Tool 同时接受自由表达式并执行生产变更"],
        "exclude_when": ["仅搜索基础设施日志或读取状态", "命令/查询只在隔离的只读模拟环境运行", "操作集合由不可绕过的 enum/allowlist 严格约束"],
        "participant_roles": ["infrastructure_write_sink", "arbitrary_execution_source"],
    },
}


def llm_flow_catalog() -> dict:
    """Return the complete Server-level semantic flow catalog, without scores."""
    return {
        "version": RULE_SET_VERSION,
        "flow_rules": [
            {
                "id": rule["id"],
                "definition": rule["title"],
                **FLOW_LLM_GUIDANCE[rule["id"]],
                "evidence_requirements": [
                    "列出参与链路的真实 Tool 名称及其角色",
                    "每个参与 Tool 至少引用一段可在该 Tool 元数据中逐字复核的原文",
                    "解释前一 Tool 的输出/数据如何语义上进入后一 Tool；仅同一 Server 共存不足以命中",
                    "若运行时可达性或数据传递无法从元数据证明，必须写入 unknowns，不得把推测当作事实",
                ],
                "authority_context": rule["authority"],
            }
            for rule in FLOW_RULES if rule["id"] in FLOW_LLM_GUIDANCE
        ],
        "deterministic_only_rules": [],
    }


def public_rules() -> list[dict]:
    result: list[dict] = []
    for rule in CAP_RULES:
        guidance = LLM_RULE_GUIDANCE[rule["id"]]
        result.append({
            "id": rule["id"], "title": rule["title"], "kind": "capability",
            "effect": f"Impact {rule['impact']}；最低 {rule['floor']}", "authority": rule["authority"],
            "meaning": f"当 Tool 的实际声明行为满足“{rule['title']}”时，记录这项固有能力；必须按完整动作、对象和范围判断，不能只看关键词。",
            "include_when": guidance["include"], "exclude_when": guidance["exclude"],
            "version": RULE_SET_VERSION, "owner": RULE_SET_OWNER,
        })
    for rule in EXP_RULES:
        result.append({
            "id": rule["id"], "title": rule["title"], "kind": "exposure",
            "effect": rule["effect"], "authority": rule["authority"],
            "meaning": f"该规则检查 Tool 的 annotations、schema 或控制声明是否满足“{rule['title']}”，用于衡量能力被误用、重复执行或扩大影响的难易程度。",
            "version": RULE_SET_VERSION, "owner": RULE_SET_OWNER,
        })
    for rule in META_RULES:
        guidance = LLM_RULE_GUIDANCE.get(rule["id"], {})
        result.append({
            "id": rule["id"], "title": rule["title"], "kind": "metadata",
            "effect": rule["effect"], "authority": rule["authority"],
            "meaning": f"该规则用于识别 MCP Tool 元数据的完整性、安全性或分类可信度问题：{rule['title']}。",
            "include_when": guidance.get("include", []), "exclude_when": guidance.get("exclude", []),
            "version": RULE_SET_VERSION, "owner": RULE_SET_OWNER,
        })
    for rule in FLOW_RULES:
        guidance = FLOW_LLM_GUIDANCE.get(rule["id"], {})
        result.append({
            "id": rule["id"], "title": rule["title"], "kind": "flow",
            "effect": rule["effect"], "authority": rule["authority"],
            "meaning": guidance.get("security_objective") or f"该规则用于识别同一 Server 内的组合能力风险：{rule['title']}。",
            "required_facts": guidance.get("required_facts", []),
            "include_when": guidance.get("include_when", []), "exclude_when": guidance.get("exclude_when", []),
            "version": RULE_SET_VERSION, "owner": RULE_SET_OWNER,
        })
    return result


RULE_BY_ID = {rule["id"]: rule for rule in CAP_RULES + EXP_RULES + META_RULES + FLOW_RULES}
