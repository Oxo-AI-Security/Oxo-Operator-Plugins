"""Deterministic, evidence-backed scoring for MCP Tool metadata.

The engine deliberately separates inherent capability risk from metadata/flow
overrides. It does not infer implementation vulnerabilities or residual risk
from a Tool description.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import datetime, timezone
from typing import Any

from ..semantic import supported_confidence, versions_match

from .rules import (
    CAP_RULES, FLOW_LLM_GUIDANCE, FLOW_PROMPT_VERSION, LLM_PROMPT_VERSION,
    RULE_BY_ID, RULE_SET_VERSION, SECURITY_ISSUE_TYPES, SEMANTIC_EXPOSURE_RULE_IDS,
    SEMANTIC_META_RULE_IDS,
)

SCORE_TYPE = "llm_rule_classified_inherent_capability_risk"
SIDE_EFFECT_CAPS = {
    "CAP-006", "CAP-007", "CAP-008", "CAP-009", "CAP-010", "CAP-011",
    "CAP-012", "CAP-013", "CAP-014", "CAP-015", "CAP-016", "CAP-017", "CAP-018",
}
WRITE_CAPS = SIDE_EFFECT_CAPS - {"CAP-018"}
PRIVATE_CAPS = {"CAP-003", "CAP-004", "CAP-005"}
SENSITIVE_CAPS = {"CAP-004", "CAP-005"}
LLM_MATCH_CONFIDENCE = 0.60

CONTROL_MAP = {
    "CAP-003": ["最小 scope", "访问审计"],
    "CAP-004": ["数据分类", "字段最小化", "目的限制", "访问审计"],
    "CAP-005": ["Secret 不进入模型上下文", "短期 token", "最小 scope", "输出脱敏"],
    "CAP-008": ["dry-run", "对象清单预览", "备份或回收站", "强制确认"],
    "CAP-009": ["dry-run", "对象清单预览", "备份恢复", "双人确认"],
    "CAP-010": ["目标 allowlist", "payload preview", "DLP", "显式确认", "不可篡改日志"],
    "CAP-011": ["sandbox", "无凭据", "只读文件系统", "网络默认拒绝", "资源限制"],
    "CAP-012": ["参数化查询", "只读凭据", "查询范围限制", "审计日志"],
    "CAP-013": ["双人审批", "短期授权", "禁止 Agent 自授予权限"],
    "CAP-014": ["强认证", "金额与对象上限", "非 Agent 最终批准", "幂等键"],
    "CAP-015": ["会话隔离", "目标预览", "动作确认", "最小权限"],
    "CAP-016": ["隔离执行", "变更计划预览", "审批", "回滚方案"],
    "CAP-017": ["物理安全联锁", "人工最终授权", "紧急停止", "隔离网络"],
    "CAP-018": ["隔离靶场", "授权范围", "网络限制", "完整审计"],
}


def _annotation(annotations: dict[str, Any], camel: str, snake: str) -> Any:
    return annotations.get(camel, annotations.get(snake))


def _hit(
    rule_id: str,
    *,
    evidence: str | None = None,
    effect: str | None = None,
    scope: str | None = None,
    source: str = "deterministic_rule_engine",
    source_detail: str | None = None,
) -> dict[str, Any]:
    rule = RULE_BY_ID[rule_id]
    if effect is None:
        effect = f"Impact {rule['impact']}；最低 {rule['floor']} 分" if rule_id.startswith("CAP-") else rule.get("effect", "")
    payload = {
        "id": rule_id,
        "title": rule["title"],
        "effect": effect,
        "authority": rule["authority"],
        "rule_set_version": RULE_SET_VERSION,
        "source": source,
    }
    if evidence:
        payload["evidence"] = evidence
    if scope:
        payload["scope"] = scope
    if source_detail:
        payload["source_detail"] = source_detail
    return payload


def _dedupe_hits(hits: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for hit in hits:
        result.setdefault(hit["id"], hit)
    return list(result.values())


def risk_band(score: int) -> tuple[int, str, str]:
    if score >= 80:
        return 5, "critical", "block"
    if score >= 60:
        return 4, "high", "restrict"
    if score >= 40:
        return 3, "medium", "confirm"
    if score >= 20:
        return 2, "low", "log"
    return 1, "informational", "allow"


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def _signal_present(text: str, signal: str) -> bool:
    if re.search(r"[\u3400-\u9fff]", signal):
        return signal in text
    return re.search(rf"(?<![a-z0-9]){re.escape(signal)}(?![a-z0-9])", text, flags=re.I) is not None


def _hidden_unicode(text: str) -> list[str]:
    found = []
    for char in text:
        category = unicodedata.category(char)
        if category in {"Cf", "Cc"} and char not in {"\n", "\r", "\t"}:
            found.append(f"U+{ord(char):04X} {unicodedata.name(char, 'UNKNOWN')}")
    return found


def _all_string_inputs_are_constrained(schema: dict[str, Any]) -> bool:
    """Return true only when every declared string input has a closed constraint."""
    string_nodes: list[dict[str, Any]] = []

    def visit(node: Any) -> None:
        if not isinstance(node, dict):
            return
        if node.get("type") == "string":
            string_nodes.append(node)
        if node.get("type") == "array":
            visit(node.get("items"))
        for child in (node.get("properties") or {}).values():
            visit(child)
        for branch in node.get("anyOf") or node.get("oneOf") or node.get("allOf") or []:
            visit(branch)

    visit(schema)
    return bool(string_nodes) and all(
        bool(node.get("enum")) or "const" in node or bool(node.get("pattern"))
        for node in string_nodes
    )


def _valid_extraction(tool: dict[str, Any], extraction: dict[str, Any] | None) -> dict[str, Any] | None:
    """Whitelist model rule IDs and retain only field-grounded exact quotations."""
    if not isinstance(extraction, dict):
        return None
    if not versions_match(extraction, LLM_PROMPT_VERSION, RULE_SET_VERSION):
        return None

    source_values = {
        "name": str(tool.get("name") or ""),
        "description": str(tool.get("description") or ""),
        "inputSchema": json.dumps(tool.get("inputSchema") or tool.get("input_schema") or {}, ensure_ascii=False),
        "outputSchema": json.dumps(tool.get("outputSchema") or tool.get("output_schema") or {}, ensure_ascii=False),
        "annotations": json.dumps(tool.get("annotations") or {}, ensure_ascii=False),
    }
    source_all = " ".join(source_values.values()).lower()

    def grounded(items: Any) -> list[dict[str, str]]:
        valid: list[dict[str, str]] = []
        if isinstance(items, (str, dict)):
            items = [items]
        if not isinstance(items, list):
            return valid
        for item in items:
            if isinstance(item, str):
                quote = item
                field = ""
            elif isinstance(item, dict):
                field, quote = str(item.get("field") or "metadata"), str(item.get("text") or "")
            else:
                continue
            quote = quote.strip()
            if len(quote) >= 2 and quote[0] == quote[-1] and quote[0] in {'"', "'", "`"}:
                quote = quote[1:-1].strip()
            if not quote.strip():
                continue
            if isinstance(item, str):
                matching_fields = [key for key, value in source_values.items() if quote.lower() in value.lower()]
                field = matching_fields[0] if matching_fields else "metadata"
            root = field.removeprefix("tool_metadata.").split(".", 1)[0]
            if root not in source_values:
                continue
            haystack = source_values[root].lower()
            if quote.lower() in haystack:
                valid.append({"field": field, "text": quote})
        return valid[:8]

    def matches(key: str, allowed_ids: set[str]) -> tuple[list[dict[str, Any]], list[str]]:
        accepted: list[dict[str, Any]] = []
        rejected: list[str] = []
        raw_items = extraction.get(key) or []
        normalized_items: list[dict[str, Any]] = []
        # Some OpenAI-compatible models emit an evidence object as the next
        # array item instead of nesting it. Recover only that narrow shape;
        # the quote must still pass exact field grounding below.
        for raw_item in raw_items if isinstance(raw_items, list) else []:
            if isinstance(raw_item, dict) and raw_item.get("rule_id"):
                normalized_items.append(dict(raw_item))
            elif isinstance(raw_item, dict) and raw_item.get("field") and raw_item.get("text") and normalized_items:
                prior = normalized_items[-1]
                existing = prior.get("evidence")
                if not isinstance(existing, list):
                    existing = []
                prior["evidence"] = [*existing, raw_item]
        for item in normalized_items:
            if not isinstance(item, dict):
                continue
            rule_id = str(item.get("rule_id") or "")
            try:
                match_confidence = float(item.get("confidence", 0))
            except (TypeError, ValueError):
                match_confidence = 0
            evidence = grounded(item.get("evidence"))
            if rule_id not in allowed_ids:
                rejected.append(f"LLM 返回了不允许的规则 ID：{rule_id or '(empty)'}")
            elif not supported_confidence(item.get("confidence")):
                rejected.append(f"{rule_id} 置信度 {match_confidence:.2f} 低于 {LLM_MATCH_CONFIDENCE:.2f}")
            elif not evidence:
                rejected.append(f"{rule_id} 没有可在对应 Tool 元数据中复核的原文证据")
            elif not str(item.get("rationale") or "").strip():
                rejected.append(f"{rule_id} 没有语义判定理由")
            else:
                accepted.append({
                    "rule_id": rule_id,
                    "confidence": round(min(1.0, max(0.0, match_confidence)), 2),
                    "rationale": str(item.get("rationale") or ""),
                    "issue_type": str(item.get("issue_type") or ""),
                    "evidence": evidence,
                })
        # One rule has one scoring effect, regardless of repeated evidence rows.
        unique = {}
        for item in accepted:
            prior = unique.get(item["rule_id"])
            if prior is None or item["confidence"] > prior["confidence"]:
                unique[item["rule_id"]] = item
        return [unique[key] for key in sorted(unique)], rejected

    cap_matches, cap_rejections = matches("capability_rule_matches", {rule["id"] for rule in CAP_RULES})
    exposure_matches, exposure_rejections = matches("exposure_rule_matches", set(SEMANTIC_EXPOSURE_RULE_IDS))
    validated_exposure_matches: list[dict[str, Any]] = []
    for item in exposure_matches:
        if item["rule_id"] == "EXP-005" and _all_string_inputs_are_constrained(
            tool.get("inputSchema") or tool.get("input_schema") or {}
        ):
            exposure_rejections.append(
                "EXP-005 被 schema 硬约束否定：所有字符串输入均由 enum、const 或 pattern 限定"
            )
            continue
        if item["rule_id"] == "EXP-008":
            roots = {proof["field"].removeprefix("tool_metadata.").split(".", 1)[0] for proof in item["evidence"]}
            if "annotations" not in roots or not roots.intersection({"name", "description", "inputSchema"}):
                exposure_rejections.append("EXP-008 必须同时引用 annotations 和与其冲突的 name、description 或 inputSchema 原文")
                continue
        validated_exposure_matches.append(item)
    security_matches, security_rejections = matches("security_rule_matches", set(SEMANTIC_META_RULE_IDS))
    raw_issue_types = extraction.get("security_issue_types") or []
    if not isinstance(raw_issue_types, list):
        raw_issue_types = [raw_issue_types]
    issue_types = [
        str(item) for item in raw_issue_types
        if str(item) in SECURITY_ISSUE_TYPES
    ]
    issue_type_rejections = [
        f"LLM 返回了不允许的 security_issue_type：{item}"
        for item in raw_issue_types if str(item) not in SECURITY_ISSUE_TYPES
    ]
    untrusted = extraction.get("untrusted_content") or {}
    if isinstance(untrusted, bool):
        untrusted = {"detected": untrusted, "confidence": 0, "evidence": []}
    untrusted_evidence = grounded(untrusted.get("evidence")) if isinstance(untrusted, dict) else []
    try:
        untrusted_confidence = float(untrusted.get("confidence", 0)) if isinstance(untrusted, dict) else 0
    except (TypeError, ValueError):
        untrusted_confidence = 0
    untrusted_detected = bool(
        isinstance(untrusted, dict) and untrusted.get("detected")
        and supported_confidence(untrusted.get("confidence")) and untrusted_evidence
    )
    untrusted_rejections = []
    if isinstance(untrusted, dict) and untrusted.get("detected") and not untrusted_detected:
        untrusted_rejections.append("LLM 报告 untrusted_content，但置信度不足或没有可逐字复核的原文证据")
    valid_data = {"public", "internal", "pii", "regulated", "financial", "health", "credential", "secret", "unknown"}
    raw_data_classes = extraction.get("data_classes") or []
    if not isinstance(raw_data_classes, list):
        raw_data_classes = [raw_data_classes]
    valid_data_classes = [str(item) for item in raw_data_classes if str(item) in valid_data]
    data_class_rejections = [
        f"LLM 返回了不允许的 data_class：{item}"
        for item in raw_data_classes if str(item) not in valid_data
    ]
    raw_unknowns = extraction.get("unknowns") or []
    if not isinstance(raw_unknowns, list):
        raw_unknowns = [raw_unknowns]
    return {
        "prompt_version": extraction.get("prompt_version"),
        "rule_set_version": extraction.get("rule_set_version"),
        "capability_rule_matches": cap_matches,
        "exposure_rule_matches": validated_exposure_matches,
        "rejected_candidates": extraction.get("rejected_candidates") if isinstance(extraction.get("rejected_candidates"), list) else [],
        "has_security_issue": bool(extraction.get("has_security_issue")),
        "security_issue_types": list(dict.fromkeys(issue_types)),
        "security_rule_matches": security_matches,
        "untrusted_content": {
            "detected": untrusted_detected,
            "confidence": round(min(1.0, max(0.0, untrusted_confidence)), 2),
            "evidence": untrusted_evidence,
        },
        "data_classes": valid_data_classes,
        "unknowns": [str(item) for item in raw_unknowns if str(item).strip()],
        "validation_rejections": cap_rejections + exposure_rejections + security_rejections + issue_type_rejections + untrusted_rejections + data_class_rejections,
    }


def _metadata_integrity(meta_ids: set[str], provenance_verified: bool) -> tuple[str, str]:
    if "META-001" in meta_ids:
        return "malicious", "检测到完整的元数据指令注入结构，必须隔离复核"
    if meta_ids & {"META-002", "META-004"}:
        return "untrusted", "元数据存在跨工具指挥或字段冲突，不能作为自动放行依据"
    if meta_ids or not provenance_verified:
        return "warning", "未发现确定恶意，但来源或元数据仍需验证"
    return "trusted", "来源已验证且未发现元数据完整性冲突"


def _controls_for(cap_ids: list[str]) -> list[str]:
    ordered: list[str] = []
    for cap_id in cap_ids:
        for control in CONTROL_MAP.get(cap_id, []):
            if control not in ordered:
                ordered.append(control)
    return ordered


def score_tool(
    tool: dict[str, Any],
    extraction: dict[str, Any] | None = None,
    *,
    provenance_verified: bool = False,
) -> dict[str, Any]:
    """Score one Tool from declared Tool metadata."""
    extraction_validation_error: str | None = None
    raw_extraction = dict(extraction) if isinstance(extraction, dict) else None
    response_meta = raw_extraction.pop("__audit", {}) if raw_extraction else {}
    try:
        extraction = _valid_extraction(tool, extraction)
    except Exception as exc:  # Model output is untrusted and must not break server scoring.
        extraction = None
        extraction_validation_error = f"LLM 返回结构无法安全解析：{type(exc).__name__}"
    name = str(tool.get("name") or "")
    description = str(tool.get("description") or "")
    schema = tool.get("inputSchema") or tool.get("input_schema") or {}
    annotations = tool.get("annotations") or {}
    matched: list[dict[str, Any]] = []
    evidence: list[dict[str, str]] = []
    unknowns: list[str] = []
    cap_ids: list[str] = []
    confidence = 1.0
    if extraction_validation_error:
        unknowns.append(extraction_validation_error)

    # Semantic CAP classification is model-primary. Raw keywords never assign a
    # capability. The model must select a versioned rule ID with grounded evidence.
    cap_matches = (extraction or {}).get("capability_rule_matches") or []
    if any(item.get("rule_id") != "CAP-001" for item in cap_matches):
        cap_matches = [item for item in cap_matches if item.get("rule_id") != "CAP-001"]
    for item in cap_matches:
        cap_id = item["rule_id"]
        if cap_id not in cap_ids:
            cap_ids.append(cap_id)
            quote = item["evidence"][0]["text"]
            matched.append(_hit(
                cap_id,
                evidence=quote,
                source="llm_semantic_match",
                source_detail="LLM 提议并通过规则 ID、置信度与原文证据校验",
            ))
            evidence.extend({
                "field": proof["field"], "text": proof["text"],
                "reason": item.get("rationale") or RULE_BY_ID[cap_id]["title"],
                "strength": "llm-grounded",
            } for proof in item["evidence"])
    match_confidences = [float(item.get("confidence", 0)) for item in cap_matches]
    if match_confidences:
        confidence = min(confidence, min(match_confidences))
    classification_status = "classified" if cap_ids else "unclassified"
    classification_source = "llm_rule_match" if cap_ids else "llm_no_supported_match" if extraction else "llm_unavailable"
    if extraction:
        unknowns.extend(extraction.get("unknowns") or [])
        unknowns.extend(extraction.get("validation_rejections") or [])
    if not cap_ids:
        confidence = min(confidence, 0.3 if extraction else 0.1)
        unknowns.append("LLM 未返回通过规则白名单、置信度和原文证据校验的 CAP；不得据此自动判低风险")

    impact = max((RULE_BY_ID[rule_id]["impact"] for rule_id in cap_ids), default=0)
    cap_floor = max((RULE_BY_ID[rule_id]["floor"] for rule_id in cap_ids), default=0)
    side_effect = any(rule_id in SIDE_EFFECT_CAPS for rule_id in cap_ids)
    write_effect = any(rule_id in WRITE_CAPS for rule_id in cap_ids)
    exposure = 0
    if any(cap in PRIVATE_CAPS for cap in cap_ids):
        exposure = max(exposure, 2)
    if "CAP-011" in cap_ids:
        exposure = 5
    elif any(cap in cap_ids for cap in {"CAP-012", "CAP-013", "CAP-014", "CAP-016", "CAP-017", "CAP-018"}):
        exposure = max(exposure, 4)

    open_world = _annotation(annotations, "openWorldHint", "open_world_hint")
    idempotent = _annotation(annotations, "idempotentHint", "idempotent_hint")
    destructive = _annotation(annotations, "destructiveHint", "destructive_hint")
    if open_world is not False:
        exposure = max(exposure, 3)
        matched.append(_hit(
            "EXP-001",
            evidence=f"openWorldHint={open_world}" if open_world is not None else "openWorldHint 缺失",
            source="mcp_annotation" if open_world is not None else "mcp_conservative_default",
            source_detail="读取 MCP annotations" if open_world is not None else "MCP 官方默认 openWorldHint=true",
        ))
        if open_world is None:
            unknowns.append("openWorldHint 缺失，按 MCP 保守默认 true 处理")
    if side_effect and idempotent is not True:
        exposure = max(exposure, 2)
        matched.append(_hit(
            "EXP-002",
            evidence=f"idempotentHint={idempotent}" if idempotent is not None else "idempotentHint 缺失",
            source="mcp_annotation" if idempotent is not None else "mcp_conservative_default",
            source_detail="副作用能力与 MCP annotations 联合判断" if idempotent is not None else "副作用能力下按 MCP 默认 idempotentHint=false",
        ))
        if idempotent is None:
            unknowns.append("有副作用但 idempotentHint 缺失")
    additive_proven = "CAP-006" in cap_ids
    if write_effect and (destructive is True or (destructive is None and not additive_proven)):
        impact = max(impact, 4)
        matched.append(_hit(
            "EXP-003",
            evidence=f"destructiveHint={destructive}" if destructive is not None else "destructiveHint 缺失且未证明仅追加/可恢复",
            source="mcp_annotation" if destructive is not None else "mcp_conservative_default",
            source_detail="写能力与 destructiveHint 联合判断",
        ))
        if destructive is None:
            unknowns.append("写能力未声明 destructiveHint，且无法证明仅追加或可恢复")

    metadata_floor = 0
    decision_override: str | None = None
    exposure_matches = (extraction or {}).get("exposure_rule_matches") or []
    exposure_ids = {item["rule_id"] for item in exposure_matches}
    # Apply absolute minima before additive modifiers. Model ordering is immaterial.
    if "EXP-006" in exposure_ids:
        exposure = max(exposure, 4)
    exposure = min(5, exposure + len(exposure_ids & {"EXP-004", "EXP-005", "EXP-007"})
                   + (2 if "EXP-008" in exposure_ids else 0))
    for item in exposure_matches:
        rule_id = item["rule_id"]
        quote = "；".join(proof["text"] for proof in item["evidence"][:3])
        matched.append(_hit(
            rule_id,
            evidence=quote,
            source="llm_semantic_exposure_match",
            source_detail="LLM 语义判断并通过规则 ID、置信度与原文证据校验",
        ))
        evidence.extend({
            "field": proof["field"], "text": proof["text"],
            "reason": item.get("rationale") or RULE_BY_ID[rule_id]["title"],
            "strength": "llm-exposure",
        } for proof in item["evidence"])
        confidence = min(confidence, float(item.get("confidence", 0)))
        if rule_id == "EXP-007":
            confidence -= 0.2
            unknowns.append("LLM 判断元数据不足以明确目标、范围、副作用或可逆性")
        if rule_id == "EXP-008":
            metadata_floor = 100
            decision_override = "quarantine"
            matched.append(_hit(
                "META-004", evidence=quote, source="llm_semantic_exposure_match",
                source_detail="LLM 以 annotations 与实际能力的双边原文证据确认冲突",
            ))
            confidence = min(confidence, 0.4)

    if not description.strip():
        unknowns.append("description 缺失")
    if not schema:
        unknowns.append("inputSchema 缺失")
    security_matches = (extraction or {}).get("security_rule_matches") or []
    for item in security_matches:
        rule_id = item["rule_id"]
        rule = RULE_BY_ID[rule_id]
        quote = item["evidence"][0]["text"]
        metadata_floor = max(metadata_floor, int(rule.get("floor", 0)))
        if rule.get("decision"):
            decision_override = str(rule["decision"])
        matched.append(_hit(
            rule_id,
            evidence=quote,
            source="llm_security_match",
            source_detail="LLM 安全语义判断并通过规则 ID、置信度与原文证据校验",
        ))
        evidence.extend({
            "field": proof["field"], "text": proof["text"],
            "reason": item.get("rationale") or rule["title"],
            "strength": "llm-security",
        } for proof in item["evidence"])

    if (extraction or {}).get("has_security_issue") and not security_matches:
        metadata_floor = max(metadata_floor, RULE_BY_ID["META-007"]["floor"])
        matched.append(_hit("META-007", evidence="LLM 报告安全问题，但规则 ID、置信度或原文证据未通过校验", source="llm_validation_fallback", source_detail="模型报告与可验证规则命中不一致，触发保守复核下限"))
        unknowns.append("LLM 报告安全问题，但没有形成可验证的 META 规则命中")
    if not cap_ids:
        metadata_floor = max(metadata_floor, RULE_BY_ID["META-007"]["floor"])
        matched.append(_hit("META-007", evidence="没有通过校验的 CAP 语义分类", source="llm_validation_fallback", source_detail="能力分类未完成，不能自动判为低风险"))
    hidden = _hidden_unicode(description)
    if hidden:
        metadata_floor = max(metadata_floor, 80)
        decision_override = "quarantine"
        matched.append(_hit("META-003", evidence=", ".join(hidden[:5]), source="structural_integrity_check", source_detail="代码直接检测隐藏 Unicode 控制字符"))
        evidence.append({"field": "tool.description", "text": ", ".join(hidden[:5]), "reason": "隐藏 Unicode 控制字符", "strength": "strong"})

    base_score = min(100, 13 * impact + 7 * exposure)
    capability_score = max(base_score, cap_floor)
    effective_score = max(capability_score, metadata_floor)
    level, risk_label, decision = risk_band(effective_score)
    if decision_override:
        decision = decision_override
    meta_ids = {hit["id"] for hit in matched if hit["id"].startswith("META-")}
    integrity, integrity_reason = _metadata_integrity(meta_ids, provenance_verified)

    residual_risk: int | str = "unknown"

    top_cap = max(cap_ids, key=lambda rule_id: (RULE_BY_ID[rule_id]["impact"], RULE_BY_ID[rule_id]["floor"])) if cap_ids else None
    exposure_rules = [hit for hit in matched if hit["id"].startswith("EXP-")]
    data_classes = list(dict.fromkeys((extraction or {}).get("data_classes") or (["secret"] if "CAP-005" in cap_ids else ["regulated"] if "CAP-004" in cap_ids else ["internal"] if any(cap in PRIVATE_CAPS for cap in cap_ids) else ["public"] if "CAP-002" in cap_ids else ["unknown"])))
    untrusted_content = bool(((extraction or {}).get("untrusted_content") or {}).get("detected")) or "CAP-002" in cap_ids
    rejected_candidates = [
        str(item.get("rule_id")) for item in (extraction or {}).get("rejected_candidates") or []
        if isinstance(item, dict) and str(item.get("rule_id") or "").startswith("CAP-")
    ]
    security_issue_types = []
    if security_matches:
        security_issue_types = list(dict.fromkeys([
            item.get("issue_type") for item in security_matches if item.get("issue_type") in SECURITY_ISSUE_TYPES
        ] + list((extraction or {}).get("security_issue_types") or [])))
    matched = _dedupe_hits(matched)
    confidence = round(max(0.0, min(1.0, confidence)), 2)
    unknowns = list(dict.fromkeys(unknowns))
    controls = _controls_for(cap_ids)
    formula = f"13×{impact} + 7×{exposure} = {base_score}"
    explanation_chain = [
        {"stage": "observed_evidence", "title": "观察到的原文", "detail": evidence or [{"field": "tool.description", "text": description or "(empty)"}]},
        {"stage": "extracted_fact", "title": "LLM 规则语义匹配", "detail": [RULE_BY_ID[cap]["title"] for cap in cap_ids] or ["没有通过验证的 CAP 规则命中"]},
        {"stage": "authority_basis", "title": "权威依据", "detail": list(dict.fromkeys(hit["authority"] for hit in matched))},
        {"stage": "product_mapping", "title": "产品规则映射", "detail": [hit["id"] for hit in matched]},
        {"stage": "numeric_rationale", "title": "数值政策", "detail": f"{formula}；能力下限 {cap_floor}；元数据下限 {metadata_floor or '无'}"},
        {"stage": "unknowns", "title": "未知项", "detail": unknowns or ["无影响当前分类的未知项"]},
    ]

    return {
        **tool,
        "score_type": SCORE_TYPE,
        "score": effective_score,
        "risk_score": effective_score,
        "capability_risk_score": capability_score,
        "effective_risk_score": effective_score,
        "risk_level": level,
        "risk_label": risk_label,
        "confidence": confidence,
        "decision": decision,
        "metadata_integrity": integrity,
        "metadata_integrity_reason": integrity_reason,
        "implementation_risk": "unknown",
        "implementation_risk_reason": "描述评分不能证明实现是否存在漏洞；需要 SAST、CVE 或运行时验证",
        "residual_risk": residual_risk,
        "residual_risk_reason": "仅在控制实施证据可验证后计算" if residual_risk == "unknown" else "基于已验证控制单独估算，不改变固有能力分",
        "impact": impact,
        "impact_detail": {"value": impact, "reason": RULE_BY_ID[top_cap]["title"] if top_cap else "语义能力尚未完成分类"},
        "exposure": exposure,
        "exposure_detail": {"value": exposure, "reason": "；".join(hit["title"] for hit in exposure_rules) or "固定闭合目标，未识别放大条件"},
        "base_score": base_score,
        "base_formula": formula,
        "capability_floor": cap_floor,
        "metadata_floor": metadata_floor,
        "capabilities": cap_ids,
        "candidate_capabilities": list(dict.fromkeys(rejected_candidates)),
        "classification_status": classification_status,
        "classification_source": classification_source,
        "data_classes": data_classes,
        "untrusted_content": untrusted_content,
        "has_security_issue": bool(security_matches),
        "security_issue_types": security_issue_types,
        "security_rule_matches": security_matches,
        "matched_rules": matched,
        "evidence": evidence,
        "unknowns": unknowns,
        "minimum_controls": controls,
        "explanation_chain": explanation_chain,
        "llm_raw_response": raw_extraction,
        "llm_response_meta": response_meta,
        "llm_extraction": extraction,
        "llm_metadata_hash": _tool_metadata_hash(tool) if extraction else None,
        "llm_prompt_version": LLM_PROMPT_VERSION,
        "rule_set_version": RULE_SET_VERSION,
    }


def _tool_metadata_hash(tool: dict[str, Any]) -> str:
    return canonical_hash({
        "name": tool.get("name"), "description": tool.get("description"),
        "inputSchema": tool.get("inputSchema") or tool.get("input_schema") or {},
        "outputSchema": tool.get("outputSchema") or tool.get("output_schema") or {},
        "annotations": tool.get("annotations") or {},
    })


def _cached_extraction(tool: dict[str, Any]) -> dict[str, Any] | None:
    cached = tool.get("llm_extraction")
    if (isinstance(cached, dict) and versions_match(cached, LLM_PROMPT_VERSION, RULE_SET_VERSION)
            and tool.get("llm_metadata_hash") == _tool_metadata_hash(tool)):
        return cached
    return None


def _flow_role_supported(tool: dict[str, Any], role: str) -> bool:
    if tool.get("classification_status") != "classified":
        return False
    caps = set(tool.get("capabilities") or [])
    exp = {hit["id"] for hit in tool.get("matched_rules") or []}
    requirements = {
        "private_data_source": bool(caps & PRIVATE_CAPS),
        "untrusted_content_source": bool(tool.get("untrusted_content")),
        "external_sink": "CAP-010" in caps,
        "secret_source": "CAP-005" in caps,
        "execution_sink": bool(caps & {"CAP-011", "CAP-015"}),
        "sensitive_data_source": bool(caps & SENSITIVE_CAPS),
        "bulk_selector": "EXP-004" in exp,
        "arbitrary_external_sink": "CAP-010" in caps and "EXP-005" in exp,
        "infrastructure_write_sink": "CAP-016" in caps,
        "arbitrary_execution_source": bool(caps & {"CAP-011", "CAP-012"}),
    }
    return requirements.get(role, False)


def _flow_matches(scored_tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    caps = {cap for tool in scored_tools for cap in tool.get("capabilities", [])}
    rule_ids = {hit["id"] for tool in scored_tools for hit in tool.get("matched_rules", [])}
    has = lambda *items: any(item in caps for item in items)
    untrusted = any(tool.get("untrusted_content") for tool in scored_tools)
    private = has("CAP-003", "CAP-004", "CAP-005")
    sensitive = has("CAP-004", "CAP-005")
    external = "CAP-010" in caps
    execution = has("CAP-011", "CAP-015")
    batch = "EXP-004" in rule_ids
    free_target = "EXP-005" in rule_ids
    query_or_exec = has("CAP-011", "CAP-012")
    conditions = [
        ("FLOW-001", private and untrusted and external),
        ("FLOW-002", "CAP-005" in caps and external),
        ("FLOW-003", untrusted and execution),
        ("FLOW-004", sensitive and batch and free_target),
        ("FLOW-005", "CAP-016" in caps and query_or_exec),
    ]
    matches: list[dict[str, Any]] = []
    for rule_id, is_match in conditions:
        if is_match:
            rule = RULE_BY_ID[rule_id]
            score = rule.get("score")
            matches.append({
                **_hit(
                    rule_id,
                    scope="same_server_tool_set",
                    source="deterministic_flow_candidate",
                    source_detail="代码仅确认 FLOW 前置能力与暴露条件，尚未确认语义路径",
                ),
                "score": score,
            })
    return matches


def _valid_flow_extraction(
    scored_tools: list[dict[str, Any]],
    extraction: dict[str, Any],
    candidate_ids: set[str],
) -> dict[str, Any]:
    """Whitelist FLOW IDs, Tool participants, roles and exact per-Tool evidence."""
    tools = {str(tool.get("name") or ""): tool for tool in scored_tools}
    if not versions_match(extraction, FLOW_PROMPT_VERSION, RULE_SET_VERSION):
        return {"matches": [], "rejections": ["FLOW 响应版本不匹配"], "rejected_candidates": [], "unknowns": []}
    if not isinstance(extraction.get("flow_rule_matches"), list):
        return {"matches": [], "rejections": ["FLOW 回复缺少完整候选数组"], "rejected_candidates": [], "unknowns": []}
    accepted: list[dict[str, Any]] = []
    rejections: list[str] = []
    raw_unknowns = extraction.get("unknowns") or []
    if not isinstance(raw_unknowns, list):
        raw_unknowns = [raw_unknowns]

    for item in extraction.get("flow_rule_matches") or []:
        if not isinstance(item, dict):
            continue
        rule_id = str(item.get("rule_id") or "")
        try:
            confidence = float(item.get("confidence", 0))
        except (TypeError, ValueError):
            confidence = 0
        if rule_id not in FLOW_LLM_GUIDANCE:
            rejections.append(f"LLM 返回了不允许的 FLOW 规则 ID：{rule_id or '(empty)'}")
            continue
        if rule_id not in candidate_ids:
            rejections.append(f"{rule_id} 未通过代码侧能力/暴露前置条件")
            continue
        if not supported_confidence(item.get("confidence")):
            rejections.append(f"{rule_id} 置信度 {confidence:.2f} 低于 {LLM_MATCH_CONFIDENCE:.2f}")
            continue

        allowed_roles = set(FLOW_LLM_GUIDANCE[rule_id]["participant_roles"])
        participants: list[dict[str, Any]] = []
        roles: set[str] = set()
        invalid_reason: str | None = None
        for participant in item.get("participants") or []:
            if not isinstance(participant, dict):
                continue
            tool_name = str(participant.get("tool_name") or "")
            role = str(participant.get("role") or "")
            tool = tools.get(tool_name)
            if not tool:
                invalid_reason = f"{rule_id} 引用了不存在的 Tool：{tool_name or '(empty)'}"
                break
            if role not in allowed_roles:
                invalid_reason = f"{rule_id} 为 {tool_name} 返回了未定义角色：{role or '(empty)'}"
                break
            if not _flow_role_supported(tool, role):
                invalid_reason = f"{rule_id} 的参与 Tool {tool_name} 没有支持角色 {role} 的已确认能力/暴露事实"
                break
            source = " ".join([
                str(tool.get("name") or ""),
                str(tool.get("description") or ""),
                json.dumps(tool.get("inputSchema") or tool.get("input_schema") or {}, ensure_ascii=False),
                json.dumps(tool.get("outputSchema") or tool.get("output_schema") or {}, ensure_ascii=False),
                json.dumps(tool.get("annotations") or {}, ensure_ascii=False),
            ]).lower()
            raw_evidence = participant.get("evidence") or []
            if isinstance(raw_evidence, str):
                raw_evidence = [raw_evidence]
            evidence = [
                str(quote) for quote in raw_evidence
                if str(quote).strip() and str(quote).lower() in source
            ][:6]
            if not evidence:
                invalid_reason = f"{rule_id} 的参与 Tool {tool_name} 没有可逐字复核的元数据证据"
                break
            roles.add(role)
            participants.append({"tool_name": tool_name, "role": role, "evidence": evidence})
        missing_roles = allowed_roles - roles
        if invalid_reason:
            rejections.append(invalid_reason)
        elif missing_roles:
            rejections.append(f"{rule_id} 缺少必需链路角色：{', '.join(sorted(missing_roles))}")
        elif not str(item.get("rationale") or "").strip() or not str(item.get("data_path") or "").strip():
            rejections.append(f"{rule_id} 缺少路径或排除项判定理由")
        else:
            hit = {
                **_hit(
                    rule_id,
                    scope="same_server_semantic_path",
                    source="llm_semantic_flow_confirmed",
                    source_detail="Server 级 LLM 确认参与 Tool、角色、证据和源到汇语义路径",
                ),
                "score": RULE_BY_ID[rule_id].get("score"),
                "confidence": round(min(1.0, max(0.0, confidence)), 2),
                "rationale": str(item.get("rationale") or ""),
                "data_path": str(item.get("data_path") or ""),
                "participants": participants,
                "source": "llm_semantic_flow_confirmed",
            }
            accepted.append(hit)

    rejected_candidates = extraction.get("rejected_candidates") or []
    if not isinstance(rejected_candidates, list):
        rejected_candidates = []
    return {
        "matches": _dedupe_hits(accepted),
        "rejections": rejections,
        "rejected_candidates": [item for item in rejected_candidates if isinstance(item, dict)],
        "unknowns": [str(item) for item in raw_unknowns if str(item).strip()],
    }


def _stable_snapshot(server: dict[str, Any]) -> dict[str, Any]:
    server_info = server.get("server_info") or {}
    return {
        "server": {
            "name": server.get("name"), "description": server.get("description"),
            "server_name": server_info.get("name"), "version": server_info.get("version"),
            "publisher": server.get("publisher"), "source": server.get("url") or server.get("command"),
            "transport": server.get("transport", "unknown"),
            "auth_mode": "configured_headers" if server.get("headers") else "none_or_unknown",
        },
        "tools": [{
            "name": tool.get("name"), "title": tool.get("title"), "description": tool.get("description"),
            "inputSchema": tool.get("inputSchema") or tool.get("input_schema"),
            "outputSchema": tool.get("outputSchema") or tool.get("output_schema"),
            "annotations": tool.get("annotations"),
        } for tool in server.get("tools", [])],
    }


def _snapshot_diff(previous: dict[str, Any] | None, current: dict[str, Any]) -> dict[str, list[str]]:
    old_tools = {str(tool.get("name")): tool for tool in ((previous or {}).get("normalized") or {}).get("tools", [])}
    new_tools = {str(tool.get("name")): tool for tool in current.get("tools", [])}
    added = sorted(set(new_tools) - set(old_tools))
    removed = sorted(set(old_tools) - set(new_tools))
    changed = sorted(name for name in set(old_tools) & set(new_tools) if canonical_hash(old_tools[name]) != canonical_hash(new_tools[name]))
    return {"added_tools": added, "removed_tools": removed, "changed_tools": changed}


def score_server(
    server: dict[str, Any],
    extractions: dict[str, dict[str, Any]] | None = None,
    previous_score: int | None = None,
    flow_extraction: dict[str, Any] | None = None,
) -> dict[str, Any]:
    extractions = extractions or {}
    provenance_verified = bool(server.get("provenance_verified"))
    previous_hash = server.get("source_snapshot_hash")
    previous_snapshot = server.get("source_snapshot")
    current_snapshot = _stable_snapshot(server)
    current_hash = canonical_hash(current_snapshot)
    change_status = "new" if not previous_hash else "unchanged" if previous_hash == current_hash else "changed"
    diff = _snapshot_diff(previous_snapshot, current_snapshot)

    scored_tools = [
        score_tool(
            tool, extractions.get(str(tool.get("name"))) or _cached_extraction(tool),
            provenance_verified=provenance_verified,
        )
        for tool in server.get("tools", [])
    ]
    capability_score = max((tool["capability_risk_score"] for tool in scored_tools), default=0)
    flow_candidates = _flow_matches(scored_tools)
    semantic_candidates = list(flow_candidates)
    raw_flow_extraction = dict(flow_extraction) if isinstance(flow_extraction, dict) else None
    flow_response_meta = raw_flow_extraction.pop("__audit", {}) if raw_flow_extraction else {}
    flow_validation = {"matches": [], "rejections": [], "rejected_candidates": [], "unknowns": []}
    if isinstance(flow_extraction, dict):
        try:
            flow_validation = _valid_flow_extraction(
                scored_tools, flow_extraction, {hit["id"] for hit in semantic_candidates},
            )
            flow_hits = _dedupe_hits(flow_validation["matches"])
            flow_classification_status = "partial" if flow_validation["rejections"] else "classified"
        except Exception as exc:
            flow_validation["rejections"] = [f"FLOW LLM 返回结构无法安全解析：{type(exc).__name__}"]
            flow_validation["unknowns"] = ["Server 级 FLOW 语义判断失败；候选未参与评分"]
            flow_hits = []
            flow_classification_status = "unavailable"
    else:
        # A prerequisite combination is not a confirmed path. If the Server-level
        # semantic pass is unavailable, keep candidates and unknowns for review
        # but never apply a FLOW score or floor.
        flow_hits = []
        flow_classification_status = "unavailable" if semantic_candidates else "not_required"
        if semantic_candidates:
            flow_validation["unknowns"] = ["Server 级 FLOW 语义判断未完成；候选未参与评分"]

    metadata_floor = max((tool.get("metadata_floor", 0) for tool in scored_tools), default=0)

    flow_score = max((hit.get("score") or 0 for hit in flow_hits), default=0)
    effective_score = max(capability_score, metadata_floor, flow_score)
    level, risk_label, decision = risk_band(effective_score)
    if metadata_floor >= 100 or any(tool.get("decision") == "quarantine" for tool in scored_tools):
        decision = "quarantine"

    top_tool_effective = max((tool["effective_risk_score"] for tool in scored_tools), default=0)
    highest = [tool["name"] for tool in scored_tools if tool["effective_risk_score"] == top_tool_effective]
    primary = next((tool for tool in scored_tools if tool.get("name") in highest), None) or {
        "impact": 0, "exposure": 0, "confidence": 0.5, "matched_rules": [],
        "evidence": [], "unknowns": ["Server 未返回 Tool"], "base_score": 0,
    }
    all_hits = _dedupe_hits(primary.get("matched_rules", []) + flow_hits + [hit for tool in scored_tools for hit in tool.get("matched_rules", [])])
    meta_ids = {hit["id"] for hit in all_hits if hit["id"].startswith("META-")}
    integrity, integrity_reason = _metadata_integrity(meta_ids, provenance_verified)
    capability_counts = Counter(tool.get("risk_label", "informational") for tool in scored_tools)
    capabilities = sorted({cap for tool in scored_tools for cap in tool.get("capabilities", [])})
    controls = _controls_for(capabilities)
    unknowns = sorted({item for tool in scored_tools for item in tool.get("unknowns", [])})
    unknowns.extend(flow_validation.get("unknowns") or [])
    unknowns.extend(flow_validation.get("rejections") or [])
    if semantic_candidates and flow_classification_status == "unavailable":
        unknowns.append("Server 级 FLOW 语义判断未完成；代码候选未参与评分，尚未证明实际语义链路")
    server_info = server.get("server_info") or {}
    if not server_info.get("version"):
        unknowns.append("Server 版本未知")
    if not server.get("publisher"):
        unknowns.append("Publisher 未验证")
    if not provenance_verified:
        unknowns.append("Server 来源/签名未验证；annotations 仅作待验证声明")
    confidence = min((tool.get("confidence", 1.0) for tool in scored_tools), default=0.5)
    confidence = max(0.0, round(confidence - (0 if provenance_verified else 0.1), 2))
    if integrity == "untrusted":
        confidence = min(confidence, 0.4)
    elif integrity == "malicious":
        confidence = min(confidence, 0.2)

    residual_values = [tool["residual_risk"] for tool in scored_tools if isinstance(tool.get("residual_risk"), int)]
    residual_risk: int | str = max(residual_values) if residual_values and len(residual_values) == len(scored_tools) else "unknown"
    classified_count = sum(tool.get("classification_status") == "classified" for tool in scored_tools)
    classification_status = "classified" if classified_count == len(scored_tools) and scored_tools else "partial" if classified_count else "unclassified"
    approval_required = classification_status != "classified" or effective_score >= 60 or integrity in {"untrusted", "malicious"}
    evaluated_at = datetime.now(timezone.utc).isoformat()
    source_snapshot = {
        "retrieved_at": evaluated_at,
        "original": {"server": current_snapshot["server"], "tools": current_snapshot["tools"]},
        "normalized": current_snapshot,
    }
    scope_statement = "FLOW 先由代码验证能力前置条件，再由 Server 级 LLM 判断 Tool 间语义数据/控制路径；这仍不等同于运行时可达性验证。跨 Server/Agent/Session 需配置实际可达关系后另评。"
    explanation_chain = [
        {"stage": "observed_evidence", "title": "观察到的原文", "detail": primary.get("evidence", []) or [{"field": "tools/list", "text": f"{len(scored_tools)} Tools"}]},
        {"stage": "extracted_fact", "title": "结构化能力事实", "detail": [RULE_BY_ID[cap]["title"] for cap in capabilities]},
        {"stage": "authority_basis", "title": "权威依据", "detail": list(dict.fromkeys(hit["authority"] for hit in all_hits))},
        {"stage": "product_mapping", "title": "产品规则映射", "detail": [hit["id"] for hit in all_hits]},
        {"stage": "flow_semantics", "title": "Server 级 FLOW 语义判断", "detail": [
            f"状态：{flow_classification_status}",
            f"代码前置候选：{', '.join(hit['id'] for hit in semantic_candidates) or '无'}",
            f"证据校验后生效：{', '.join(hit['id'] for hit in flow_hits) or '无'}",
            *[f"校验拒绝：{item}" for item in flow_validation.get("rejections") or []],
            *[f"未知项：{item}" for item in flow_validation.get("unknowns") or []],
        ]},
        {"stage": "numeric_rationale", "title": "数值政策", "detail": f"固有能力 {capability_score}；META 下限 {metadata_floor or '无'}；FLOW 下限 {flow_score or '无'}；有效分 {effective_score}"},
        {"stage": "unknowns", "title": "未知项", "detail": list(dict.fromkeys(unknowns)) or ["无影响当前分类的未知项"]},
    ]

    return {
        **server,
        "status": "connected" if server.get("tools") is not None else server.get("status", "configured"),
        "tool_count": len(scored_tools),
        "tools": scored_tools,
        "score_type": SCORE_TYPE,
        "risk_score": effective_score,
        "capability_risk_score": capability_score,
        "effective_risk_score": effective_score,
        "risk_level": level,
        "risk_label": risk_label,
        "decision": decision,
        "metadata_integrity": integrity,
        "metadata_integrity_reason": integrity_reason,
        "implementation_risk": "unknown",
        "implementation_risk_reason": "需独立 SAST、CVE 或运行时验证，不由 Tool 描述评分推断",
        "residual_risk": residual_risk,
        "residual_risk_reason": "未验证控制实施证据" if residual_risk == "unknown" else "基于已验证控制单独计算",
        "impact": primary.get("impact", 0),
        "impact_detail": primary.get("impact_detail"),
        "exposure": primary.get("exposure", 0),
        "exposure_detail": primary.get("exposure_detail"),
        "base_score": primary.get("base_score", 0),
        "base_formula": primary.get("base_formula"),
        "capability_floor": primary.get("capability_floor", 0),
        "metadata_floor": metadata_floor,
        "confidence": confidence,
        "classification_status": classification_status,
        "classified_tool_count": classified_count,
        "matched_rules": all_hits,
        "toxic_combinations": flow_hits,
        "flow_candidates": semantic_candidates,
        "flow_classification_status": flow_classification_status,
        "flow_validation_rejections": flow_validation.get("rejections") or [],
        "flow_rejected_candidates": flow_validation.get("rejected_candidates") or [],
        "flow_unknowns": flow_validation.get("unknowns") or [],
        "flow_llm_raw_response": raw_flow_extraction,
        "flow_llm_response_meta": flow_response_meta,
        "flow_prompt_version": FLOW_PROMPT_VERSION,
        "combination_scope": "same_server_tool_set",
        "combination_semantics": (
            "llm_confirmed_same_server_semantic_path" if flow_hits
            else "metadata_candidates_unconfirmed" if semantic_candidates
            else "no_flow_candidate"
        ),
        "scope_statement": scope_statement,
        "evidence": primary.get("evidence", []),
        "unknowns": list(dict.fromkeys(unknowns)),
        "highest_risk_tools": highest,
        "capability_summary": capabilities,
        "capability_count_by_level": dict(capability_counts),
        "minimum_controls": controls,
        "explanation_chain": explanation_chain,
        "change_status": change_status,
        "change_details": diff,
        "source_snapshot": source_snapshot,
        "source_snapshot_hash": current_hash,
        "rule_set_version": RULE_SET_VERSION,
        "llm_prompt_version": LLM_PROMPT_VERSION,
        "evaluated_at": evaluated_at,
        "approval_required": approval_required,
    }
