"""MCP scoring domain."""
