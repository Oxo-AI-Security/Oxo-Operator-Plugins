"""Risk-scoring domain rules and deterministic policy."""
