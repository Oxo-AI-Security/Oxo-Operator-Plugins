"""Declarative rule prerequisites over reviewed operational records.

No keywords, sample names, model calls, findings or numeric scores.
"""

# Fields use the same operational vocabulary for every rule family.
PREREQUISITES = {
    'CAP-011': {'action': ['execute'], 'control': ['caller_executable']},
    'EXP-006': {'action': ['execute'], 'control': ['caller_executable']},
    'CAP-020': {'action': ['install']},
    'CAP-015': {'action': ['interface'], 'authenticated_session_proven': [True]},
    'SEM-006': {'action': ['instruction_priority'], 'content_use': ['higher_priority_instruction'],
                'origin': ['service_content', 'public_content', 'workspace']},
    'EXP-003': {'origin': ['service_content', 'public_content']},
    'EXP-004': {'reach': ['multiple_objects']},
    'EXP-005': {'reach': ['free_target']},
    'EXP-007': {'reach': ['privileged']},
    'EXP-008': {'reach': ['automatic']},
}

PURE_TASK_ACTIONS = frozenset({'transform', 'interact'})

# Shared by extraction, review and rule mapping. Invocation identity is not a
# resource effect; fixed APIs may still have separately recorded IO effects.
OPERATION_SEMANTICS = {
    'classification_unit': 'reviewed resource effect, with program execution normalized separately',
    'fixed_tool_or_api': 'A fixed tool/API identity alone is not program execution. Classify all declared effects: transform/interact, read, create, modify, delete, send, install, etc.',
    'program_or_dynamic_invocation': 'Program invocation, or caller-controlled executable input even through an API, produces a separate execute fact and excludes CAP-001.',
    'pure_actions': sorted(PURE_TASK_ACTIONS),
    'pure_read_origins': ['packaged'],
    'baseline_requirement': 'Complete reviewed coverage; every active effect must be pure. Unknown executable control cannot prove purity. Source words, imports and inert/negated examples alone do not establish an active effect.',
}


def pure_operation(operation):
    """Task conversation/content work and packaged reads, without persistent IO."""
    invocation = operation.get('invocation')
    if invocation and (invocation['kind'] != 'tool_or_api' or invocation['control'] != 'fixed_data'):
        return False
    return operation['action'] in PURE_TASK_ACTIONS or (
        operation['action']=='read' and operation['origin']=='packaged')


def operational_rule(rule):
    """Static integrity statements use direct source proof; runtime predicates use operations."""
    return rule.split('-')[0] not in {'SEM','MAL'} or rule in PREREQUISITES


def _matches(operation, required):
    return all(bool(set(operation.get(key, [])) & set(values)) if isinstance(operation.get(key), list)
               else operation.get(key) in values for key,values in required.items())


def profile_rule_error(rule, profile):
    """A valid rule cannot contradict the immutable reviewed operations."""
    operations=[o for o in profile.get('operations',[]) if o.get('actor')=='runtime_agent']
    if rule in {'CAP-001','EXP-001'}:
        if not profile.get('coverage_complete') or not operations:
            return 'zero_baseline_has_no_complete_operational_profile'
        if rule=='CAP-001' and any(not pure_operation(o) for o in operations):
            return 'zero_baseline_conflicts_with_reviewed_operations'
        if rule=='EXP-001' and any(o['origin'] not in {'task','packaged'} or set(o['reach'])-{'fixed'}
                or o['action'] not in {'transform','interact','read'} for o in operations):
            return 'fixed_baseline_conflicts_with_reviewed_operations'
    required=PREREQUISITES.get(rule)
    if required and not any(_matches(o,required) for o in operations):
        return 'rule_prerequisite_not_in_reviewed_operations'
    return None


def validate_mapping(rule, operation_ids, profile):
    """Bind a rule to immutable fact identities and cap certainty at its facts."""
    if not operational_rule(rule):
        return None,1
    if not isinstance(operation_ids,list) or not operation_ids or any(not isinstance(i,str) for i in operation_ids):
        return 'rule_operation_identity_missing', None
    if len(set(operation_ids))!=len(operation_ids):
        return 'rule_operation_identity_duplicate', None
    by_id={o['operation_id']:o for o in profile['operations']}
    if any(i not in by_id or by_id[i]['actor']!='runtime_agent' for i in operation_ids):
        return 'rule_operation_not_reviewed_or_not_active', None
    selected=[by_id[i] for i in operation_ids]
    basis=profile if rule in {'CAP-001','EXP-001'} else {**profile,'operations':selected}
    error=profile_rule_error(rule,basis)
    return error,min(o['confidence'] for o in selected)
