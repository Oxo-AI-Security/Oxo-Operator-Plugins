"""Skill scanning domain."""
