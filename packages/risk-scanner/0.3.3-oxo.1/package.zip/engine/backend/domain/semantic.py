"""Pure acceptance contracts; no model calls or rule inference."""
from __future__ import annotations

import math
from typing import Any


def supported_confidence(value: Any, threshold: float = 0.60) -> bool:
    if isinstance(value, bool):
        return False
    try:
        number = float(value)
    except (TypeError, ValueError):
        return False
    return math.isfinite(number) and threshold <= number <= 1.0


def versions_match(response: dict[str, Any], prompt: str, rules: str) -> bool:
    return response.get("prompt_version") == prompt and response.get("rule_set_version") == rules
