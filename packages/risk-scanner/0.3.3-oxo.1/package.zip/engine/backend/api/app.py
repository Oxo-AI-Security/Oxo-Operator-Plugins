"""FastAPI application factory and cross-cutting HTTP configuration."""

from collections.abc import Callable
from typing import AsyncContextManager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

OPENAPI_TAGS = [
    {"name": "System", "description": "Health and version information."},
    {"name": "MCP Servers", "description": "Register, connect, evaluate, and remove MCP Servers."},
    {"name": "MCP Rules", "description": "Read the versioned MCP scoring rule catalog."},
    {"name": "Skills", "description": "Upload archives, inspect analyzed AI Skills, reuse hash-matched results, and remove stored results."},
    {"name": "Skill Rules", "description": "Read the versioned Skill scoring rule catalog."},
    {"name": "Model Settings", "description": "Configure and test the semantic-analysis model."},
    {"name": "Async Scoring", "description": "Submit captured MCP or Skill snapshots and poll immutable scoring jobs."},
]

# The scoring API is designed to be called by other products on the trusted LAN.
# CORS is intentionally unrestricted; it is a browser policy, not authentication.
ALLOWED_ORIGINS = ["*"]


def create_api_app(
    *,
    lifespan: Callable[[FastAPI], AsyncContextManager[None]] | None = None,
) -> FastAPI:
    """Create the HTTP shell; feature routes are registered by the composition root."""
    app = FastAPI(
        title="Risk score API",
        version="2.3.0",
        description=(
            "Public HTTP API for MCP discovery and scoring, AI Skill package scanning, "
            "versioned rule catalogs, and model configuration. All scanner decisions include "
            "evidence and rule-version metadata so callers can audit the result."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        openapi_tags=OPENAPI_TAGS,
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=ALLOWED_ORIGINS,
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return app
