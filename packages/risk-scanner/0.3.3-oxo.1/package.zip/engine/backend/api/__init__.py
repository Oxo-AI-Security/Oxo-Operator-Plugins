"""HTTP interface models and route adapters."""
