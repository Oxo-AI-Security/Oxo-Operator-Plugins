"""Validated HTTP request models.

Keeping transport schemas here makes the API contract discoverable without
mixing validation concerns into scoring or persistence code.
"""

from __future__ import annotations

from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, Field, field_validator, model_validator
from ..infrastructure.ai.provider_config import DEFAULT_BASE_URL, ProviderName, provider_spec

class ServerCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=1000)
    transport: Literal["streamable_http", "sse", "stdio"] = "streamable_http"
    url: str | None = None
    command: str | None = None
    args: list[str] = Field(default_factory=list, max_length=50)
    headers: dict[str, str] = Field(default_factory=dict)
    stdio_acknowledged: bool = False

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: str | None) -> str | None:
        if value and not value.startswith(("http://", "https://")):
            raise ValueError("URL 必须使用 http:// 或 https://")
        return value


class EvaluateRequest(BaseModel):
    use_llm: bool = True
    refresh_tools: bool = False


class ModelSettingsInput(BaseModel):
    provider: ProviderName = "openai_compatible"
    model: str = Field(default="qwen-plus", min_length=2, max_length=100)
    base_url: str = Field(
        default=DEFAULT_BASE_URL,
        min_length=8,
        max_length=500,
    )
    azure_endpoint: str | None = Field(default=None, max_length=1000)
    azure_deployment: str | None = Field(default=None, max_length=200)
    api_key: str | None = Field(default=None, max_length=500)

    @model_validator(mode="before")
    @classmethod
    def apply_provider_defaults(cls, value):
        if not isinstance(value, dict):
            return value
        result = dict(value)
        spec = provider_spec(result)
        result.setdefault('model', spec.default_model)
        # Foundry uses azure_endpoint; preserve the compatibility field's default.
        result.setdefault('base_url', spec.base_url or DEFAULT_BASE_URL)
        return result

    @field_validator("base_url", "azure_endpoint")
    @classmethod
    def validate_endpoint(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip().rstrip("/")
        if not value.startswith("https://"):
            raise ValueError("生产模型 Endpoint 必须使用 HTTPS")
        parsed = urlsplit(value)
        if not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Endpoint 必须是有效 HTTPS URL，且不能包含用户名或密码")
        return value

    @field_validator("model", "azure_deployment")
    @classmethod
    def strip_model_fields(cls, value: str | None) -> str | None:
        return value.strip() if value else value

    @model_validator(mode="after")
    def validate_provider_fields(self) -> "ModelSettingsInput":
        if self.provider == "azure_openai":
            if not self.azure_endpoint:
                raise ValueError("Azure AI Foundry 需要 Endpoint")
            if not self.azure_deployment:
                raise ValueError("Azure AI Foundry 需要 Deployment name")
        return self
