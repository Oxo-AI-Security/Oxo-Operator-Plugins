"""Validated snapshot payloads for external asynchronous scoring clients."""

from __future__ import annotations

import base64
import io
import json
import re
import stat
import tarfile
import zipfile
from pathlib import PurePosixPath
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError


MAX_PAYLOAD_CHARS = 8_000_000
MAX_TOOLS = 1_000
MAX_SKILL_FILES = 1_000
MAX_SKILL_FILE_BYTES = 6_000_000
MAX_SKILL_TOTAL_BYTES = 8_000_000


class PayloadFormatError(ValueError):
    def __init__(self, code: str, message: str, field: str = "payload") -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.field = field

    def detail(self) -> dict[str, str]:
        return {"code": self.code, "message": self.message, "field": self.field}


class ExternalMcpScoreRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", json_schema_extra={
        "examples": [{
            "name": "HR tools snapshot",
            "description": "Captured from the production MCP tools/list response.",
            "client_reference": "asset-hr-mcp-42",
            "payload": '{"jsonrpc":"2.0","id":2,"result":{"tools":[{"name":"search_users","description":"Search users by name or email.","inputSchema":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]},"annotations":{"readOnlyHint":true,"destructiveHint":false,"idempotentHint":true,"openWorldHint":false}}]}}',
        }]
    })

    payload: str = Field(
        min_length=2,
        max_length=MAX_PAYLOAD_CHARS,
        description="MCP tools/list JSON-RPC response serialized as one JSON string.",
    )
    name: str = Field(default="External MCP snapshot", min_length=1, max_length=120)
    description: str = Field(default="", max_length=2_000)
    server_info: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional serverInfo captured from the initialize response.",
    )
    client_reference: str | None = Field(
        default=None,
        max_length=200,
        description=(
            "Optional caller correlation key. Reusing it updates the same external MCP inventory item; "
            "omitting it creates a new item for every request."
        ),
    )
class ScoreJobAccepted(BaseModel):
    request_id: str
    kind: Literal["mcp", "skill"]
    status: Literal["queued"]
    submitted_at: str
    client_reference: str | None = None
    result_url: str


class ScoreJobStatus(BaseModel):
    request_id: str
    kind: Literal["mcp", "skill"]
    status: Literal["queued", "running", "succeeded", "failed"]
    submitted_at: str
    started_at: str | None = None
    completed_at: str | None = None
    client_reference: str | None = None
    input_summary: dict[str, Any]
    result: dict[str, Any] | None = None
    error: dict[str, Any] | None = None


class McpToolSnapshot(BaseModel):
    model_config = ConfigDict(extra="allow")

    name: str = Field(min_length=1, max_length=256)
    title: str | None = Field(default=None, max_length=500)
    description: str | None = Field(default=None, max_length=100_000)
    inputSchema: dict[str, Any]
    outputSchema: dict[str, Any] | None = None
    annotations: dict[str, Any] | None = None


def _decode_json_string(payload: str, code: str) -> Any:
    try:
        return json.loads(payload)
    except json.JSONDecodeError as exc:
        raise PayloadFormatError(
            code,
            f"payload 不是合法 JSON：第 {exc.lineno} 行第 {exc.colno} 列，{exc.msg}",
        ) from exc


def parse_mcp_tools_payload(payload: str) -> list[dict[str, Any]]:
    document = _decode_json_string(payload, "INVALID_MCP_JSON")
    if not isinstance(document, dict):
        raise PayloadFormatError("INVALID_MCP_ENVELOPE", "MCP payload 顶层必须是 JSON object。")
    if document.get("jsonrpc") != "2.0":
        raise PayloadFormatError("INVALID_MCP_ENVELOPE", "jsonrpc 必须等于字符串 2.0。", "payload.jsonrpc")
    if "id" not in document:
        raise PayloadFormatError("INVALID_MCP_ENVELOPE", "tools/list 响应必须包含 id。", "payload.id")
    if document.get("error") is not None:
        raise PayloadFormatError("MCP_ERROR_RESPONSE", "收到的是 JSON-RPC error 响应，不能用于评分。", "payload.error")
    result = document.get("result")
    if not isinstance(result, dict):
        raise PayloadFormatError("INVALID_MCP_RESULT", "result 必须是 JSON object。", "payload.result")
    tools = result.get("tools")
    if not isinstance(tools, list):
        raise PayloadFormatError("INVALID_MCP_TOOLS", "result.tools 必须是 JSON array。", "payload.result.tools")
    if len(tools) > MAX_TOOLS:
        raise PayloadFormatError("MCP_TOOL_LIMIT_EXCEEDED", f"一次最多提交 {MAX_TOOLS} 个 Tool。", "payload.result.tools")

    parsed: list[dict[str, Any]] = []
    names: set[str] = set()
    for index, tool in enumerate(tools):
        if not isinstance(tool, dict):
            raise PayloadFormatError("INVALID_MCP_TOOL", "每个 Tool 必须是 JSON object。", f"payload.result.tools[{index}]")
        try:
            validated = McpToolSnapshot.model_validate(tool)
        except ValidationError as exc:
            message = exc.errors(include_url=False)[0].get("msg", "Tool 结构不合法")
            raise PayloadFormatError("INVALID_MCP_TOOL", str(message), f"payload.result.tools[{index}]") from exc
        if validated.name in names:
            raise PayloadFormatError("DUPLICATE_MCP_TOOL", f"Tool name 重复：{validated.name}", f"payload.result.tools[{index}].name")
        names.add(validated.name)
        parsed.append(validated.model_dump(exclude_none=True))
    return parsed


def _safe_skill_path(raw_path: str, index: int) -> str:
    normalized = raw_path.replace("\\", "/").strip()
    path = PurePosixPath(normalized)
    if (
        not normalized
        or normalized.startswith("/")
        or re.match(r"^[A-Za-z]:", normalized)
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise PayloadFormatError("INVALID_SKILL_PATH", "Skill 文件必须使用包内相对路径。", f"payload.files[{index}].path")
    return path.as_posix()


def _archive_stem(filename: str) -> str:
    name = PurePosixPath(filename).name
    for suffix in (".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".txz", ".zip", ".tar"):
        if name.lower().endswith(suffix):
            return name[:-len(suffix)].strip() or "uploaded-skill"
    return name[:120] or "uploaded-skill"


def _skill_packages(parsed: list[dict[str, Any]], filename: str) -> list[dict[str, Any]]:
    anchors = sorted(
        (item["path"] for item in parsed if PurePosixPath(item["path"]).name == "SKILL.md"),
        key=lambda value: (len(PurePosixPath(value).parts), value.lower()),
    )
    if not anchors:
        raise PayloadFormatError("SKILL_ANCHOR_NOT_FOUND", "压缩包中未发现 SKILL.md，无法确定 Skill 包边界。", "file")

    archive_name = _archive_stem(filename)
    packages: dict[str, list[dict[str, Any]]] = {anchor: [] for anchor in anchors}
    anchor_roots = {anchor: PurePosixPath(anchor).parent for anchor in anchors}
    for item in parsed:
        item_path = PurePosixPath(item["path"])
        candidates = [
            anchor for anchor, root in anchor_roots.items()
            if root == PurePosixPath(".") or root in item_path.parents
        ]
        if not candidates:
            continue
        owner = max(candidates, key=lambda anchor: len(anchor_roots[anchor].parts))
        root = anchor_roots[owner]
        relative = item_path if root == PurePosixPath(".") else item_path.relative_to(root)
        packages[owner].append({**item, "path": relative.as_posix()})

    output = []
    for anchor in anchors:
        root = anchor_roots[anchor]
        package_name = root.name if root != PurePosixPath(".") else archive_name
        output.append({
            "name": package_name[:120],
            "root": "" if root == PurePosixPath(".") else root.as_posix(),
            "anchor": anchor,
            "files": packages[anchor],
        })
    return output


def _validate_archive_entry(path_value: str, size: int, index: int, paths: set[str]) -> str:
    if size > MAX_SKILL_FILE_BYTES:
        raise PayloadFormatError("SKILL_FILE_TOO_LARGE", f"单文件不得超过 {MAX_SKILL_FILE_BYTES} bytes。", f"file[{index}]")
    if len(path_value) > 500:
        raise PayloadFormatError("INVALID_SKILL_PATH", "压缩包内路径不得超过 500 字符。", f"file[{index}]")
    path = _safe_skill_path(path_value, index)
    if path.lower() in paths:
        raise PayloadFormatError("DUPLICATE_SKILL_PATH", f"文件路径重复：{path}", f"file[{index}]")
    paths.add(path.lower())
    return path


def parse_skill_archive(archive_bytes: bytes, filename: str) -> list[dict[str, Any]]:
    if len(archive_bytes) > MAX_PAYLOAD_CHARS:
        raise PayloadFormatError("SKILL_ARCHIVE_TOO_LARGE", f"压缩包不得超过 {MAX_PAYLOAD_CHARS} bytes。", "file")
    lower_name = filename.lower()
    is_zip = lower_name.endswith(".zip")
    is_tar = lower_name.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz"))
    if not is_zip and not is_tar:
        raise PayloadFormatError(
            "UNSUPPORTED_SKILL_ARCHIVE",
            "支持 zip、tar、tar.gz/tgz、tar.bz2/tbz2、tar.xz/txz；暂不支持 rar 或 7z。",
            "file",
        )

    parsed: list[dict[str, Any]] = []
    paths: set[str] = set()
    total_size = 0
    if is_zip:
        try:
            archive = zipfile.ZipFile(io.BytesIO(archive_bytes))
        except (zipfile.BadZipFile, OSError) as exc:
            raise PayloadFormatError("INVALID_SKILL_ARCHIVE", "上传内容不是合法 ZIP 文件。", "file") from exc
        try:
            entries = [item for item in archive.infolist() if not item.is_dir()]
            if len(entries) > MAX_SKILL_FILES:
                raise PayloadFormatError("SKILL_FILE_LIMIT_EXCEEDED", f"一次最多提交 {MAX_SKILL_FILES} 个文件。", "file")
            for index, item in enumerate(entries):
                if item.flag_bits & 0x1:
                    raise PayloadFormatError("ENCRYPTED_SKILL_ARCHIVE", "不支持加密 ZIP 条目。", f"file[{index}]")
                mode = (item.external_attr >> 16) & 0xFFFF
                if mode and stat.S_ISLNK(mode):
                    raise PayloadFormatError("UNSAFE_SKILL_LINK", "压缩包不得包含符号链接。", f"file[{index}]")
                path = _validate_archive_entry(item.filename, item.file_size, index, paths)
                total_size += item.file_size
                if total_size > MAX_SKILL_TOTAL_BYTES:
                    raise PayloadFormatError("SKILL_PACKAGE_TOO_LARGE", f"Skill 解压后总大小不得超过 {MAX_SKILL_TOTAL_BYTES} bytes。", "file")
                raw = archive.read(item)
                if len(raw) != item.file_size:
                    raise PayloadFormatError("INVALID_SKILL_ARCHIVE", f"ZIP 条目大小不一致：{path}", f"file[{index}]")
                parsed.append({"path": path, "content_base64": base64.b64encode(raw).decode("ascii"), "size": len(raw), "last_modified": None})
        finally:
            archive.close()
    else:
        try:
            archive = tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:*")
        except (tarfile.TarError, OSError) as exc:
            raise PayloadFormatError("INVALID_SKILL_ARCHIVE", "上传内容不是合法 TAR 压缩包。", "file") from exc
        try:
            entries = [item for item in archive.getmembers() if not item.isdir()]
            if len(entries) > MAX_SKILL_FILES:
                raise PayloadFormatError("SKILL_FILE_LIMIT_EXCEEDED", f"一次最多提交 {MAX_SKILL_FILES} 个文件。", "file")
            for index, item in enumerate(entries):
                if not item.isfile():
                    raise PayloadFormatError("UNSAFE_SKILL_LINK", "TAR 不得包含链接、设备或其他特殊条目。", f"file[{index}]")
                path = _validate_archive_entry(item.name, item.size, index, paths)
                total_size += item.size
                if total_size > MAX_SKILL_TOTAL_BYTES:
                    raise PayloadFormatError("SKILL_PACKAGE_TOO_LARGE", f"Skill 解压后总大小不得超过 {MAX_SKILL_TOTAL_BYTES} bytes。", "file")
                stream = archive.extractfile(item)
                if stream is None:
                    raise PayloadFormatError("INVALID_SKILL_ARCHIVE", f"无法读取 TAR 条目：{path}", f"file[{index}]")
                raw = stream.read(MAX_SKILL_FILE_BYTES + 1)
                if len(raw) != item.size:
                    raise PayloadFormatError("INVALID_SKILL_ARCHIVE", f"TAR 条目大小不一致：{path}", f"file[{index}]")
                parsed.append({"path": path, "content_base64": base64.b64encode(raw).decode("ascii"), "size": len(raw), "last_modified": None})
        finally:
            archive.close()

    if not parsed:
        raise PayloadFormatError("EMPTY_SKILL_ARCHIVE", "压缩包中没有可扫描文件。", "file")
    return _skill_packages(parsed, filename)
