"""Adapters for AI providers, MCP transports, files, and persistence."""
