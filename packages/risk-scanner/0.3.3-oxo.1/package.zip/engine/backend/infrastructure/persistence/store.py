"""Durable application state backed by SQLite."""

from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any

from .database import DEFAULT_DATABASE_PATH, StateDatabase
from ..ai.provider_config import DEFAULT_BASE_URL, DEFAULT_PROVIDER, provider_spec


class Store:
    def __init__(self, database_path: Path = DEFAULT_DATABASE_PATH) -> None:
        self._lock = RLock()
        self._database = StateDatabase(database_path)
        self.servers = self._load_servers()
        self.skills = self._load_skills()
        self.score_jobs = self._load_score_jobs()
        self.model_settings = self._load_model_settings()

    def _load_skills(self) -> list[dict[str, Any]]:
        skills = self._database.load("skills", [])
        changed = False
        for skill in skills:
            latest = skill.get("latest_scan") or {}
            if latest.get("analysis_status") in {"queued", "pending", "running", "analyzing"}:
                previous = latest["analysis_status"]
                latest.update(analysis_status="error", classification_status="error",
                              analysis_error_code="WORKER_RESTARTED",
                              analysis_error="服务在评分完成前停止或重启；此任务已中断，未恢复扫描。",
                              interruption={"previous_status": previous, "observed_at": datetime.now(UTC).isoformat(),
                                            "reason": "worker_restarted", "auto_resumed": False})
                skill["latest_scan"] = latest
                changed = True
        if changed:
            self._database.save("skills", skills)
        return skills

    def _load_score_jobs(self) -> list[dict[str, Any]]:
        jobs = self._database.load("score_jobs", [])
        changed = False
        now = datetime.now(UTC).isoformat()
        for job in jobs:
            if job.get("status") in {"queued", "running"}:
                job["status"] = "failed"
                job["completed_at"] = now
                job["error"] = {
                    "code": "WORKER_RESTARTED",
                    "message": "评分任务执行期间服务发生重启，请重新提交。",
                }
                changed = True
        if changed:
            self._database.save("score_jobs", jobs)
        return jobs

    def _load_servers(self) -> list[dict[str, Any]]:
        servers = self._database.load("servers", [])
        for server in servers:
            sealed = server.pop("_sealed_headers", None)
            server["headers"] = self._database.open_json(sealed) if sealed else {}
        return servers

    def _save_servers(self) -> None:
        payload = deepcopy(self.servers)
        for server in payload:
            headers = server.pop("headers", {}) or {}
            if headers:
                server["_sealed_headers"] = self._database.seal_json(headers)
        self._database.save("servers", payload)

    def _load_model_settings(self) -> dict[str, Any]:
        settings = self._database.load(
            "model_settings",
            {
                "provider": DEFAULT_PROVIDER,
                "model": "qwen-plus",
                "base_url": DEFAULT_BASE_URL,
                "azure_endpoint": "",
                "azure_deployment": "",
                "api_key": None,
            },
        )
        sealed = settings.pop("_sealed_api_key", None)
        settings.setdefault("provider", DEFAULT_PROVIDER)
        settings.setdefault("base_url", provider_spec(settings).base_url or DEFAULT_BASE_URL)
        settings.setdefault("azure_endpoint", "")
        settings.setdefault("azure_deployment", "")
        settings["api_key"] = self._database.secrets.open(sealed) if sealed else None
        return settings

    def save_model_settings(self, settings: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self.model_settings = deepcopy(settings)
            payload = deepcopy(settings)
            api_key = payload.pop("api_key", None)
            if api_key:
                payload["_sealed_api_key"] = self._database.secrets.seal(api_key)
            self._database.save("model_settings", payload)
            return deepcopy(self.model_settings)

    def list_servers(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self.servers)

    def get_server(self, server_id: str) -> dict[str, Any] | None:
        with self._lock:
            return next((item for item in self.servers if item["id"] == server_id), None)

    def upsert_server(self, server: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            for index, item in enumerate(self.servers):
                if item["id"] == server["id"]:
                    self.servers[index] = deepcopy(server)
                    self._save_servers()
                    return server
            self.servers.append(deepcopy(server))
            self._save_servers()
            return server

    def delete_server(self, server_id: str) -> bool:
        with self._lock:
            original = len(self.servers)
            self.servers = [item for item in self.servers if item["id"] != server_id]
            changed = len(self.servers) != original
            if changed:
                self._save_servers()
            return changed

    def list_skills(self) -> list[dict[str, Any]]:
        with self._lock:
            return deepcopy(self.skills)

    def claim_score_job(self, request_id: str) -> bool:
        """Atomically start a queued job once; duplicate worker dispatch is a no-op."""
        with self._lock:
            job = next((job for job in self.score_jobs if job["request_id"] == request_id), None)
            if job is None or job.get("status") != "queued":
                return False
            from datetime import UTC, datetime
            job.update(status="running", started_at=datetime.now(UTC).isoformat())
            self._database.save("score_jobs", self.score_jobs)
            return True

    def get_skill(self, skill_id: str) -> dict[str, Any] | None:
        with self._lock:
            return next((deepcopy(item) for item in self.skills if item["id"] == skill_id), None)

    def upsert_skill(self, skill: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            for index, item in enumerate(self.skills):
                if item["id"] == skill["id"]:
                    self.skills[index] = deepcopy(skill)
                    self._database.save("skills", self.skills)
                    return deepcopy(skill)
            self.skills.append(deepcopy(skill))
            self._database.save("skills", self.skills)
            return deepcopy(skill)

    def delete_skill(self, skill_id: str) -> bool:
        with self._lock:
            original = len(self.skills)
            self.skills = [item for item in self.skills if item["id"] != skill_id]
            changed = len(self.skills) != original
            if changed:
                self._database.save("skills", self.skills)
            return changed

    def create_score_job(self, job: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self.score_jobs.append(deepcopy(job))
            self.score_jobs = self.score_jobs[-500:]
            self._database.save("score_jobs", self.score_jobs)
            return deepcopy(job)

    def get_score_job(self, request_id: str, kind: str | None = None) -> dict[str, Any] | None:
        with self._lock:
            return next((
                deepcopy(item) for item in self.score_jobs
                if item.get("request_id") == request_id and (kind is None or item.get("kind") == kind)
            ), None)

    def update_score_job(self, request_id: str, **changes: Any) -> dict[str, Any] | None:
        with self._lock:
            for index, item in enumerate(self.score_jobs):
                if item.get("request_id") != request_id:
                    continue
                updated = {**item, **deepcopy(changes)}
                self.score_jobs[index] = updated
                self._database.save("score_jobs", self.score_jobs)
                return deepcopy(updated)
            return None


store = Store()
