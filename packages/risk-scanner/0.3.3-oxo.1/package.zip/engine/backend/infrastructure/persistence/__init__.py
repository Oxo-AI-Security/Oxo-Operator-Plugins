"""Durable state adapters."""
