"""SQLite state storage with encrypted-at-rest secret fields."""

from __future__ import annotations

import base64
import ctypes
import json
import os
import sqlite3
from ctypes import wintypes
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any


# database.py lives at backend/infrastructure/persistence/database.py.
# Keep durable state at the repository-level data/ directory regardless of
# how deeply infrastructure adapters are nested.
PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DATA_DIR = Path(os.getenv("MCP_RISK_DATA_DIR", PROJECT_ROOT / "data"))
DEFAULT_DATABASE_PATH = DEFAULT_DATA_DIR / "mcp-risk-console.db"


class SecretProtectionError(RuntimeError):
    pass


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _windows_dpapi(data: bytes, *, decrypt: bool) -> bytes:
    buffer = ctypes.create_string_buffer(data)
    source = _DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    result = _DataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    if decrypt:
        ok = crypt32.CryptUnprotectData(ctypes.byref(source), None, None, None, None, 0, ctypes.byref(result))
    else:
        ok = crypt32.CryptProtectData(ctypes.byref(source), "Risk score", None, None, None, 0, ctypes.byref(result))
    if not ok:
        raise SecretProtectionError(f"Windows DPAPI failed with error {ctypes.get_last_error()}")
    try:
        return ctypes.string_at(result.pbData, result.cbData)
    finally:
        kernel32.LocalFree(result.pbData)


class SecretBox:
    """Protect secrets with Windows DPAPI or a permission-restricted local Fernet key."""

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = data_dir

    def seal(self, value: str) -> str:
        raw = value.encode("utf-8")
        if os.name == "nt":
            return "dpapi:" + base64.urlsafe_b64encode(_windows_dpapi(raw, decrypt=False)).decode("ascii")
        return "fernet:" + self._fernet().encrypt(raw).decode("ascii")

    def open(self, value: str) -> str:
        try:
            scheme, payload = value.split(":", 1)
            if scheme == "dpapi" and os.name == "nt":
                raw = _windows_dpapi(base64.urlsafe_b64decode(payload.encode("ascii")), decrypt=True)
            elif scheme == "fernet":
                raw = self._fernet().decrypt(payload.encode("ascii"))
            else:
                raise SecretProtectionError(f"Unsupported secret protection scheme: {scheme}")
            return raw.decode("utf-8")
        except SecretProtectionError:
            raise
        except Exception as exc:
            raise SecretProtectionError("Stored secret could not be decrypted") from exc

    def _fernet(self):
        from cryptography.fernet import Fernet

        key_path = self.data_dir / ".secret.key"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if not key_path.exists():
            key_path.write_bytes(Fernet.generate_key())
            try:
                key_path.chmod(0o600)
            except OSError:
                pass
        return Fernet(key_path.read_bytes())


class StateDatabase:
    def __init__(self, path: Path = DEFAULT_DATABASE_PATH) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self.secrets = SecretBox(self.path.parent)
        with self._connect() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS app_state (
                    name TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )"""
            )

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        return connection

    def load(self, name: str, default: Any) -> Any:
        with self._lock, self._connect() as connection:
            row = connection.execute("SELECT value FROM app_state WHERE name = ?", (name,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row[0])
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Persistent state '{name}' is corrupted") from exc

    def save(self, name: str, value: Any) -> None:
        encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        updated_at = datetime.now(UTC).isoformat()
        with self._lock, self._connect() as connection:
            connection.execute(
                """INSERT INTO app_state(name, value, updated_at) VALUES (?, ?, ?)
                   ON CONFLICT(name) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                (name, encoded, updated_at),
            )

    def seal_json(self, value: Any) -> str:
        return self.secrets.seal(json.dumps(value, ensure_ascii=False, separators=(",", ":")))

    def open_json(self, value: str) -> Any:
        return json.loads(self.secrets.open(value))
