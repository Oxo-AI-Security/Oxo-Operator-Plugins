"""Read-only MCP metadata connector supporting standard transports."""

from __future__ import annotations

import asyncio
import inspect
from typing import Any

import httpx


class McpConnectionError(RuntimeError):
    pass


async def fetch_server_tools(config: dict[str, Any], timeout_seconds: int = 25) -> dict[str, Any]:
    """Initialize a session and read tools/list. No MCP Tool is invoked."""
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.sse import sse_client
        from mcp.client.stdio import stdio_client
        try:
            from mcp.client.streamable_http import streamable_http_client
        except ImportError:  # Stable v1 SDK compatibility.
            from mcp.client.streamable_http import streamablehttp_client as streamable_http_client
    except ImportError as exc:
        raise McpConnectionError("未安装 MCP Python SDK，请先安装 backend/requirements.txt") from exc

    async def read_session(read_stream: Any, write_stream: Any) -> dict[str, Any]:
        async with ClientSession(read_stream, write_stream) as session:
            init = await session.initialize()
            result = await session.list_tools()
            tools = [tool.model_dump(by_alias=True, exclude_none=True) for tool in result.tools]
            server_info = getattr(init, "serverInfo", None) or getattr(init, "server_info", None)
            instructions = getattr(init, "instructions", None)
            return {
                "tools": tools,
                "server_info": server_info.model_dump(by_alias=True, exclude_none=True) if server_info else {},
                "instructions": instructions,
            }

    transport = config.get("transport", "streamable_http")
    try:
        async with asyncio.timeout(timeout_seconds):
            if transport == "stdio":
                if not config.get("stdio_acknowledged"):
                    raise McpConnectionError("stdio Server 必须显式确认命令执行风险")
                params = StdioServerParameters(command=config.get("command") or "", args=config.get("args") or [])
                async with stdio_client(params) as (read_stream, write_stream):
                    return await read_session(read_stream, write_stream)
            if transport == "sse":
                async with sse_client(config.get("url") or "", headers=config.get("headers") or {}) as streams:
                    read_stream, write_stream = streams[0], streams[1]
                    return await read_session(read_stream, write_stream)
            if transport == "streamable_http":
                if "http_client" in inspect.signature(streamable_http_client).parameters:
                    # MCP endpoints are explicit product configuration. Do not let an
                    # ambient machine proxy silently intercept loopback/private demo
                    # traffic and turn a healthy Server into an opaque HTTP 502.
                    async with httpx.AsyncClient(
                        headers=config.get("headers") or {},
                        trust_env=False,
                    ) as http_client:
                        async with streamable_http_client(config.get("url") or "", http_client=http_client) as streams:
                            read_stream, write_stream = streams[0], streams[1]
                            return await read_session(read_stream, write_stream)
                async with streamable_http_client(config.get("url") or "", headers=config.get("headers") or {}) as streams:
                    read_stream, write_stream = streams[0], streams[1]
                    return await read_session(read_stream, write_stream)
            raise McpConnectionError(f"不支持的传输方式：{transport}")
    except TimeoutError as exc:
        raise McpConnectionError(f"连接超时（{timeout_seconds} 秒）") from exc
    except McpConnectionError:
        raise
    except Exception as exc:
        raise McpConnectionError(f"MCP 连接失败：{exc}") from exc
