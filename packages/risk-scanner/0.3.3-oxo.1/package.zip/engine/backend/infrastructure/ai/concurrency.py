"""Bounded stage groups with complete sibling cleanup on failure/cancellation."""
import asyncio


async def gather_stages(*calls, limit=3):
    semaphore = asyncio.Semaphore(limit)

    async def run(call):
        started = False
        try:
            async with semaphore:
                started = True
                return await call
        finally:
            if not started:
                call.close()

    tasks = [asyncio.create_task(run(call)) for call in calls]
    try:
        return await asyncio.gather(*tasks)
    except BaseException:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        raise
