"""One schema for generation and strict local validation, with bounded repair.

No coercion, model/rule fallback, confidence increase or semantic voting.
"""
from copy import deepcopy
import hashlib
import json
from .schema_validation import validation_errors
from .qwen import QwenError

PROTECTED_FIELDS = {'rule_id', 'fact_id', 'confidence', 'prompt_version', 'rule_set_version'}


class ModelContractError(QwenError):
    def __init__(self, message, audit):
        super().__init__(message)
        self.audit = audit


def _has_low_confidence(value, threshold):
    if isinstance(value, dict):
        confidence = value.get('confidence')
        if isinstance(confidence, (int, float)) and not isinstance(confidence, bool) and confidence < threshold:
            return True
        return any(_has_low_confidence(child, threshold) for child in value.values())
    return isinstance(value, list) and any(_has_low_confidence(child, threshold) for child in value)


def _value_at(value, path):
    try:
        for part in path:
            value = value[part]
        return value
    except (KeyError, IndexError, TypeError):
        return None


def _same_json(before, after):
    """JSON booleans are distinct from numbers, including inside containers."""
    if isinstance(before, dict) and isinstance(after, dict):
        return before.keys() == after.keys() and all(_same_json(before[k], after[k]) for k in before)
    if isinstance(before, list) and isinstance(after, list):
        return len(before) == len(after) and all(_same_json(a, b) for a, b in zip(before, after))
    if isinstance(before, bool) or isinstance(after, bool):
        return type(before) is type(after) and before == after
    return before == after


def _lossless_container_repair(before, after):
    if not isinstance(before, str) or not isinstance(after, (list, dict)):
        return False
    try:
        return _same_json(json.loads(before), after)
    except ValueError:
        return _same_json([before], after)


def _preserves_content(before, after, errors):
    allowed = {tuple(error['location']) for error in errors}

    def compare(original, corrected, path):
        if path in allowed:
            return _lossless_container_repair(original, corrected)
        if isinstance(original, dict) and isinstance(corrected, dict):
            if original.keys() != corrected.keys():
                return False
            return all(compare(original[key], corrected[key], (*path, key)) for key in original)
        if isinstance(original, list) and isinstance(corrected, list):
            return len(original) == len(corrected) and all(
                compare(a, b, (*path, index)) for index, (a, b) in enumerate(zip(original, corrected))
            )
        return _same_json(original, corrected)

    return compare(before, after, ())


def _can_repair_format(response, errors, confidence_floor):
    if _has_low_confidence(response, confidence_floor):
        return False
    return all(
        error['validator'] == 'type'
        and isinstance(_value_at(response, error['location']), str)
        and not (error['location'] and error['location'][-1] in PROTECTED_FIELDS)
        for error in errors
    )


async def structured_chat(chat, settings, messages, *, schema, max_tokens, confidence_floor=.60):
    schema_settings = {**settings, '_response_schema': schema}
    response, latency = await chat(schema_settings, messages, max_tokens=max_tokens)
    errors = validation_errors(schema, response)
    audit = {'status': 'valid', 'attempts': [{'response': deepcopy(response), 'validation_errors': errors}]}
    if not errors:
        return response, latency, audit
    # Only lossless container representation can be corrected. Missing facts,
    # enums, source identities and cardinality errors require a new semantic
    # answer, which is outside this format-only boundary.
    if not _can_repair_format(response, errors, confidence_floor):
        detail = json.dumps(errors, ensure_ascii=False)[:700]
        raise ModelContractError('MODEL_RESPONSE_CONTRACT_INVALID: ' + detail, audit)
    correction = [
        *messages,
        {'role': 'assistant', 'content': json.dumps(response, ensure_ascii=False)},
        {'role': 'user', 'content': json.dumps({
            'validation_errors': errors,
            'contract_repair': 'Correct only invalid fields to the supplied schema. Preserve every valid field, claim, identity, confidence and container content. Do not add or remove claims.',
        }, ensure_ascii=False)},
    ]
    corrected, extra = await chat(schema_settings, correction, max_tokens=max_tokens)
    audit['attempts'].append({
        'response': deepcopy(corrected),
        'validation_errors': validation_errors(schema, corrected),
        'request_sha256': hashlib.sha256(json.dumps(correction, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
    })
    if audit['attempts'][-1]['validation_errors'] or not _preserves_content(response, corrected, errors):
        raise ModelContractError('MODEL_RESPONSE_CONTRACT_INVALID: 一次格式纠正后仍不满足合同，或改变了有效业务内容', audit)
    audit['status'] = 'format_corrected'
    return corrected, latency + extra, audit
