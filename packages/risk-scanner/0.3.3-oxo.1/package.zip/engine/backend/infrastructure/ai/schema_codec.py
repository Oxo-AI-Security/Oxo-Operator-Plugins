"""Project JSON Schema into the provider's generation grammar.

The original schema remains the local acceptance contract. Global array
predicates cannot be enforced by this decoder and are validated locally.
"""
from copy import deepcopy

_SCHEMA_MAPS={'properties','$defs','definitions','patternProperties','dependentSchemas'}
_SCHEMA_VALUES={'items','additionalProperties','not','contains','propertyNames','if','then','else'}
_SCHEMA_LISTS={'anyOf','oneOf','allOf','prefixItems'}
_GLOBAL_ARRAY_PREDICATES={'uniqueItems','contains','minContains','maxContains'}


def generation_schema(schema, *, unsupported_keywords=frozenset()):
    if not isinstance(schema,dict):
        return deepcopy(schema)
    result={}
    for key,value in schema.items():
        if key in unsupported_keywords:
            continue
        if schema.get('type')=='array' and key in _GLOBAL_ARRAY_PREDICATES:
            continue
        if key in _SCHEMA_MAPS and isinstance(value,dict):
            result[key]={name:generation_schema(child, unsupported_keywords=unsupported_keywords) for name,child in value.items()}
        elif key in _SCHEMA_LISTS and isinstance(value,list):
            result[key]=[generation_schema(child, unsupported_keywords=unsupported_keywords) for child in value]
        elif key in _SCHEMA_VALUES:
            result[key]=generation_schema(value, unsupported_keywords=unsupported_keywords)
        else:
            result[key]=deepcopy(value)
    if 'const' in result:
        constant=result.pop('const')
        result['enum']=[constant] if 'enum' not in result else [v for v in result['enum'] if v==constant]
    return result
