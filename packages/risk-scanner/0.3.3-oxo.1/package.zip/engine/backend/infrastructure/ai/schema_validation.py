"""Full local JSON Schema validation shared by readiness and stage acceptance."""
from jsonschema import Draft202012Validator


def validation_errors(schema: dict, value) -> list[dict]:
    errors = []
    for error in Draft202012Validator(schema).iter_errors(value):
        location = list(error.absolute_path)
        if error.validator == 'required' and isinstance(error.instance, dict):
            locations = [[*location, key] for key in error.validator_value if key not in error.instance]
        elif error.validator == 'additionalProperties' and isinstance(error.instance, dict):
            locations = [[*location, key] for key in error.instance if key not in error.schema.get('properties', {})]
        else:
            locations = [location]
        errors.extend({
            'location': path, 'validator': error.validator, 'message': error.message[:350],
        } for path in locations)
    return errors
