"""Probe provider constraint enforcement before sending any Skill content."""
import hashlib
import time

from .qwen import QwenError, effective_key, effective_model, model_provider
from .schema_validation import validation_errors
from .structured_output import schema_transport

CAPABILITY_SCHEMA = {
    'type': 'object',
    'properties': {
        'contract_tag': {'type': 'string', 'enum': ['skill-contract-v1']},
        'items': {'type': 'array', 'items': {'type': 'integer'}},
    },
    'required': ['contract_tag', 'items'],
    'additionalProperties': False,
}
_CAPABILITY_CACHE = {}
CACHE_SECONDS = 1800


def _cache_identity(settings: dict) -> tuple:
    return (
        model_provider(settings), effective_model(settings), schema_transport(settings),
        settings.get('base_url'), settings.get('azure_endpoint'), settings.get('azure_deployment'),
        hashlib.sha256((effective_key(settings) or '').encode()).hexdigest(),
    )


def _is_schema_rejection(error: QwenError) -> bool:
    message = str(error).lower()
    return (('http 400' in message or 'http 422' in message)
            and any(name in message for name in ('response_format', 'json_schema', 'tool parameters schema')))


async def probe_contract(chat, settings: dict, *, force: bool = False) -> dict:
    """A reachable endpoint or accepted request is not proof of enforced output."""
    identity = _cache_identity(settings)
    cached = _CAPABILITY_CACHE.get(identity)
    if not force and cached and time.monotonic() - cached[0] < CACHE_SECONDS:
        return {**cached[1], 'cache_hit': True}
    contract_settings = {**settings, '_response_schema': CAPABILITY_SCHEMA}
    messages = [
        {'role': 'system', 'content': 'This is a JSON output-contract capability test.'},
        {'role': 'user', 'content': 'Return exactly {"contract_tag":"wrong-value","items":"not-an-array"} as JSON.'},
    ]
    result = {'format': schema_transport(settings), 'model': effective_model(settings), 'cache_hit': False}
    try:
        response, latency = await chat(contract_settings, messages, max_tokens=800)
        errors = validation_errors(CAPABILITY_SCHEMA, response)
        result.update(supported=not errors, latency_ms=latency, response=response, validation_errors=errors)
    except QwenError as error:
        if not _is_schema_rejection(error):
            raise
        result.update(supported=False, error=str(error)[:500])
    _CAPABILITY_CACHE[identity] = (time.monotonic(), result)
    return result


async def require_contract(chat, settings: dict) -> dict:
    result = await probe_contract(chat, settings)
    if not result['supported']:
        raise QwenError('MODEL_SCHEMA_UNSUPPORTED：当前模型虽可连接，但未执行 Skill 分析所需的结构化合同。请在设置中测试并选择兼容模型。')
    return result
