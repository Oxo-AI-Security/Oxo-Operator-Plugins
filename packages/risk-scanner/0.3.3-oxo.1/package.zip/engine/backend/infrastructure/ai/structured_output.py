"""Provider wire formats for one structured result; no tools are executed here."""
from copy import deepcopy
from urllib.parse import urlsplit

from .schema_codec import generation_schema
from .provider_config import provider_spec

JSON_SCHEMA = 'json_schema'
STRICT_FUNCTION = 'strict_function'
RESPONSES_SCHEMA = 'responses_json_schema'
CONTRACT_FUNCTION = 'skill_contract'
DEEPSEEK_UNSUPPORTED = frozenset({'minLength', 'maxLength', 'minItems', 'maxItems'})


def schema_transport(settings: dict) -> str:
    """Select a documented protocol by endpoint, independently of model or rule."""
    endpoint = urlsplit(str(settings.get('base_url') or provider_spec(settings).base_url))
    if (settings.get('provider') == 'deepseek' and endpoint.hostname == 'api.deepseek.com'
            and endpoint.path.rstrip('/') in {'', '/v1', '/beta'}):
        return RESPONSES_SCHEMA
    if (settings.get('provider') != 'azure_openai'
            and endpoint.hostname == 'api.deepseek.com'
            and endpoint.path.rstrip('/') in {'', '/v1', '/beta'}):
        return STRICT_FUNCTION
    return JSON_SCHEMA


def responses_request(model: str, messages: list[dict], schema: dict) -> dict:
    """Use native text constraints, independently of function-call generation."""
    return {'model': model, 'input': deepcopy(messages), 'reasoning': {'effort': 'none'},
            'temperature': 0, 'text': {'format': {
                'type': 'json_schema', 'name': CONTRACT_FUNCTION, 'strict': True,
                'schema': generation_schema(schema, unsupported_keywords=DEEPSEEK_UNSUPPORTED),
            }}}


def responses_content(payload: dict) -> str:
    """Accept a single completed answer; never run output tools or accept partials."""
    if (not isinstance(payload, dict) or payload.get('object') != 'response'
            or payload.get('status') != 'completed' or payload.get('error')
            or payload.get('incomplete_details')):
        raise ValueError('模型未返回完整 Responses 结构化答案')
    output = payload.get('output')
    if not isinstance(output, list) or len(output) != 1:
        raise ValueError('模型未返回唯一 Responses 消息')
    message = output[0]
    if (not isinstance(message, dict) or message.get('type') != 'message'
            or message.get('role') != 'assistant' or message.get('status') != 'completed'):
        raise ValueError('模型 Responses 消息类型或完成状态无效')
    parts = message.get('content')
    if (not isinstance(parts, list) or len(parts) != 1 or not isinstance(parts[0], dict)
            or parts[0].get('type') != 'output_text' or not isinstance(parts[0].get('text'), str)):
        raise ValueError('模型 Responses 答案不是唯一 JSON 文本')
    return parts[0]['text']


def structured_base_url(base_url: str, transport: str) -> str:
    if transport == STRICT_FUNCTION:
        # This transport is selected only for the official endpoint above.
        return 'https://api.deepseek.com/beta'
    return base_url.rstrip('/')


def apply_schema(body: dict, schema: dict, transport: str) -> dict:
    """Encode a generation contract without altering its local acceptance schema."""
    result = deepcopy(body)
    wire_schema = generation_schema(schema, unsupported_keywords=DEEPSEEK_UNSUPPORTED if transport == STRICT_FUNCTION else frozenset())
    if transport == STRICT_FUNCTION:
        result.pop('response_format', None)
        result['thinking'] = {'type': 'disabled'}
        result['tools'] = [{'type': 'function', 'function': {
            'name': CONTRACT_FUNCTION,
            'description': 'Return the structured analysis result. This function is never executed.',
            'strict': True,
            'parameters': wire_schema,
        }}]
        result['tool_choice'] = {'type': 'function', 'function': {'name': CONTRACT_FUNCTION}}
    else:
        result['response_format'] = {'type': 'json_schema', 'json_schema': {
            'name': CONTRACT_FUNCTION, 'strict': True, 'schema': wire_schema,
        }}
    return result


def completion_content(choice: dict, transport: str) -> str:
    """Read exactly one complete result. Never dispatch a returned function."""
    if not isinstance(choice, dict) or not isinstance(choice.get('message'), dict):
        raise ValueError('模型未返回完整结构化 message')
    if choice.get('finish_reason') == 'length':
        raise ValueError('模型输出被截断（finish_reason=length），请增加输出 token 预算或使用非推理模型')
    if choice.get('finish_reason') == 'content_filter':
        raise ValueError('模型响应被内容筛选阻止，未获得完整 JSON 答案')
    message = choice['message']
    if transport == JSON_SCHEMA:
        if choice.get('finish_reason') != 'stop' or message.get('tool_calls') or message.get('refusal'):
            raise ValueError('模型未返回完整结构化答案')
        content = message.get('content')
        if not isinstance(content, str):
            raise ValueError('模型结构化 content 不是 JSON 文本')
        return content

    calls = message.get('tool_calls') or []
    if (not isinstance(calls, list) or choice.get('finish_reason') != 'tool_calls' or len(calls) != 1
            or message.get('content') not in (None, '') or message.get('refusal')):
        raise ValueError('模型未返回唯一完整的结构化函数结果')
    call = calls[0]
    if not isinstance(call, dict) or not isinstance(call.get('function'), dict):
        raise ValueError('模型结构化函数结果缺少完整身份')
    function = call['function']
    if call.get('type') != 'function' or function.get('name') != CONTRACT_FUNCTION:
        raise ValueError('模型结构化函数身份不匹配')
    arguments = function.get('arguments')
    if not isinstance(arguments, str):
        raise ValueError('模型结构化函数 arguments 不是 JSON 文本')
    return arguments
