"""Model service defaults shared by API validation, persistence and transport."""
from dataclasses import dataclass
from typing import Literal

ProviderName = Literal['openai_compatible', 'azure_openai', 'deepseek']
DEFAULT_PROVIDER = 'openai_compatible'
AZURE_PROVIDER = 'azure_openai'
DEEPSEEK_PROVIDER = 'deepseek'


@dataclass(frozen=True)
class ProviderSpec:
    base_url: str
    default_model: str
    key_environment: str
    models: tuple[str, ...]
    docs_url: str


PROVIDERS = {
    DEFAULT_PROVIDER: ProviderSpec(
        'https://dashscope.aliyuncs.com/compatible-mode/v1', 'qwen-plus', 'DASHSCOPE_API_KEY',
        ('qwen-plus', 'qwen-max', 'qwen-turbo', 'qwen3.7-plus', 'qwen3.7-max'),
        'https://help.aliyun.com/zh/model-studio/qwen-api-reference',
    ),
    AZURE_PROVIDER: ProviderSpec(
        '', 'gpt-4o', 'AZURE_OPENAI_API_KEY', (),
        'https://learn.microsoft.com/azure/foundry/openai/how-to/chatgpt',
    ),
    DEEPSEEK_PROVIDER: ProviderSpec(
        'https://api.deepseek.com', 'deepseek-flash', 'DEEPSEEK_API_KEY',
        ('deepseek-flash', 'deepseek-v4-pro'), 'https://api-docs.deepseek.com/',
    ),
}
DEFAULT_BASE_URL = PROVIDERS[DEFAULT_PROVIDER].base_url


def model_provider(settings: dict) -> str:
    provider = str(settings.get('provider') or DEFAULT_PROVIDER)
    return provider if provider in PROVIDERS else DEFAULT_PROVIDER


def provider_spec(settings: dict) -> ProviderSpec:
    return PROVIDERS[model_provider(settings)]


def public_provider_options() -> list[dict]:
    return [{
        'provider': name, 'base_url': spec.base_url, 'default_model': spec.default_model,
        'models': list(spec.models), 'docs_url': spec.docs_url, 'key_environment': spec.key_environment,
    } for name, spec in PROVIDERS.items()]
