"""AI provider adapters."""
