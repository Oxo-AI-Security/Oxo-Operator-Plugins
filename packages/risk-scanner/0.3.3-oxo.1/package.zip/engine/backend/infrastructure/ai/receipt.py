"""Credential-free fingerprints for comparing actual provider requests/replies."""
import hashlib
import json


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


class ModelReply(dict):
    def __init__(self, value, receipt):
        super().__init__(value)
        self.receipt = receipt


def provider_receipt(url, body, payload, response):
    return {'request_sha256': digest({'url':url, 'body':body}),
        'response_sha256': digest(payload), 'requested_model':body.get('model'),
        'returned_model':payload.get('model'), 'response_id':payload.get('id'),
        'system_fingerprint':payload.get('system_fingerprint'),
        'request_id':response.headers.get('x-request-id'), 'usage':payload.get('usage'),
        'finish_reasons':[choice.get('finish_reason') for choice in payload.get('choices', [])]
                         or [payload.get('status')]}
