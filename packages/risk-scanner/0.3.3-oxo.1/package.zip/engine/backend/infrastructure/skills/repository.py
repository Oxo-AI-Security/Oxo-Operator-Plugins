"""Managed on-disk storage for uploaded AI Skill packages."""

from __future__ import annotations

import base64
import shutil
from pathlib import Path, PurePosixPath
from typing import Any

from ..persistence.database import DEFAULT_DATA_DIR


DEFAULT_MANAGED_SKILLS_DIR = DEFAULT_DATA_DIR / "managed-skills"


class ManagedSkillStorageError(ValueError):
    pass


def _managed_root(root: Path | None = None) -> Path:
    resolved = (root or DEFAULT_MANAGED_SKILLS_DIR).resolve()
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def _safe_skill_dir(skill_id: str, root: Path | None = None) -> Path:
    if not skill_id or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in skill_id):
        raise ManagedSkillStorageError("Invalid managed Skill id")
    managed_root = _managed_root(root)
    target = (managed_root / skill_id).resolve()
    if target.parent != managed_root:
        raise ManagedSkillStorageError("Managed Skill path escaped storage root")
    return target


def _safe_relative_path(value: str) -> Path:
    raw = str(value or "").replace("\\", "/")
    if raw.startswith("/") or (len(raw) >= 2 and raw[1] == ":"):
        raise ManagedSkillStorageError(f"Unsafe Skill file path: {value}")
    normalized = raw.strip("/")
    path = PurePosixPath(normalized)
    if not normalized or path.is_absolute() or ".." in path.parts:
        raise ManagedSkillStorageError(f"Unsafe Skill file path: {value}")
    if any(part in {"", "."} for part in path.parts):
        raise ManagedSkillStorageError(f"Unsafe Skill file path: {value}")
    return Path(*path.parts)


def save_managed_skill_files(
    skill_id: str,
    files: list[dict[str, Any]],
    *,
    root: Path | None = None,
) -> Path:
    """Persist an uploaded package below the product-owned managed directory."""
    target = _safe_skill_dir(skill_id, root)
    if target.exists():
        raise ManagedSkillStorageError("Managed Skill directory already exists")
    target.mkdir(parents=True)
    try:
        for item in files:
            relative = _safe_relative_path(str(item.get("path") or ""))
            destination = (target / relative).resolve()
            if target not in destination.parents:
                raise ManagedSkillStorageError("Skill file escaped managed directory")
            encoded = str(item.get("content_base64") or "")
            try:
                content = base64.b64decode(encoded, validate=True)
            except Exception as exc:
                raise ManagedSkillStorageError(f"Invalid base64 content for {relative.as_posix()}") from exc
            declared_size = int(item.get("size") or len(content))
            if declared_size != len(content):
                raise ManagedSkillStorageError(f"Size mismatch for {relative.as_posix()}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(content)
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        raise
    return target


def load_managed_skill_files(
    skill_id: str,
    *,
    root: Path | None = None,
) -> list[dict[str, Any]]:
    """Load the product-owned copy used for an explicit re-evaluation.

    The scanner accepts the same base64 payload shape as an archive import, so
    no original user path or archive is needed after the first successful
    upload. Only regular files contained by the managed Skill directory are
    returned.
    """
    target = _safe_skill_dir(skill_id, root)
    if not target.is_dir():
        raise ManagedSkillStorageError("Managed Skill package does not exist")

    files: list[dict[str, Any]] = []
    sources = sorted(
        target.rglob("*"),
        key=lambda item: item.relative_to(target).as_posix().casefold(),
    )
    for source in sources:
        if not source.is_file():
            continue
        resolved = source.resolve()
        if target not in resolved.parents:
            raise ManagedSkillStorageError("Managed Skill file escaped storage root")
        content = resolved.read_bytes()
        files.append({
            "path": resolved.relative_to(target).as_posix(),
            "content_base64": base64.b64encode(content).decode("ascii"),
            "size": len(content),
        })
    if not files:
        raise ManagedSkillStorageError("Managed Skill package is empty")
    return files


def delete_managed_skill_files(
    skill_id: str,
    *,
    root: Path | None = None,
) -> bool:
    target = _safe_skill_dir(skill_id, root)
    if not target.exists():
        return False
    shutil.rmtree(target)
    return True
