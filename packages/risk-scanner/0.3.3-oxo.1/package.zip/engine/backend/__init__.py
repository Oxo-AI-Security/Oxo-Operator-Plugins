"""Risk score backend package and legacy import aliases.

The aliases keep integrations such as ``backend.store`` working while all new
code uses the explicit layered paths documented in ``ARCHITECTURE.md``.
"""

import sys

from .api import external_payloads
from .application import skill_scanner
from .domain.mcp import rules, scoring
from .infrastructure.ai import qwen
from .infrastructure.mcp import client as mcp_client
from .infrastructure.persistence import database as persistence
from .infrastructure.persistence import store
from .infrastructure.skills import repository as skill_repository

_LEGACY_MODULES = {
    "external_payloads": external_payloads,
    "mcp_client": mcp_client,
    "persistence": persistence,
    "qwen": qwen,
    "rules": rules,
    "scoring": scoring,
    "skill_repository": skill_repository,
    "skill_scanner": skill_scanner,
    "store": store,
}

for _name, _module in _LEGACY_MODULES.items():
    sys.modules[f"{__name__}.{_name}"] = _module
