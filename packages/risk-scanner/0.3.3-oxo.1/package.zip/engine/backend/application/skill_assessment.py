"""One assessment boundary shared by extraction, review and rule mapping."""

ASSESSMENT_SUBJECT = {
    'actor': 'runtime_agent',
    'basis': 'follows_declared_skill_procedure',
    'runtime_environment': 'not_assessed',
    'scope_unit': 'independently_selected_top_level_resource',
}
