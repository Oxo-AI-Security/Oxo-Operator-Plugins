"""Source contracts for contested baselines and caller-controlled execution.

These checks cannot create a rule, assign confidence or calculate a score.
"""
from .skill_evidence import SourceIndex
from ..domain.semantic import supported_confidence


def baseline_alternatives(files, proposals, verified):
    """Preserve grounded discarded hypotheses; never promote them to findings."""
    baselines = {c.get('rule_id') for c in verified} & {'CAP-001', 'EXP-001'}
    if not baselines:
        return []
    sources = SourceIndex(files)
    present = {c.get('rule_id') for c in verified}
    alternatives = []
    for candidate in proposals:
        rule = candidate['rule_id']
        if rule in present or rule.split('-')[0]+'-001' not in baselines or not supported_confidence(candidate.get('confidence')):
            continue
        path, quote = sources.resolve(candidate.get('path', ''), candidate.get('evidence', ''), candidate.get('evidence_id'))
        if not path:
            continue
        alternatives.append({'hypothesis_id': str(len(alternatives)), 'rule_id': rule,
            'evidence': {'path': path, 'quote': quote}, 'rationale': candidate.get('rationale', ''),
            'reference_context': sources.reference_context(path), 'status': 'unaccepted_hypothesis'})
    return alternatives


def baseline_proof_error(rule, alternatives, response):
    relevant = [a for a in alternatives if a['rule_id'].split('-')[0] == rule.split('-')[0]]
    if not relevant:
        return None
    decisions = response.get('baseline_alternative_decisions')
    if not isinstance(decisions, list):
        return 'baseline_alternatives_not_reviewed'
    by_id = {}
    for row in decisions:
        if not isinstance(row, dict) or row.get('hypothesis_id') in by_id:
            return 'baseline_alternative_decisions_invalid'
        by_id[row.get('hypothesis_id')] = row
    for alternative in relevant:
        row = by_id.get(alternative['hypothesis_id']) or {}
        if row.get('excluded') is not True or not supported_confidence(row.get('confidence')) or not str(row.get('source_reason') or '').strip():
            return 'baseline_conflicts_with_unresolved_source_hypothesis'
    return None


def _claim_identity(candidate: dict) -> tuple:
    return candidate['rule_id'], tuple(sorted(candidate.get('operation_ids') or []))


def _prior_rejections(proposal: dict, reviews: list[dict]) -> list[dict]:
    rejections = [
        {'outcome': 'excluded', 'rationale': candidate.get('rationale', '')}
        for review in reviews
        for candidate in review.get('rejected_candidates', [])
        if candidate.get('rule_id') == proposal['rule_id']
    ]
    return rejections or [{
        'outcome': 'not_returned',
        'rationale': 'The independent review did not return this operational claim.',
    }]


def retain_source_hypotheses(proposals: list[dict], verified: list[dict], reviews: list[dict]):
    """Preserve disputed claims for final review; never approve or score them."""
    seen = {_claim_identity(candidate) for candidate in verified}
    retained = []
    for proposal in proposals:
        key = _claim_identity(proposal)
        if key in seen:
            continue
        retained.append({**proposal, 'prior_semantic_reviews': _prior_rejections(proposal, reviews)})
        seen.add(key)
    return [*verified, *retained], retained

