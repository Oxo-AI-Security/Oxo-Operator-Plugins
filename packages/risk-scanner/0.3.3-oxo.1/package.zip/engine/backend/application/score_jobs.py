"""Asynchronous scoring job lifecycle and result aggregation."""

from __future__ import annotations

import uuid
import asyncio
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from typing import Any, Literal

ScoreKind = Literal["mcp", "skill"]


class ScoreJobFailure(RuntimeError):
    """A public, stable failure code for an asynchronous scoring job."""

    def __init__(self, code: str, message: str, *, diagnostics: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.diagnostics = diagnostics


def create_score_job(
    store: Any,
    kind: ScoreKind,
    *,
    client_reference: str | None,
    input_summary: dict[str, Any],
) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    request_id = f"{kind}-{uuid.uuid4().hex}"
    job = {
        "request_id": request_id,
        "kind": kind,
        "status": "queued",
        "submitted_at": now,
        "started_at": None,
        "completed_at": None,
        "client_reference": client_reference,
        "input_summary": input_summary,
        "result": None,
        "error": None,
    }
    store.create_score_job(job)
    return job


def accepted_job(job: dict[str, Any]) -> dict[str, Any]:
    kind = job["kind"]
    return {
        "request_id": job["request_id"],
        "kind": kind,
        "status": "queued",
        "submitted_at": job["submitted_at"],
        "client_reference": job.get("client_reference"),
        "result_url": f"/api/v1/score/{kind}/requests/{job['request_id']}",
    }


async def run_mcp_score_job(
    store: Any,
    request_id: str,
    server: dict[str, Any],
    use_llm: bool,
    *,
    score_snapshot: Callable[..., Awaitable[dict[str, Any]]],
    serialize_result: Callable[[dict[str, Any]], dict[str, Any]],
) -> None:
    if not store.claim_score_job(request_id):
        return
    try:
        result = await score_snapshot(server, use_llm=use_llm)
        public_result = serialize_result(result)
        store.upsert_server(public_result)
        store.update_score_job(
            request_id,
            status="succeeded",
            completed_at=datetime.now(timezone.utc).isoformat(),
            result=public_result,
            error=None,
        )
    except asyncio.CancelledError:
        _cancelled_job(store, request_id)
        raise
    except Exception as exc:
        store.update_score_job(
            request_id,
            status="failed",
            completed_at=datetime.now(timezone.utc).isoformat(),
            result=None,
            error={"code": getattr(exc, "code", "MCP_SCORING_FAILED"), "message": str(exc)[:1_000]},
        )


async def run_skill_score_job(
    store: Any,
    request_id: str,
    packages: list[dict[str, Any]],
    use_llm: bool,
    *,
    scan_package: Callable[..., Awaitable[dict[str, Any]]],
) -> None:
    if not store.claim_score_job(request_id):
        return
    results = []
    failures = []
    for package in packages:
        try:
            scan = await scan_package(
                package["name"],
                package["files"],
                store.model_settings,
                use_llm=use_llm,
                trigger="external_api",
            )
            scan["package_root"] = package["root"]
            scan["skill_anchor"] = package["anchor"]
            results.append(scan)
        except asyncio.CancelledError:
            _cancelled_job(store, request_id)
            raise
        except Exception as exc:
            failures.append({
                "name": package.get("name"),
                "package_root": package.get("root"),
                "code": getattr(exc, "code", "SKILL_SCORING_FAILED"),
                "message": str(exc)[:1_000],
                "analysis": getattr(exc, "diagnostics", None),
            })
    if results:
        maximum = max((item.get("effective_risk", 0) for item in results), default=0)
        result = {
            "requested_package_count": len(packages),
            "package_count": len(results),
            "failed_count": len(failures),
            "failures": failures,
            "summary": {
                "maximum_effective_risk": maximum,
                "highest_risk_skills": [
                    item["name"] for item in results if item.get("effective_risk", 0) == maximum
                ],
                "total_findings": sum(len(item.get("findings", [])) for item in results),
            },
            "skills": results,
        }
        store.update_score_job(
            request_id,
            status="succeeded",
            completed_at=datetime.now(timezone.utc).isoformat(),
            result=result,
            error=None,
        )
    else:
        store.update_score_job(
            request_id,
            status="failed",
            completed_at=datetime.now(timezone.utc).isoformat(),
            result=None,
            error={
                "code": "SKILL_SCORING_FAILED",
                "message": "All Skill packages failed semantic scoring.",
                "failures": failures,
            },
        )


def _cancelled_job(store: Any, request_id: str) -> None:
    store.update_score_job(
        request_id, status="failed", completed_at=datetime.now(timezone.utc).isoformat(),
        result=None, error={"code": "SCORING_CANCELLED", "message": "评分任务已中断，未形成完整结果。"},
    )
