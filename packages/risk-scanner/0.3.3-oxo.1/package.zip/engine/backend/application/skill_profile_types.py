"""Strict shared fact-wire model configuration."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class WireModel(BaseModel):
    model_config=ConfigDict(extra='forbid',strict=True,allow_inf_nan=False)


class Invocation(WireModel):
    kind: Literal['program', 'tool_or_api']
    program: str = Field(min_length=1)
    origin: Literal['task', 'packaged', 'workspace', 'service_content', 'public_content', 'unknown']
    control: Literal['fixed_data', 'caller_executable', 'agent_selected_program', 'unknown'] = Field(
        description='Control of the invoked executable program/code/selector, independently of its ordinary data arguments.')
    reach: list[Literal['fixed', 'single_object', 'multiple_objects', 'free_target', 'privileged', 'automatic', 'unknown']]
    evidence_id: str = Field(pattern=r'^E\d+-\d+$', description='Source of the invocation/sink.')
    input_evidence_id: str = Field(pattern=r'^E\d+-\d+$', description='Source of the executable value or selector; a fixed literal may cite the invocation itself.')
    value_path: str = Field(min_length=1, description='Executable input/selector -> transformations -> invocation argument. A section location is not a value path.')


class OperationFacts(WireModel):
    operation_id: str = Field(min_length=1)
    invocation: Invocation | None
    actor: Literal['runtime_agent', 'human', 'inert'] = Field(
        description='Operative Skill procedures target the fixed assessment_subject. Human or inert requires source context explicitly assigning the action to a person or quoting it as nonoperative data.')
    action: Literal['transform', 'interact', 'read', 'create', 'modify', 'delete', 'send', 'install',
                    'permissions', 'transaction', 'interface', 'production', 'schedule', 'instruction_priority', 'other'] = Field(
        description='Effect on resource, not the verb alone. transform edits/generates/returns task content; interact asks, waits for confirmation, or presents task/packaged content in the current task conversation, without external transport or UI control. create/modify/delete require a declared persistent resource effect (filesystem or service state). Content editing alone does not establish a persistent write. Record distinct resource effects separately. interface controls a browser/desktop. Program execution belongs exclusively to invocation.')
    resource: str = Field(min_length=1, description='The entity read, changed, sent or executed by this effect, distinct from the tool performing it.')
    origin: Literal['task', 'packaged', 'workspace', 'service_content', 'public_content', 'secret_store', 'unknown'] = Field(
        description='Origin of the affected resource/content, not origin of its invocation syntax. Independent of authentication. service_content includes internal/private API, document, email and issue content.')
    control: Literal['fixed_data', 'caller_data', 'caller_executable', 'agent_selected_program', 'unknown'] = Field(
        description='Control of the operational value. Caller initiating a task is different from supplying executable program/code.')
    content_use: Literal['data', 'executable', 'higher_priority_instruction', 'none', 'unknown'] = Field(
        description='Use of content: factual summarization is data; instruction priority means overriding a trusted authority.')
    reach: list[Literal['fixed', 'single_object', 'multiple_objects', 'free_target', 'privileged', 'automatic', 'unknown']] = Field(
        description='Scope of affected resources, not the number of invocations. Preserve full source-declared target selection and fan-out.')
    condition: str = Field(min_length=1)
    entry_evidence_id: str = Field(pattern=r'^E\d+-\d+$')
    action_evidence_id: str = Field(pattern=r'^E\d+-\d+$')
    input_evidence_id: str | None
    value_path: str = Field(min_length=1)


class Operation(OperationFacts):
    confidence: float = Field(ge=0, le=1)


CoverageRole = Literal['procedure', 'implementation', 'data', 'license', 'unknown']


class Discovery(WireModel):
    prompt_version: str
    rule_set_version: str
    operations: list[OperationFacts]
    coverage: dict[str, CoverageRole]
    unknowns: list[str]


def discovery_schema(paths: list[str]) -> dict:
    """Bind known file identities before generation; the model assigns roles only."""
    schema = Discovery.model_json_schema()
    role_schema = schema['properties']['coverage']['additionalProperties']
    schema['properties']['coverage'] = {
        'type': 'object', 'properties': {path: role_schema for path in paths},
        'required': paths, 'additionalProperties': False,
    }
    return schema


class ReviewDecision(WireModel):
    operation_id: str
    valid: bool
    confidence: float = Field(ge=0, le=1)
    source_reason: str = Field(min_length=1)


class Review(WireModel):
    prompt_version: str
    rule_set_version: str
    decisions: list[ReviewDecision]
    additional_operations: list[Operation]
    coverage_complete: bool
    unknowns: list[str]


