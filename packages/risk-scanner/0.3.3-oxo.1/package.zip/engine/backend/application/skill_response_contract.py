"""Value-free response schemas for existing Skill passes.

These guide generation; they never replace exact-source or semantic validation.
In particular a numeric example is not a confidence value to copy.
"""
from copy import deepcopy
from .identity_contract import keyed_records, identity_records

TEXT = {"type": "string", "minLength": 1}
CONFIDENCE = {"type": "number", "minimum": 0, "maximum": 1,
              "description": "Your actual semantic certainty, not a placeholder; uncertainty must remain low/unknown."}

def obj(properties, required=None):
    return {"type": "object", "properties": properties,
            "required": list(properties) if required is None else required, "additionalProperties": False}

def array(item):
    return {"type": "array", "items": item}


def catalog_verdicts(candidate, rule_id, identities):
    """Every catalog identity requires an explicit match, exclusion or unknown."""
    row = deepcopy(candidate)
    row['properties'].update(verdict={'type':'string','enum':['matched','excluded','unknown']}, exclusion_analysis=TEXT)
    row['properties']['evidence_id'] = {'anyOf':[row['properties']['evidence_id'], {'type':'null'}]}
    if 'operation_ids' in row['properties']:
        row['properties']['operation_ids']['minItems'] = 0
    row['required'].extend(['verdict','exclusion_analysis'])
    return keyed_records(row, identities, 'rule_id')


def response_schema(request):
    versions = {key: {"type": "string", "const": request[key]}
                for key in ("prompt_version", "rule_set_version") if key in request}
    ids = [item["rule_id"] for item in request.get("rule_catalog", [])]
    rule_id = {"type": "string", **({"enum": ids} if ids else {})}
    evidence_id = {"type": "string", "pattern": r"^E[0-9]+-[0-9]+$",
                   "description": "Exact ID of a nonblank source block stating the action. Never select an empty line."}
    candidate = obj({"rule_id": rule_id, "confidence": CONFIDENCE,
                     "evidence_id": evidence_id, "rationale": TEXT})
    operation_ids = [o['operation_id'] for o in (request.get('validated_operation_profile') or {}).get('operations',[])]
    if request.get('validated_operation_profile') is not None:
        candidate['properties']['operation_ids'] = {'type':'array','minItems':1,'uniqueItems':True,
            'items':{'type':'string','enum':operation_ids}}
        candidate['required'].append('operation_ids')
        if (request.get('analysis_family') or request.get('verification_family'))=='integrity':
            candidate['properties']['operation_ids']={**candidate['properties']['operation_ids'],'minItems':0}
    rejects = array(obj({"rule_id": {"type": "string"}, "rationale": TEXT}))
    extras = {"rejected_candidates": rejects, "unknowns": array({"type": "string"})}
    if "semantic_adjudication" in request or "flow_adjudication" in request:
        identities = [item['candidate_id'] for item in request.get('candidates', []) if 'candidate_id' in item]
        decision = obj({"candidate_id": {"type": "string", **({"enum": identities} if identities else {})},
                        "valid": {"type": "boolean"}, "confidence": CONFIDENCE,
                        "rationale": TEXT, "exclusion_analysis": TEXT,
                        "source_reason":{**TEXT,'description':'Source-based final resolution, including any supplied prior exclusion or omission. This is the only final verdict and confidence for the identity.'}})
        schema = obj({**versions, "candidate_decisions": keyed_records(decision, identities, 'candidate_id')})
        disputed=[c['candidate_id'] for c in request.get('candidates',[]) if c.get('prior_semantic_reviews')]
        if request.get('baseline_alternatives'):
            schema['properties']['baseline_alternative_decisions'] = keyed_records(obj({
                'hypothesis_id': TEXT, 'excluded': {'type': 'boolean'}, 'confidence': CONFIDENCE, 'source_reason': TEXT}),
                [row['hypothesis_id'] for row in request['baseline_alternatives']], 'hypothesis_id')
            schema['required'].append('baseline_alternative_decisions')
    elif "candidate_rule_ids" in request:
        participant = obj({"path": TEXT, "role": TEXT, "evidence": TEXT})
        match = obj({"rule_id": {"type": "string", "enum": request["candidate_rule_ids"]},
                     "confidence": CONFIDENCE, "rationale": TEXT, "data_path": TEXT,
                     "participants": {**array(participant), "minItems": 1}})
        schema = obj({**versions, "flow_rule_matches": array(match), **extras})
    elif "missing_axis" in request:
        schema = obj({**versions, "candidate": {"anyOf": [candidate, {"type": "null"}]},
                      "unknown": {"type": ["string", "null"]}})
    elif "verification_family" in request:
        if request['verification_family'] in {'capability', 'exposure'}:
            schema = obj({**versions, 'rule_decisions':catalog_verdicts(candidate, rule_id, ids)})
        else:
            schema = obj({**versions, "verified_candidates": array(candidate),
                          "rejected_candidates": rejects, "incomplete_axes": array({"type": "string"})})
    elif "analysis_family" in request:
        fact_ids = [item["fact_id"] for item in request.get("behavior_fact_catalog", [])]
        fact = obj({"fact_id": {"type": "string", **({"enum": fact_ids} if fact_ids else {})},
                    "confidence": CONFIDENCE, "evidence_id": evidence_id, "rationale": TEXT})
        if request.get('validated_operation_profile') is not None:
            fact['properties']['operation_ids'] = {**candidate['properties']['operation_ids'],'minItems':1}
            fact['required'].append('operation_ids')
        schema = obj({**versions, "candidates": array(candidate), "behavior_facts": array(fact), **extras})
    else:
        return None
    return deepcopy(schema)


def decode_decisions(response: dict, request: dict) -> dict:
    """Restore domain collections after schema validation, without default votes."""
    decoded = deepcopy(response)
    for field, identity in [('candidate_decisions','candidate_id'), ('baseline_alternative_decisions','hypothesis_id')]:
        if isinstance(decoded.get(field), dict):
            decoded[field] = identity_records(decoded[field], identity)
    if 'rule_decisions' in decoded:
        rows = identity_records(decoded.pop('rule_decisions'), 'rule_id')
        for row in rows:
            if row['verdict']=='matched':
                if not row.get('evidence_id'):
                    raise ValueError('Matched rule requires exact source identity')
                if request.get('validated_operation_profile') is not None and not row.get('operation_ids'):
                    raise ValueError('Matched operational rule requires operation identities')
        decoded['verified_candidates'] = [row for row in rows if row['verdict']=='matched']
        decoded['rejected_candidates'] = [row for row in rows if row['verdict']=='excluded']
        decoded['incomplete_axes'] = [row['rule_id'] + ': ' + row['rationale'] for row in rows if row['verdict']=='unknown']
    return decoded
