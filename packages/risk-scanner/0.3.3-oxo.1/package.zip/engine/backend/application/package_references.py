"""Exact package references, including Markdown directory/member lists.

Edges prove a reference only. Semantic review still decides whether it is active.
"""
import posixpath
import re


def references(source: str, text: str, paths: set[str]) -> list[dict]:
    edges = {}
    directory = posixpath.dirname(source) or '.'
    for target in sorted(paths - {source}):
        relative = posixpath.relpath(target, directory)
        match = re.search(r'(?<![\w./-])(?:\./)?' + re.escape(relative) + r'(?![\w./-])', text)
        if match:
            edges[target] = {'path': source, 'target_path': target,
                'line': text.count('\n', 0, match.start()) + 1, 'quote': match.group(),
                'kind': 'unclassified_package_reference'}
    # Resolve only explicitly listed members under a directory list item.
    # A directory mention never links its entire subtree or a bare basename elsewhere.
    stack = []
    lines = text.splitlines(keepends=True)
    fenced = False
    for number, line in enumerate(lines, 1):
        if re.match(r'^\s*(```|~~~)', line):
            fenced = not fenced
        if fenced:
            continue
        item = re.match(r'^(\s*)[-*+]\s+(.*)$', line)
        if not item:
            if line.strip():
                stack = []
            continue
        indent = len(item[1].expandtabs(4))
        while stack and stack[-1][0] >= indent:
            stack.pop()
        tokens = re.findall(r'`([^`]+)`|\*\*([^*]+)\*\*', item[2])
        for parts in tokens:
            token = next(value for value in parts if value).strip()
            base = stack[-1][1] if stack else directory
            target = posixpath.normpath(posixpath.join(base, token))
            if token.endswith('/'):
                stack.append((indent, target, number, line))
            elif stack and target in paths and target != source:
                parent = stack[-1]
                edges.setdefault(target, {'path': source, 'target_path': target, 'line': parent[2],
                    'quote': ''.join(lines[parent[2]-1:number]),
                    'kind': 'unclassified_scoped_member_reference'})
    return list(edges.values())
