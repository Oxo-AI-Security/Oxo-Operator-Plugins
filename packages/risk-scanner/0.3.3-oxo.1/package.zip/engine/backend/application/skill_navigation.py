"""Syntactic source navigation for reviewers, never rule or reachability proof.

Python's standard AST exposes actual calls separately from docstring examples.
All original package text remains available, including unsupported syntax and
files whose optional navigation index exceeds the display budget.
"""
import ast
import json


MAX_NAVIGATION_CHARACTERS = 12_000


def python_call_navigation(sources):
    records = []
    used = 0
    line_ids = {}
    for block in sources.catalog:
        if block['text'].strip():
            location = (block['path'], block['start_line'])
            line_ids[location] = block['evidence_id'] if location not in line_ids else None
    for document in sources.documents:
        path = document['path']
        if not path.lower().endswith('.py'):
            continue
        text = sources.texts[path]
        try:
            tree = ast.parse(text)
        except (SyntaxError, ValueError, RecursionError):
            records.append({'path': path, 'status': 'syntax_unavailable_review_original_source'})
            continue
        calls = []
        class Calls(ast.NodeVisitor):
            scope = '<module>'

            def visit_FunctionDef(self, node):
                previous = self.scope
                self.scope = node.name
                self.generic_visit(node)
                self.scope = previous

            visit_AsyncFunctionDef = visit_FunctionDef

            def visit_Call(self, node):
                try:
                    target = ast.unparse(node.func)
                    arguments = ', '.join([ast.unparse(arg) for arg in node.args] +
                                          [f'{kw.arg}={ast.unparse(kw.value)}' if kw.arg else f'**{ast.unparse(kw.value)}'
                                           for kw in node.keywords])
                except RecursionError:
                    target, arguments = '<inspect source>', '<inspect source>'
                calls.append({'evidence_id': line_ids.get((path, node.lineno)), 'line': node.lineno,
                              'scope': self.scope, 'call': target, 'arguments': arguments})
                self.generic_visit(node)
        try:
            Calls().visit(tree)
        except RecursionError:
            records.append({'path': path, 'status': 'syntax_unavailable_review_original_source'})
            continue
        record = {'path': path, 'status': 'syntactic_calls_only', 'calls': calls}
        size = len(json.dumps(record, ensure_ascii=False))
        if used + size <= MAX_NAVIGATION_CHARACTERS:
            records.append(record)
            used += size
        else:
            records.append({'path': path, 'status': 'navigation_not_attached_budget_review_original_source',
                            'call_count': len(calls)})
    return {'kind': 'syntactic_navigation_not_semantic_evidence', 'language': 'python', 'files': records}
