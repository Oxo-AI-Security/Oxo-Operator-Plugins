"""Lossless flat wire representation of the existing typed operation contract.

Generation owns semantic facts. This codec only moves invocation fields between
explicitly prefixed keys and the internal object; it never parses or repairs JSON.
"""
from copy import deepcopy
from .skill_profile_types import Invocation, Operation, OperationFacts
from .operation_scope import SCOPE_FIELDS, decode_scope


def profile_wire_schema(schema: dict) -> dict:
    """Derive both flat variants from the domain types, without duplicate policy."""
    wire = deepcopy(schema)
    operation_key = 'Operation' if 'Operation' in wire['$defs'] else 'OperationFacts'
    operation = wire['$defs'][operation_key]
    invocation = wire['$defs']['Invocation']
    effect_fields = {key: value for key, value in operation['properties'].items() if key not in {'invocation', 'reach'}}
    effect_fields.update(deepcopy(SCOPE_FIELDS))
    required_effects = list(effect_fields)
    call_fields = {f'invocation_{key}': value for key, value in invocation['properties'].items() if key != 'reach'}
    call_fields.update({f'invocation_{key}':deepcopy(value) for key,value in SCOPE_FIELDS.items()})
    variants = []
    for fields in ({'invocation_kind': {'type': 'string', 'enum': ['none']}}, call_fields):
        variants.append({'type': 'object', 'properties': {**effect_fields, **fields},
                         'required': [*required_effects, *fields], 'additionalProperties': False})
    wire['$defs'][operation_key] = {'anyOf': variants}
    return wire


def decode_operations(records: list[dict], *, reviewed: bool = True) -> list[dict]:
    """Restore domain objects only after the flat response passed its schema."""
    result = []
    for record in records:
        effect = deepcopy(record)
        effect['reach'] = decode_scope(effect)
        kind = effect.pop('invocation_kind')
        if kind == 'none':
            effect['invocation'] = None
        else:
            call = {'kind': kind}
            for key in Invocation.model_fields:
                if key not in {'kind', 'reach'}:
                    call[key] = effect.pop(f'invocation_{key}')
            call['reach'] = decode_scope(effect, 'invocation_')
            effect['invocation'] = call
        model = Operation if reviewed else OperationFacts
        result.append(model.model_validate(effect).model_dump())
    return result
