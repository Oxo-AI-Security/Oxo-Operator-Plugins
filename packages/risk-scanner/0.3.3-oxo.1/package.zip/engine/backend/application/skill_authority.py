"""Source-backed authority facts for resource/session control operations."""
import json
from typing import Literal
from pydantic import Field
from .skill_profile_types import WireModel
from ..domain.semantic import supported_confidence


class AuthorityDecision(WireModel):
    operation_id: str
    authentication: Literal['established', 'absent', 'unknown']
    privilege: Literal['ordinary', 'privileged', 'unknown']
    evidence_ids: list[str]
    confidence: float = Field(ge=0, le=1)
    source_reason: str = Field(min_length=1)


class AuthorityReview(WireModel):
    prompt_version: str
    rule_set_version: str
    decisions: list[AuthorityDecision]


def _validate_authority_evidence(decisions, sources, error_type):
    for decision in decisions.values():
        if any(not sources.resolve('', '', identifier)[0] for identifier in decision.evidence_ids):
            raise error_type('Skill 资源权限复核引用不属于原始源码')
        if decision.authentication == 'established' and not decision.evidence_ids:
            raise error_type('Skill 已认证会话声明缺少原始证据')


async def reviewed_authority(call, settings, operations, sources, versions, error_type):
    selected = [operation for operation in operations
                if operation['actor'] == 'runtime_agent'
                and operation['action'] in {'interface', 'permissions', 'production'}]
    if not selected:
        return operations, None, 0
    request = {
        **versions, 'authority_review': True,
        'operations': [{key: value for key, value in operation.items() if key not in {'source_evidence', 'review'}}
                       for operation in selected],
        'response_schema': AuthorityReview.model_json_schema(),
        'package_excerpts': [{'path': path, 'content': text} for path, text in sources.texts.items()],
    }
    messages = [
        {'role': 'system', 'content':
            'Review authentication and privilege of each supplied controlled resource/session against the complete source. '
            'Established authentication needs explicit login, credentials, or reuse of an authenticated session. '
            'Program execution, user intent and interface control alone do not establish session authentication or privilege. '
            'Return one source-grounded decision per operation; preserve unknowns and actual confidence. '
            'Do not classify rules or calculate risk. Return response_schema JSON.'},
        {'role': 'user', 'content': json.dumps(request, ensure_ascii=False)},
    ]
    raw, latency = await call(settings, messages, max_tokens=2500)
    review = AuthorityReview.model_validate(raw)
    if any(raw.get(key) != value for key, value in versions.items()):
        raise error_type('Skill 资源权限复核版本不匹配')
    decisions = {decision.operation_id: decision for decision in review.decisions}
    if len(decisions) != len(review.decisions) or set(decisions) != {operation['operation_id'] for operation in selected}:
        raise error_type('Skill 资源权限复核身份不完整或重复')
    _validate_authority_evidence(decisions, sources, error_type)
    result = []
    for operation in operations:
        decision = decisions.get(operation['operation_id'])
        if decision is None:
            result.append(operation)
            continue
        result.append({
            **operation,
            'authenticated_session_proven': decision.authentication == 'established' and supported_confidence(decision.confidence),
            'authority_review': decision.model_dump(),
        })
    return result, raw, latency
