"""Shared identity and decision validation for independent source reviews."""


def records_by_identity(records, expected, identity, error_type):
    """Require a one-to-one decision set before inspecting semantic outcomes."""
    if not isinstance(records, list):
        raise error_type('Skill 最终语义复核未返回候选决策')
    by_id = {}
    for record in records:
        if not isinstance(record, dict) or str(record.get(identity)) in by_id:
            raise error_type('Skill 最终语义复核候选身份重复或无效')
        by_id[str(record.get(identity))] = record
    if set(by_id) != set(expected):
        raise error_type('Skill 最终语义复核不完整，未形成完整评分')
    return by_id


def decisions_by_identity(decisions, expected, error_type):
    by_id = records_by_identity(decisions, expected, 'candidate_id', error_type)
    if any(
        not isinstance(decision.get('valid'), bool)
        or not str(decision.get('rationale') or '').strip()
        or not str(decision.get('exclusion_analysis') or '').strip()
        for decision in by_id.values()
    ):
        raise error_type('Skill 最终语义复核缺少有效判定与排除理由')
    return by_id
