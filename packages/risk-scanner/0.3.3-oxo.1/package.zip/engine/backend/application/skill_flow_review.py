"""Independent source-to-sink adjudication; never promote an unproven path."""
import json

from ..domain.semantic import supported_confidence
from .skill_review_contract import decisions_by_identity


def _path_candidates(catalog: list[dict], findings: list[dict], proposal: dict):
    """Assign separate identities to every proposed path and unmatched exclusion."""
    rules = {rule['rule_id']: rule for rule in catalog}
    candidates = []
    findings_by_identity = {}
    for finding, match in zip(findings, proposal['flow_rule_matches']):
        identity = str(len(candidates))
        findings_by_identity[identity] = finding
        candidates.append({
            'candidate_id': identity, **rules[finding['id']],
            'proposed_match': match, 'proposed_exclusion': None,
        })
    matched_rules = {finding['id'] for finding in findings}
    for rule in catalog:
        if rule['rule_id'] in matched_rules:
            continue
        exclusion = next((candidate for candidate in proposal['rejected_candidates']
                          if candidate['rule_id'] == rule['rule_id']), None)
        candidates.append({
            'candidate_id': str(len(candidates)), **rule,
            'proposed_match': None, 'proposed_exclusion': exclusion,
        })
    return candidates, findings_by_identity


def _apply_path_decisions(candidates, findings_by_identity, decisions, error_type):
    accepted = []
    rejected = []
    for candidate in candidates:
        identity = candidate['candidate_id']
        decision = decisions[identity]
        if not supported_confidence(decision.get('confidence')):
            raise error_type('Skill FLOW 最终复核仍不确定，未形成完整评分')
        if not decision['valid']:
            rejected.append({
                'rule_id': candidate['rule_id'],
                'validation_error': 'final_flow_adjudication_rejected', 'decision': decision,
            })
            continue
        if identity not in findings_by_identity:
            raise error_type('Skill FLOW 复核与原路径排除冲突，缺少已验证路径，未形成评分')
        finding = findings_by_identity[identity]
        accepted.append({
            **finding, 'llm_confidence': min(finding['llm_confidence'], decision['confidence']),
            'semantic_adjudication': decision,
        })
    return accepted, rejected


async def review_flow_paths(call, settings, files, catalog, findings, proposal, facts, versions, error_type):
    if len(findings) != len(proposal['flow_rule_matches']):
        raise error_type('Skill FLOW 路径身份不完整')
    candidates, findings_by_identity = _path_candidates(catalog, findings, proposal)
    messages = [
        {'role': 'system', 'content':
            'Independently adjudicate every proposed source-to-sink path against its definition, required roles and complete original source. '
            'Prove actual value-flow joins and activation. Mere access, coexistence, or imagined future actions are insufficient. '
            'A valid path needs all proposed participants and their actual source-to-sink relationship. '
            'An exclusion needs a specific source-grounded explanation. Do not invent a replacement path or evidence. '
            'Return exactly one candidate_decision per identity, actual confidence, rationale and exclusion_analysis, using response_schema. '
            'Do not calculate risk or scores.'},
        {'role': 'user', 'content': json.dumps({
            **versions, 'flow_adjudication': True, 'candidates': candidates,
            'validated_stage1_findings': facts,
            'package_excerpts': [{'path': file['path'], 'content': file['text']} for file in files if file.get('text')],
        }, ensure_ascii=False)},
    ]
    response, latency = await call(settings, messages, max_tokens=3000)
    if any(response.get(key) != value for key, value in versions.items()):
        raise error_type('Skill FLOW 最终复核版本不匹配')
    decisions = decisions_by_identity(response.get('candidate_decisions'),
                                     [candidate['candidate_id'] for candidate in candidates], error_type)
    accepted, rejected = _apply_path_decisions(candidates, findings_by_identity, decisions, error_type)
    return accepted, {'status': 'completed', 'latency_ms': latency, 'raw_response': response, 'rejected': rejected}
