"""Decode wire containers and enforce the original semantic acceptance contract."""
import json
from .identity_wire import restore_identity_maps
from .skill_response_contract import decode_decisions
from ..infrastructure.ai.schema_validation import validation_errors


def decode_skill_response(response, request):
    response = restore_identity_maps(response, request['_identity_layout'])
    if request['_acceptance_schema']:
        errors = validation_errors(request['_acceptance_schema'], response)
        if errors:
            raise ValueError('MODEL_RESPONSE_CONTRACT_INVALID: ' + json.dumps(errors,ensure_ascii=False)[:700])
    return decode_decisions(response, request)
