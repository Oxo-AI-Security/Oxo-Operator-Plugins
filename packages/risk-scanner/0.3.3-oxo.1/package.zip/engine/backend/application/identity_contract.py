"""Required identity-keyed records; no missing decisions or default verdicts."""
from copy import deepcopy


def keyed_records(item: dict, identities: list[str], identity_field: str) -> dict:
    if len(set(identities)) != len(identities):
        raise ValueError('Duplicate contract identity')
    item = deepcopy(item)
    item['properties'].pop(identity_field, None)
    item['required'] = [key for key in item['required'] if key != identity_field]
    return {'type': 'object', 'properties': {key: deepcopy(item) for key in identities},
            'required': identities, 'additionalProperties': False}


def identity_records(values: dict, identity_field: str) -> list[dict]:
    if not isinstance(values, dict) or any(not isinstance(row, dict) or identity_field in row for row in values.values()):
        raise ValueError('Invalid identity-keyed decision records')
    return [{identity_field: key, **row} for key, row in values.items()]
