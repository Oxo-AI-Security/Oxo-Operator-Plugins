"""Transport known identity maps as homogeneous records, then enforce exact coverage.

Providers generate arrays more reliably than dynamic nested object keys. This is
a structural codec: every original required identity and field is still checked.
"""
from copy import deepcopy

IDENTITIES = {'decisions':'operation_id', 'candidate_decisions':'candidate_id',
              'baseline_alternative_decisions':'hypothesis_id', 'rule_decisions':'rule_id'}


def identity_wire_schema(schema):
    wire = deepcopy(schema)
    layout = {}
    for field, identity_field in IDENTITIES.items():
        contract = wire.get('properties', {}).get(field)
        if not contract or contract.get('type') != 'object':
            continue
        rows = contract['properties']
        identities = list(rows)
        if not identities:
            wire['properties'][field] = {'type':'array', 'maxItems':0, 'items':{'type':'object'}}
        else:
            templates = list(rows.values())
            if any(template != templates[0] for template in templates):
                raise ValueError('Identity transport requires a homogeneous record contract')
            item = deepcopy(templates[0])
            item['properties'][identity_field] = {'type':'string', 'enum':identities}
            item['required'].append(identity_field)
            wire['properties'][field] = {'type':'array', 'items':item,
                'minItems':len(identities), 'maxItems':len(identities)}
        layout[field] = (identity_field, identities)
    return wire, layout


def restore_identity_maps(response, layout):
    restored = deepcopy(response)
    for field, (identity_field, identities) in layout.items():
        rows = restored[field]
        values = {}
        for row in rows:
            identity = row[identity_field]
            if identity not in identities or identity in values:
                raise ValueError('Duplicate or unexpected review identity')
            values[identity] = {key:value for key,value in row.items() if key != identity_field}
        if set(values) != set(identities):
            raise ValueError('Missing required review identity')
        restored[field] = values
    return restored
