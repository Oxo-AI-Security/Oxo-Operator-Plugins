"""Use-case orchestration independent from HTTP and persistence details."""
