"""Reviewed, immutable operational facts shared by all Skill rule stages."""
import json
import hashlib
from ..domain.semantic import supported_confidence
from .skill_evidence import SourceIndex
from .skill_profile_types import Discovery, Review, discovery_schema
from .skill_profile_wire import profile_wire_schema, decode_operations
from .skill_authority import reviewed_authority
from .skill_assessment import ASSESSMENT_SUBJECT
from .identity_contract import keyed_records, identity_records


def _resolve_sources(operation: dict, sources: SourceIndex) -> dict:
    """Candidate citations must be real, independently of their eventual verdict."""
    evidence = {}
    for field in ('entry_evidence_id', 'action_evidence_id', 'input_evidence_id'):
        identifier = operation.get(field)
        if identifier is None and field == 'input_evidence_id':
            continue
        path, quote = sources.resolve('', '', identifier)
        if not path:
            raise ValueError(f'profile {field} does not identify nonblank original source')
        evidence[field.removesuffix('_id')] = {'path': path, 'quote': quote}
    if operation['action']=='execute' and operation['control'] == 'caller_executable' and 'input_evidence' not in evidence:
        raise ValueError('caller executable control requires an exact input citation')
    return {**operation, 'source_evidence': evidence}


def _ground(operation: dict, sources: SourceIndex) -> dict:
    """Accepted runtime facts also require a complete original entry reference chain."""
    grounded = _resolve_sources(operation, sources)
    path = grounded['source_evidence']['entry_evidence']['path']
    if operation['actor'] == 'runtime_agent' and path.rsplit('/', 1)[-1] != 'SKILL.md':
        chain = sources.procedure_reference_chain(path)
        if not chain:
            raise ValueError('profile entry is not the manifest or a manifest-referenced source')
        grounded['entry_reference_chain'] = chain
    return grounded


def _compile_operations(operations: list[dict], sources: SourceIndex) -> list[dict]:
    """Normalize reviewed effects/calls into facts; never infer rules or scores."""
    compiled = []
    for operation in operations:
        compiled.append(operation)
        invocation = operation.get('invocation')
        if invocation is None:
            continue
        execution = {
            **operation, 'operation_id': operation['operation_id'] + '.execution',
            'parent_operation_id': operation['operation_id'], 'action': 'execute',
            'resource': invocation['program'], 'origin': invocation['origin'],
            'control': invocation['control'], 'content_use': 'executable', 'reach': invocation['reach'],
            'action_evidence_id': invocation['evidence_id'],
            'input_evidence_id': invocation['input_evidence_id'], 'value_path': invocation['value_path'],
        }
        execution = _ground(execution, sources)
        if invocation['kind'] == 'program' or invocation['control'] == 'caller_executable':
            compiled.append(execution)
    ids = [operation['operation_id'] for operation in compiled]
    if len(ids) != len(set(ids)):
        raise ValueError('normalized effect/execution identities collide')
    return compiled


async def operational_profile(call, settings, files, *, prompt_version, rule_version, error_type):
    """Discover then independently review operations, without proposing rules."""
    sources=SourceIndex(files)
    versions={'prompt_version':prompt_version,'rule_set_version':rule_version}
    subject=dict(ASSESSMENT_SUBJECT)
    excerpts=[{'path':f['path'],'content':f.get('text') or ''} for f in files if f.get('text')]
    system=('Extract the execution plan that the Skill instructs assessment_subject to perform, from both procedure text and code. '
            'Natural-language operational steps define Agent behavior without requiring bundled tool implementations. '
            'Separate actor, action, source origin, executable control, '
            'content use, scope and activation condition. Entry references identify the active procedure linked from the manifest; '
            'action/input references must state the actual operation and controlled value. Return response_schema JSON. '
            'Do not calculate scores, infer permissions or convert uncertainty into a pure/fixed baseline.')
    raw,latency=await call(settings,[{'role':'system','content':system},{'role':'user','content':json.dumps({
        **versions,'operation_profile':True,'response_schema':profile_wire_schema(discovery_schema(list(sources.texts))),
        'assessment_subject':subject,
        'required_coverage_paths':list(sources.texts),
        'package_excerpts':excerpts},ensure_ascii=False)}],max_tokens=6500)
    discovery=Discovery.model_validate({**raw, 'operations':decode_operations(raw['operations'], reviewed=False)})
    if discovery.prompt_version!=prompt_version or discovery.rule_set_version!=rule_version:
        raise error_type('Skill 操作提取版本不匹配')
    operations=[o.model_dump() for o in discovery.operations]
    ids=[o['operation_id'] for o in operations]
    if len(ids)!=len(set(ids)):
        raise error_type('Skill 操作记录身份重复')
    if set(discovery.coverage)!=set(sources.texts):
        raise error_type('Skill 操作提取未覆盖完整可分析文件清单')
    coverage=[{'path':path,'role':discovery.coverage[path]} for path in sources.texts]
    grounded=[_resolve_sources(o,sources) for o in operations]
    review_schema=profile_wire_schema(Review.model_json_schema())
    review_schema['properties']['decisions']=keyed_records(
        review_schema['$defs']['ReviewDecision'],ids,'operation_id')
    review_raw,review_latency=await call(settings,[{'role':'system','content':
        'Independently review each supplied operation against the complete original Skill. Verify the runtime actor, '
        'entry linkage, condition, actual action, input origin, controlled value and its path to the action. '
        'Do not classify rules or overwrite operation identities/attributes: reject an incorrect record and add a '
        'source-grounded corrected record if needed. Include exactly one decision per input operation. '
        'Check the complete source for omitted reachable operations. Return response_schema JSON.'},
        {'role':'user','content':json.dumps({**versions,'operation_review':True,'operations':raw['operations'],
            'assessment_subject':subject,
            'coverage':coverage,'response_schema':review_schema,
            'package_excerpts':excerpts},ensure_ascii=False)}],max_tokens=6500)
    review=Review.model_validate({**review_raw,
        'decisions':identity_records(review_raw['decisions'],'operation_id'),
        'additional_operations':decode_operations(review_raw['additional_operations'])})
    if review.prompt_version!=prompt_version or review.rule_set_version!=rule_version:
        raise error_type('Skill 操作复核版本不匹配')
    decisions = {decision.operation_id: decision for decision in review.decisions}
    if len(decisions) != len(review.decisions) or set(decisions) != set(ids):
        raise error_type('Skill 操作复核身份不完整或重复')
    accepted = []
    for operation in grounded:
        decision = decisions[operation['operation_id']]
        if decision.valid and supported_confidence(decision.confidence):
            accepted.append(_ground({
                **operation, 'confidence': decision.confidence,
                'review': decision.model_dump(),
            }, sources))
    for index, operation in enumerate(review.additional_operations):
        if supported_confidence(operation.confidence):
            accepted.append(_ground({**operation.model_dump(), 'operation_id': f'added-{index}'}, sources))
    unresolved = [
        decision.operation_id for decision in review.decisions
        if not supported_confidence(decision.confidence)
    ]
    accepted = _compile_operations(accepted, sources)
    accepted, authority, authority_latency = await reviewed_authority(call, settings, accepted, sources, versions, error_type)
    fingerprint = hashlib.sha256(json.dumps(accepted, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()
    return {
        'operations': accepted,
        'coverage_complete': review.coverage_complete and not unresolved and 'unknown' not in discovery.coverage.values(),
        'unresolved_operations': unresolved,
        'contract_version': 'skill-operation-profile-v6', 'assessment_subject': subject, 'operations_sha256': fingerprint,
        'wire_contract_version': 'skill-operation-flat-wire-v3',
        'coverage': coverage,
        'unknowns': [*discovery.unknowns, *review.unknowns],
        'discovery': raw, 'review': review_raw, 'authority_review': authority,
        'latency_ms': latency + review_latency + authority_latency,
    }
