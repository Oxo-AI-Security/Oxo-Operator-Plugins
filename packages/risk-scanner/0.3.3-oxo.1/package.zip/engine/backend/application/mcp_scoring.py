"""Application orchestration for MCP snapshot scoring."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any

from ..domain.mcp.rules import FLOW_PROMPT_VERSION, RULE_SET_VERSION
from ..infrastructure.ai.concurrency import gather_stages

ToolExtractor = Callable[[dict[str, Any], dict[str, Any]], Awaitable[dict[str, Any]]]
FlowExtractor = Callable[
    [dict[str, Any], list[dict[str, Any]], list[str], dict[str, Any]],
    Awaitable[dict[str, Any]],
]
ScoreCalculator = Callable[..., dict[str, Any]]


async def score_mcp_tools_snapshot(
    server: dict[str, Any],
    *,
    use_llm: bool,
    previous_score: int | None,
    model_settings: dict[str, Any],
    model_is_configured: bool,
    extract_tool: ToolExtractor,
    extract_server_flows: FlowExtractor,
    score_server: ScoreCalculator,
    semantic_error_type: type[Exception],
) -> dict[str, Any]:
    """Combine semantic extraction with deterministic scoring.

    Dependencies are passed explicitly so this application layer is testable
    and the domain calculator remains the only authority for numeric scores.
    """
    extractions: dict[str, dict[str, Any]] = {}
    semantic_errors: list[str] = []
    flow_extraction: dict[str, Any] | None = None

    if use_llm and model_is_configured:
        # A failed fresh classification must not silently fall back to old semantics.
        server = {**server, "tools": [
            {key: value for key, value in tool.items() if key not in {
                "llm_extraction", "llm_raw_response", "llm_metadata_hash", "llm_response_meta",
            }} for tool in server.get("tools", [])
        ]}
        semaphore = asyncio.Semaphore(3)

        async def extract(item: dict[str, Any]) -> None:
            async with semaphore:
                try:
                    extractions[str(item.get("name"))] = await extract_tool(item, model_settings)
                except semantic_error_type as exc:
                    semantic_errors.append(f"{item.get('name')}: {exc}")

        await gather_stages(*(extract(tool) for tool in server.get("tools", [])))

        preliminary = score_server(server, extractions=extractions, previous_score=previous_score)
        flow_candidate_ids = [hit["id"] for hit in preliminary.get("flow_candidates", [])]
        if flow_candidate_ids:
            try:
                flow_extraction = await extract_server_flows(
                    server,
                    preliminary.get("tools", []),
                    flow_candidate_ids,
                    model_settings,
                )
            except semantic_error_type as exc:
                semantic_errors.append(f"Server FLOW 分析: {exc}")
        else:
            flow_extraction = {
                "prompt_version": FLOW_PROMPT_VERSION,
                "rule_set_version": RULE_SET_VERSION,
                "flow_rule_matches": [],
                "rejected_candidates": [],
                "unknowns": [],
                "__audit": {"mode": "not_required", "reason": "代码侧未形成 FLOW 前置候选"},
            }

    evaluated = score_server(
        server,
        extractions=extractions,
        previous_score=previous_score,
        flow_extraction=flow_extraction,
    )
    if semantic_errors:
        evaluated["unknowns"] = sorted(
            set(evaluated.get("unknowns", []) + [f"LLM 抽取失败：{item}" for item in semantic_errors])
        )
        evaluated["confidence"] = max(0.1, round(evaluated["confidence"] - 0.1, 2))
    return evaluated
