"""Compose test/save settings without reusing another service's credentials."""
from urllib.parse import urlsplit

from ..infrastructure.ai.provider_config import AZURE_PROVIDER, model_provider, provider_spec


def credential_scope(settings: dict) -> tuple[str, str]:
    provider = model_provider(settings)
    endpoint = (settings.get('azure_endpoint') if provider == AZURE_PROVIDER else settings.get('base_url'))
    endpoint = endpoint or provider_spec(settings).base_url
    return provider, urlsplit(str(endpoint)).netloc.lower()


def compose_model_settings(saved: dict, incoming: dict) -> dict:
    candidate = {**saved, **incoming}
    candidate['azure_endpoint'] = candidate.get('azure_endpoint') or ''
    candidate['azure_deployment'] = candidate.get('azure_deployment') or ''
    if incoming.get('api_key'):
        candidate['api_key'] = incoming['api_key']
    elif credential_scope(candidate) == credential_scope(saved):
        candidate['api_key'] = saved.get('api_key')
    else:
        candidate['api_key'] = None
    return candidate
