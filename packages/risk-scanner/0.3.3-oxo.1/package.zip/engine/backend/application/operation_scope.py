"""Independent scope dimensions mapped to the existing policy vocabulary."""

SCOPE_FIELDS = {
    'target_count': {'type': 'string', 'enum': ['single_object', 'multiple_objects', 'unspecified', 'unknown'],
        'description': 'Count independently selected top-level resources, not components within one selected resource.'},
    'target_selection': {'type': 'string', 'enum': ['fixed', 'bounded', 'free_target', 'unknown'],
        'description': 'Fixed literal target, a constrained selection, or an unconstrained caller-selected path/URL/identifier. Independent of target_count.'},
    'privilege': {'type': 'string', 'enum': ['ordinary', 'privileged', 'unknown'],
        'description': 'Declared authority requirement, including explicit elevated invocation; current environment availability is not assessed.'},
    'activation': {'type': 'string', 'enum': ['explicit', 'automatic', 'unknown'],
        'description': 'Explicit task invocation versus persistent/automatic trigger.'},
}


def decode_scope(record: dict, prefix: str = '') -> list[str]:
    values = {key: record.pop(prefix + key) for key in SCOPE_FIELDS}
    labels = [values['target_selection']] if values['target_selection'] in {'fixed', 'free_target'} else []
    if values['target_count'] in {'single_object', 'multiple_objects'}:
        labels.append(values['target_count'])
    if values['privilege'] == 'privileged':
        labels.append('privileged')
    if values['activation'] == 'automatic':
        labels.append('automatic')
    if 'unknown' in values.values():
        labels.append('unknown')
    return labels
