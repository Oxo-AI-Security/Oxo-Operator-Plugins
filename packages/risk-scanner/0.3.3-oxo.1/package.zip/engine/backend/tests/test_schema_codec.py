"""Provider encoding never weakens the local acceptance contract."""
from copy import deepcopy
import pytest
from jsonschema import validate,ValidationError
from backend.infrastructure.ai.schema_codec import generation_schema
from backend.infrastructure.ai.qwen import _request_parts


def test_deepseek_wire_dialect_keeps_local_bounds_and_property_names():
    schema = {'type': 'object', 'properties': {
        'minLength': {'type': 'string', 'minLength': 1},
        'items': {'type': 'array', 'minItems': 1, 'items': {'type': 'string', 'maxLength': 5}},
    }, 'required': ['minLength', 'items'], 'additionalProperties': False}
    original = deepcopy(schema)
    _, _, body = _request_parts({'provider': 'deepseek', 'api_key': 'offline', '_response_schema': schema}, [], 800)
    wire = body['text']['format']['schema']
    assert 'minLength' in wire['properties'] and 'minLength' not in wire['properties']['minLength']
    assert 'minItems' not in wire['properties']['items']
    assert schema == original
    with pytest.raises(ValidationError): validate({'minLength': '', 'items': []}, schema)


def test_global_array_constraints_remain_in_the_local_schema_and_reject_duplicates():
    schema={'type':'array','items':{'type':'integer'},'uniqueItems':True,'contains':{'const':1},'minContains':1}
    original=deepcopy(schema);wire=generation_schema(schema)
    assert schema==original and wire=={'type':'array','items':{'type':'integer'}}
    with pytest.raises(ValidationError):validate([1,1],schema)
    with pytest.raises(ValidationError):validate([2,3],schema)
    validate([1,2],schema)


def test_constants_are_encoded_equivalently_without_rewriting_property_names_or_data():
    schema={'type':'object','properties':{'const':{'const':'fixed'},'example':{'enum':[{'const':'inert-data'}]}},
            'required':['const','example'],'additionalProperties':False}
    wire=generation_schema(schema)
    assert wire['properties']['const']=={'enum':['fixed']}
    assert wire['properties']['example']==schema['properties']['example']
    value={'const':'fixed','example':{'const':'inert-data'}}
    validate(value,schema);validate(value,wire)
    with pytest.raises(ValidationError):validate({**value,'const':'wrong'},wire)


def test_transport_uses_generation_schema_but_does_not_mutate_the_validation_schema():
    schema={'type':'object','properties':{'ids':{'type':'array','uniqueItems':True,'items':{'type':'string'}}},
            'required':['ids'],'additionalProperties':False}
    original=deepcopy(schema)
    _,_,body=_request_parts({'api_key':'offline','model':'test','_response_schema':schema},[],800)
    assert 'uniqueItems' not in body['response_format']['json_schema']['schema']['properties']['ids']
    assert schema==original and schema['properties']['ids']['uniqueItems']
