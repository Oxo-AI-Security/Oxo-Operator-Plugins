"""Matcher unit tests isolate the separately tested operational-profile boundary."""
import pytest
from backend import skill_scanner as ss
from backend.application.skill_prompt import OPERATION_PROFILE

@pytest.fixture(autouse=True)
def isolate_operation_profile(monkeypatch):
    async def boundary(*args, **kwargs):
        return None
    async def contract_boundary(chat,settings,messages,**kwargs):
        response,latency=await chat(settings,messages,max_tokens=kwargs['max_tokens'])
        return response,latency,{'status':'matcher_unit_boundary'}
    monkeypatch.setattr(ss, 'operational_profile', boundary)
    monkeypatch.setattr(ss, 'structured_chat', contract_boundary)
    monkeypatch.setattr(ss, 'decode_skill_response', lambda response,request:response)
    monkeypatch.setattr(ss, 'require_contract', boundary)
    token=OPERATION_PROFILE.set(None)
    try:
        yield
    finally:
        OPERATION_PROFILE.reset(token)
