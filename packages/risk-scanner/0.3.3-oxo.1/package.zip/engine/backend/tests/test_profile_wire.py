"""Flat transport has the same fact space, confidence and source requirements."""
from copy import deepcopy
import json
import pytest
from pydantic import ValidationError
from backend.application.skill_profile_types import Discovery, Review, Operation
from backend.application.skill_profile_wire import profile_wire_schema, decode_operations
from backend.infrastructure.ai.schema_validation import validation_errors
from backend.tests.test_effect_execution_contract import case
from backend.application.skill_profile import _ground, _compile_operations


class ReviewedDiscovery(Discovery):
    operations: list[Operation]


def flatten(operation):
    row = deepcopy(operation)
    invocation = row.pop('invocation')
    def scope(value):
        reach = value.pop('reach')
        return {**value, 'target_count':next((x for x in reach if x in {'single_object','multiple_objects'}),'unspecified'),
            'target_selection':next((x for x in reach if x in {'fixed','free_target'}),'bounded'),
            'privilege':'privileged' if 'privileged' in reach else 'ordinary',
            'activation':'automatic' if 'automatic' in reach else 'explicit'}
    row = scope(row)
    row.update({'invocation_kind':'none'} if invocation is None else
               {f'invocation_{key}':value for key,value in scope(invocation).items()})
    return row


def response(operation):
    return {'prompt_version':'v','rule_set_version':'r','operations':[flatten(operation)],
            'coverage':{'SKILL.md':'procedure'},'unknowns':[]}


@pytest.mark.parametrize('kind', ['program','tool_or_api',None])
def test_lossless_roundtrip_preserves_scope_quotes_unknowns_and_confidence(kind):
    _, operation = case(kind or 'program')
    if kind is None: operation['invocation'] = None
    else: operation['invocation']['value_path'] += ' -> "quoted\\path"\nnext line'
    operation['confidence'] = .2
    operation['origin'] = 'unknown'
    original = deepcopy(operation)
    unchanged = deepcopy(operation)
    raw = json.loads(json.dumps(response(operation), ensure_ascii=False))
    schema = profile_wire_schema(ReviewedDiscovery.model_json_schema())
    assert not validation_errors(schema, raw)
    decoded = decode_operations(raw['operations'])[0]
    assert set(decoded.pop('reach')) == set(original.pop('reach'))
    if original['invocation']:
        assert set(decoded['invocation'].pop('reach')) == set(original['invocation'].pop('reach'))
    assert decoded == original
    assert operation == unchanged


@pytest.mark.parametrize('defect', ['missing_call_source','none_with_call_fields','invalid_kind','nested',
    'missing_discriminator','extra','invalid_confidence','string_instead_of_list'])
def test_incomplete_ambiguous_or_legacy_records_cannot_pass(defect):
    _, operation = case()
    raw = response(operation)
    row = raw['operations'][0]
    if defect == 'missing_call_source': del row['invocation_input_evidence_id']
    elif defect == 'none_with_call_fields': row['invocation_kind'] = 'none'
    elif defect == 'invalid_kind': row['invocation_kind'] = 'shell'
    elif defect == 'nested': raw['operations'] = [operation]
    elif defect == 'missing_discriminator': del row['invocation_kind']
    elif defect == 'invalid_confidence': row['confidence'] = True
    elif defect == 'string_instead_of_list': row['invocation_reach'] = 'free_target'
    else: row['invented_field'] = 'value'
    assert validation_errors(profile_wire_schema(ReviewedDiscovery.model_json_schema()), raw)


def test_both_schemas_are_derived_from_the_same_domain_types_without_mutation():
    for model in (Discovery, Review):
        schema = model.model_json_schema()
        original = deepcopy(schema)
        wire = profile_wire_schema(schema)
        key = 'Operation' if model is Review else 'OperationFacts'
        variants = wire['$defs'][key]['anyOf']
        assert len(variants) == 2
        assert all('invocation' not in branch['properties'] for branch in variants)
        assert variants[1]['properties']['invocation_control'] == original['$defs']['Invocation']['properties']['control']
        assert schema == original


def test_bad_source_still_fails_after_valid_wire_and_exact_decoder():
    sources, operation = case()
    operation['invocation']['input_evidence_id'] = 'E99-999'
    raw = response(operation)
    assert not validation_errors(profile_wire_schema(ReviewedDiscovery.model_json_schema()), raw)
    joined = decode_operations(raw['operations'])[0]
    with pytest.raises(ValueError): _compile_operations([_ground(joined, sources)], sources)


def test_decoder_does_not_silently_drop_extra_fields_even_when_called_directly():
    _, operation = case()
    row = flatten(operation)
    row['unexpected'] = 'value'
    with pytest.raises(ValidationError): decode_operations([row])
