import asyncio,json
import pytest
from backend.application.skill_authority import reviewed_authority
from backend.application.skill_evidence import SourceIndex
from backend.application.skill_profile import _ground
from backend.domain.skill.profile_policy import validate_mapping
from backend.tests.test_skill_operation_profile import operation


@pytest.mark.parametrize('authentication,confidence,proven',[
    ('absent',.95,False),('unknown',.9,False),('established',.3,False),('established',.9,True)])
def test_interface_control_needs_affirmative_source_backed_session_authority(authentication,confidence,proven):
    sources=SourceIndex([{'path':'SKILL.md','text':'Control the selected interface.\nUse the authenticated context only after login.\n'}])
    op={**operation(),'action':'interface','action_evidence_id':'E0-0','input_evidence_id':None}
    async def reply(settings,messages,**kwargs):
        request=json.loads(messages[1]['content'])
        assert not request.get('rule_catalog')
        return {'prompt_version':'fixed','rule_set_version':'fixed','decisions':[{
            'operation_id':'read','authentication':authentication,'privilege':'ordinary','evidence_ids':['E0-1'],
            'confidence':confidence,'source_reason':'Review the actual context, not the existence of interface control.'}]},1
    result,raw,_=asyncio.run(reviewed_authority(reply,{},[op],sources,
        {'prompt_version':'fixed','rule_set_version':'fixed'},ValueError))
    assert result[0]['authenticated_session_proven'] is proven
    assert raw['decisions'][0]['confidence']==confidence
    error,_=validate_mapping('CAP-015',['read'],{'operations':result,'coverage_complete':True})
    assert (error is None) is proven


def test_resource_code_data_does_not_claim_execution_without_an_invocation():
    sources=SourceIndex([{'path':'SKILL.md','text':'Read the selected source code.\n'}])
    read={**operation(),'control':'caller_executable','action_evidence_id':'E0-0','input_evidence_id':None}
    assert _ground(read,sources)['action']=='read'
    with pytest.raises(ValueError,match='exact input citation'):_ground({**read,'action':'execute'},sources)
