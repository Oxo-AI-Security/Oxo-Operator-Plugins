"""A negative FLOW decision needs an explicit candidate-specific receipt."""
import asyncio
import pytest
from backend.application import skill_scanner as scanner


@pytest.mark.parametrize('decision',['empty','unknown','explicit_rejection'])
def test_undecided_flow_is_incomplete_and_explicit_source_rejection_can_complete(monkeypatch,decision):
    async def reply(settings,messages,**kwargs):
        if __import__('json').loads(messages[1]['content']).get('flow_adjudication'):
            return {'prompt_version':scanner.SKILL_FLOW_PROMPT_VERSION,'rule_set_version':scanner.SKILL_RULE_SET_VERSION,
                'candidate_decisions':[{'candidate_id':'0','valid':False,'confidence':.95,
                    'rationale':'The source and command are independent.','exclusion_analysis':'No value joins the source to execution.'}]},1
        return {'prompt_version':scanner.SKILL_FLOW_PROMPT_VERSION,
                'rule_set_version':scanner.SKILL_RULE_SET_VERSION,'flow_rule_matches':[],
                'rejected_candidates':[{'rule_id':'FLOW-003','rationale':'The source is never used as an execution argument.'}]
                    if decision=='explicit_rejection' else [],
                'unknowns':['The path could not be determined.'] if decision=='unknown' else []},1
    monkeypatch.setattr(scanner,'_recorded_skill_chat',reply)
    matches,audit=asyncio.run(scanner._llm_flow_findings(
        [{'path':'SKILL.md','text':'Read content and independently execute a fixed local tool.'}],
        ['FLOW-003'],[],[],{'api_key':'offline'}))
    assert matches==[]
    assert audit['status']==('completed' if decision=='explicit_rejection' else 'incomplete')
    if decision!='explicit_rejection':
        assert audit['rejected'][0]['validation_error']=='flow_candidate_undecided'
