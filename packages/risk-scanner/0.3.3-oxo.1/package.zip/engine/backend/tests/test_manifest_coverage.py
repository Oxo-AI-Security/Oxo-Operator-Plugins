"""Known source identities are required in both the decoder and local validator."""
import pytest
from backend.application.skill_profile_types import discovery_schema
from backend.infrastructure.ai.schema_validation import validation_errors


@pytest.mark.parametrize('coverage', [{}, {'SKILL.md': 'procedure'},
    {'SKILL.md': 'procedure', 'guide.md': 'data', 'extra.md': 'data'},
    {'SKILL.md': 'procedure', 'guide.md': 'optional'},
    [{'path': 'SKILL.md', 'role': 'procedure'}]])
def test_missing_extra_unknown_roles_and_legacy_lists_are_rejected(coverage):
    schema = discovery_schema(['SKILL.md', 'guide.md'])
    result = {'prompt_version': 'v', 'rule_set_version': 'r', 'operations': [],
              'coverage': coverage, 'unknowns': []}
    assert validation_errors(schema, result)


def test_path_keys_with_json_pointer_characters_remain_exact():
    paths = ['SKILL.md', 'nested/a~b.md']
    schema = discovery_schema(paths)
    result = {'prompt_version': 'v', 'rule_set_version': 'r', 'operations': [],
              'coverage': dict(zip(paths, ['procedure', 'unknown'])), 'unknowns': []}
    assert not validation_errors(schema, result)
    assert schema['properties']['coverage']['required'] == paths
