"""Resource effects and executable control have separate typed provenance."""
from copy import deepcopy
import pytest
from pydantic import ValidationError
from backend.application.skill_profile import _ground, _compile_operations
from backend.application.skill_profile_types import Operation
from backend.application.skill_evidence import SourceIndex
from backend.domain.skill.profile_policy import validate_mapping
from backend.tests.test_skill_operation_profile import operation


def case(kind='program'):
    sources=SourceIndex([{'path':'SKILL.md','text':'Read and update records using runner.py.\n'},
        {'path':'runner.py','text':'program = args.program\nsubprocess.run(program)\nclient.update_all(records)\n'}])
    effect={**operation(),'operation_id':'change','action':'modify','resource':'records',
        'action_evidence_id':'E1-2','input_evidence_id':None,'reach':['multiple_objects'],
        'invocation':{'kind':kind,'program':'selected program','origin':'task',
            'control':'caller_executable','reach':['free_target'],'evidence_id':'E1-1',
            'input_evidence_id':'E1-0','value_path':'args.program -> program -> subprocess.run(program)'}}
    return sources,effect


def test_one_invocation_retains_resource_scope_and_independent_executable_input():
    sources,effect=case();facts=_compile_operations([_ground(effect,sources)],sources)
    assert [(f['operation_id'],f['action'],f['control'],f['reach']) for f in facts]==[
        ('change','modify','caller_data',['multiple_objects']),
        ('change.execution','execute','caller_executable',['free_target'])]
    assert facts[1]['source_evidence']['input_evidence']['quote']=='program = args.program\n'
    profile={'operations':facts,'coverage_complete':True}
    assert validate_mapping('CAP-011',['change'],profile)[0]=='rule_prerequisite_not_in_reviewed_operations'
    assert validate_mapping('CAP-011',['change.execution'],profile)==(None,.9)


def test_tool_identity_is_not_automatically_program_execution():
    sources,effect=case('tool_or_api')
    effect['invocation']['control']='fixed_data'
    assert len(_compile_operations([_ground(effect,sources)],sources))==1


def test_executable_input_through_api_cannot_hide_as_tool_identity():
    sources,effect=case('tool_or_api')
    facts=_compile_operations([_ground(effect,sources)],sources)
    assert len(facts)==2
    assert validate_mapping('CAP-011',['change.execution'],{'operations':facts,'coverage_complete':True})==(None,.9)


def test_invocation_provenance_is_checked_even_for_tool_metadata():
    sources,effect=case('tool_or_api');effect['invocation']['input_evidence_id']='E99-999'
    with pytest.raises(ValueError,match='nonblank original source'):
        _compile_operations([_ground(effect,sources)],sources)


def test_native_effect_cannot_replace_a_resource_effect_with_generic_execution():
    sources,effect=case();effect['action']='execute'
    with pytest.raises(ValidationError):Operation.model_validate(effect)


def test_executable_value_source_is_mandatory_in_the_native_contract():
    sources,effect=case();del effect['invocation']['input_evidence_id']
    with pytest.raises(ValidationError):Operation.model_validate(effect)
