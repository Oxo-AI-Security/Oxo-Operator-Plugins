"""DeepSeek settings across validation, save/reload, probing and request routing."""
import asyncio
from copy import deepcopy
import json

import httpx
import pytest
from fastapi.testclient import TestClient

from backend import main, qwen
from backend.api.schemas import ModelSettingsInput
from backend.application.model_settings import compose_model_settings
from backend.infrastructure.ai.capabilities import _CAPABILITY_CACHE
from backend.store import Store


def test_deepseek_defaults_and_openapi_provider_catalog_have_one_source():
    settings = ModelSettingsInput(provider='deepseek')
    assert settings.model == 'deepseek-flash'
    assert settings.base_url == 'https://api.deepseek.com'
    client = TestClient(main.app)
    options = client.get('/api/settings/model/providers').json()
    preset = next(option for option in options if option['provider'] == 'deepseek')
    assert preset['default_model'] == settings.model
    assert preset['base_url'] == settings.base_url
    assert preset['models'] == ['deepseek-flash', 'deepseek-v4-pro']
    assert preset['key_environment'] == 'DEEPSEEK_API_KEY'
    assert 'deepseek' in client.get('/openapi.json').json()['components']['schemas']['ModelSettingsInput']['properties']['provider']['enum']


def test_saved_deepseek_key_and_config_survive_reload_without_plaintext_exposure(tmp_path, monkeypatch):
    local = Store(tmp_path / 'state.db')
    monkeypatch.setattr(main, 'store', local)
    client = TestClient(main.app)
    candidate = {'provider': 'deepseek', 'api_key': 'isolated-deepseek-secret'}
    saved = client.put('/api/settings/model', json=candidate)
    assert saved.status_code == 200 and saved.json()['provider'] == 'deepseek'
    assert candidate['api_key'] not in saved.text and 'api_key' not in saved.json()
    reloaded = Store(tmp_path / 'state.db')
    assert reloaded.model_settings['api_key'] == candidate['api_key']
    assert reloaded.model_settings['base_url'] == 'https://api.deepseek.com'
    raw = local._database.load('model_settings', {})
    assert '_sealed_api_key' in raw and 'api_key' not in raw
    assert candidate['api_key'] not in json.dumps(raw)
    monkeypatch.setattr(main, 'store', reloaded)
    blank_key_save = client.put('/api/settings/model', json={'provider': 'deepseek', 'model': 'deepseek-v4-pro'})
    assert blank_key_save.status_code == 200
    assert reloaded.model_settings['api_key'] == candidate['api_key']


@pytest.mark.parametrize('incoming', [
    {'provider': 'deepseek'},
    {'provider': 'openai_compatible', 'base_url': 'https://another-provider.test/v1'},
])
def test_old_credentials_are_cleared_when_provider_or_endpoint_changes(incoming):
    previous = {'provider': 'openai_compatible', 'model': 'qwen-max',
                'base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1', 'api_key': 'old-cloud-key'}
    original = deepcopy(previous)
    request = ModelSettingsInput(**incoming).model_dump()
    result = compose_model_settings(previous, request)
    assert result['api_key'] is None and previous == original


def test_deepseek_uses_its_own_environment_key_and_non_thinking_request_budget(monkeypatch):
    monkeypatch.setenv('DASHSCOPE_API_KEY', 'wrong-cloud')
    monkeypatch.setenv('DEEPSEEK_API_KEY', 'deepseek-environment-key')
    url, headers, body = qwen._request_parts({'provider': 'deepseek'}, [], 20)
    assert url == 'https://api.deepseek.com/chat/completions'
    assert headers['Authorization'] == 'Bearer deepseek-environment-key'
    assert body['model'] == 'deepseek-flash' and body['max_tokens'] == 20
    assert body['thinking'] == {'type': 'disabled'}
    monkeypatch.delenv('DEEPSEEK_API_KEY')
    assert qwen.effective_key({'provider': 'deepseek'}) is None


def test_saved_configuration_test_reuses_only_matching_key_and_keeps_failed_skill_contract(tmp_path, monkeypatch):
    local = Store(tmp_path / 'state.db')
    local.save_model_settings(ModelSettingsInput(provider='deepseek', api_key='saved-deepseek-key').model_dump())
    original = deepcopy(local.model_settings)
    monkeypatch.setattr(main, 'store', local)
    calls = []
    client_class = httpx.AsyncClient

    def respond(request):
        calls.append(request)
        body = json.loads(request.content)
        assert request.headers['Authorization'] == 'Bearer saved-deepseek-key'
        assert body['model'] == 'deepseek-flash'
        if 'text' in body:
            assert str(request.url) == 'https://api.deepseek.com/responses'
            return httpx.Response(200, json={'object': 'response', 'status': 'completed', 'output': [{
                'type': 'message', 'role': 'assistant', 'status': 'completed',
                'content': [{'type': 'output_text', 'text': '{"contract_tag":"wrong-value","items":[]}'}],
            }]})
        assert str(request.url) == 'https://api.deepseek.com/chat/completions'
        return httpx.Response(200, json={'choices': [{'finish_reason': 'stop', 'message': {'content': '{"ok":true}'}}]})

    monkeypatch.setattr(qwen.httpx, 'AsyncClient', lambda **kwargs: client_class(transport=httpx.MockTransport(respond), **kwargs))
    _CAPABILITY_CACHE.clear()
    response = TestClient(main.app).post('/api/settings/model/test', json={'provider': 'deepseek'})
    assert response.status_code == 200
    assert response.json()['ok'] is True and response.json()['provider'] == 'deepseek'
    assert response.json()['skill_contract']['supported'] is False
    assert response.json()['skill_contract']['format'] == 'responses_json_schema'
    assert len(calls) == 2 and local.model_settings == original
    assert 'saved-deepseek-key' not in response.text
    _CAPABILITY_CACHE.clear()
