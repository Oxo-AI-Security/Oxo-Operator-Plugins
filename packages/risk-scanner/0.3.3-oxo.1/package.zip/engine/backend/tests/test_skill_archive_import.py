import io
import zipfile
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from backend import main
from backend.application.score_jobs import ScoreJobFailure
from backend.store import Store


def archive(files: dict[str, str]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as output:
        for path, content in files.items():
            output.writestr(path, content)
    return buffer.getvalue()


def configured_store(path) -> Store:
    result = Store(path)
    result.save_model_settings({
        "model": "qwen-plus",
        "base_url": "https://example.test/v1",
        "api_key": "sk-test-skill-import",
    })
    return result


def completed_scan(name: str, files: list[dict]) -> dict:
    now = datetime.now(timezone.utc).isoformat()
    snapshot = main.skill_snapshot_hash(files)
    return {
        "id": f"scan-{snapshot[:12]}",
        "name": name,
        "scanned_at": now,
        "snapshot_hash": snapshot,
        "snapshot_short": snapshot[:12],
        "fingerprint_algorithm": "sha256-canonical-package-v1",
        "rule_set_version": main.SKILL_RULE_SET_VERSION,
        "prompt_version": main.SKILL_PROMPT_VERSION,
        "flow_prompt_version": main.SKILL_FLOW_PROMPT_VERSION,
        "classification_status": "classified",
        "analyzer_versions": {"scoring": main.SKILL_SCORING_VERSION},
        "llm_analysis": {
            "status": "completed", "accepted": 2, "proposed": 2,
            "axis_coverage": {"capability": True, "exposure": True}, "missing_axes": [],
        },
        "flow_llm_analysis": {"status": "not_required", "accepted": 0},
        "flow_candidates": [],
        "effective_risk": 0,
        "risk_label": "informational",
        "decision": "allow",
        "default_action": "allow",
        "analyzable_file_count": len(files),
        "ignored_file_count": 0,
        "file_count": len(files),
        "findings": [],
        "dimension_scores": {"SEM": 0, "MAL": 0, "CAP": 0, "EXP": 0},
        "calculation": {},
        "base_risk": 0,
        "rule_floor": 0,
        "flow_floor": 0,
        "hard_gates": [],
        "unknowns": [],
    }


def test_archive_import_splits_multiple_skills_and_reuses_identical_hash(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "skill-import.db")
    managed_root = tmp_path / "managed"
    scan_calls = []

    async def fake_scan(name, files, _settings, **_kwargs):
        scan_calls.append((name, files))
        return completed_scan(name, files)

    monkeypatch.setattr(main, "store", test_store)
    monkeypatch.setattr(main, "scan_skill", fake_scan)
    monkeypatch.setattr(main, "save_managed_skill_files", lambda skill_id, _files: managed_root / skill_id)
    monkeypatch.setattr(main, "delete_managed_skill_files", lambda _skill_id: None)

    payload = archive({
        "bundle/alpha/SKILL.md": "# Alpha\nSummarize public text.",
        "bundle/alpha/scripts/run.py": "print('alpha')",
        "bundle/beta/SKILL.md": "# Beta\nFormat JSON.",
    })
    with TestClient(main.app) as client:
        first = client.post(
            "/api/skills/import-archive",
            files={"file": ("skills.zip", payload, "application/zip")},
        )
        second = client.post(
            "/api/skills/import-archive",
            files={"file": ("skills-again.zip", payload, "application/zip")},
        )

    assert first.status_code == 200
    assert first.json()["package_count"] == 2
    assert first.json()["scanned"] == 2
    assert first.json()["cache_hits"] == 0
    assert second.status_code == 200
    assert second.json()["package_count"] == 2
    assert second.json()["scanned"] == 0
    assert second.json()["cache_hits"] == 2
    assert all(item["cache_hit"] for item in second.json()["skills"])
    assert len(scan_calls) == 2
    assert len(test_store.list_skills()) == 2


def test_pending_skill_inventory_exposes_parsed_item_without_a_fake_score():
    pending = main._pending_skill_inventory(
        {
            "name": "alpha",
            "root": "bundle/alpha",
            "snapshot_hash": "a" * 64,
            "files": [
                {"path": "SKILL.md", "size": 18},
                {"path": "scripts/run.py", "size": 12},
            ],
        },
        "skills.zip",
        "alpha-123456",
    )

    latest = pending["latest_scan"]
    assert pending["storage_mode"] == "pending_upload"
    assert latest["analysis_status"] == "pending"
    assert latest["classification_status"] == "pending"
    assert latest["file_count"] == 2
    assert "effective_risk" not in latest


def test_archive_import_replaces_same_skill_identity_instead_of_creating_history(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "skill-replace.db")
    managed_root = tmp_path / "managed"

    async def fake_scan(name, files, _settings, **_kwargs):
        return completed_scan(name, files)

    monkeypatch.setattr(main, "store", test_store)
    monkeypatch.setattr(main, "scan_skill", fake_scan)
    monkeypatch.setattr(main, "save_managed_skill_files", lambda skill_id, _files: managed_root / skill_id)
    monkeypatch.setattr(main, "delete_managed_skill_files", lambda _skill_id: True)
    first_payload = archive({"bundle/alpha/SKILL.md": "# Alpha\nVersion one."})
    second_payload = archive({"bundle/alpha/SKILL.md": "# Alpha\nVersion two."})

    with TestClient(main.app) as client:
        first = client.post("/api/skills/import-archive", files={"file": ("first.zip", first_payload, "application/zip")})
        second = client.post("/api/skills/import-archive", files={"file": ("second.zip", second_payload, "application/zip")})

    assert first.status_code == second.status_code == 200
    assert first.json()["skills"][0]["id"] != second.json()["skills"][0]["id"]
    assert len(test_store.list_skills()) == 1
    assert test_store.list_skills()[0]["fingerprint_hash"] == second.json()["skills"][0]["fingerprint_hash"]


def test_archive_import_requires_exact_uppercase_skill_anchor(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "store", configured_store(tmp_path / "lowercase-anchor.db"))
    payload = archive({"demo/skill.md": "# Not an exact anchor"})
    with TestClient(main.app) as client:
        response = client.post(
            "/api/skills/import-archive",
            files={"file": ("bad.zip", payload, "application/zip")},
        )
    assert response.status_code == 422
    assert response.json()["detail"]["code"] == "SKILL_ANCHOR_NOT_FOUND"


def test_archive_cache_miss_requires_model_configuration(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "store", Store(tmp_path / "missing-model.db"))
    payload = archive({"demo/SKILL.md": "# Demo"})
    with TestClient(main.app) as client:
        response = client.post(
            "/api/skills/import-archive",
            files={"file": ("demo.zip", payload, "application/zip")},
        )
    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "MODEL_NOT_CONFIGURED"


def test_archive_import_isolates_one_skill_failure_and_continues(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "skill-partial.db")
    managed_root = tmp_path / "managed"

    async def fake_scan(name, files, _settings, **_kwargs):
        if name == "beta":
            raise ScoreJobFailure("LLM_SCORING_FAILED", "temporary model failure")
        return completed_scan(name, files)

    monkeypatch.setattr(main, "store", test_store)
    monkeypatch.setattr(main, "scan_skill", fake_scan)
    monkeypatch.setattr(main, "save_managed_skill_files", lambda skill_id, _files: managed_root / skill_id)
    monkeypatch.setattr(main, "delete_managed_skill_files", lambda _skill_id: None)
    payload = archive({
        "bundle/alpha/SKILL.md": "# Alpha",
        "bundle/beta/SKILL.md": "# Beta",
        "bundle/gamma/SKILL.md": "# Gamma",
    })

    with TestClient(main.app) as client:
        response = client.post(
            "/api/skills/import-archive",
            files={"file": ("skills.zip", payload, "application/zip")},
        )

    assert response.status_code == 200
    body = response.json()
    assert body["package_count"] == 3
    assert body["scanned"] == 2
    assert body["failed"] == 1
    assert body["failures"][0]["name"] == "beta"
    inventories = test_store.list_skills()
    assert len(inventories) == 3
    failed_skill = next(item for item in inventories if item["name"] == "beta")
    assert failed_skill["latest_scan"]["analysis_status"] == "error"
    assert failed_skill["latest_scan"]["analysis_error_code"] == "LLM_SCORING_FAILED"


def test_stored_skill_can_be_re_evaluated_with_current_model(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "skill-reevaluate.db")
    files = [{"path": "SKILL.md", "content_base64": "IyBEZW1v", "size": 6}]
    baseline = completed_scan("demo", files)
    test_store.upsert_skill({
        "id": "demo-abc123",
        "name": "demo",
        "storage_mode": "managed_copy",
        "managed_path": str(tmp_path / "managed" / "demo-abc123"),
        "created_at": baseline["scanned_at"],
        "fingerprint_hash": baseline["snapshot_hash"],
        "latest_scan": baseline,
    })
    calls = []

    async def fake_scan(name, received_files, _settings, **kwargs):
        calls.append((name, received_files, kwargs))
        result = completed_scan(name, received_files)
        result["effective_risk"] = 54
        result["risk_label"] = "medium"
        return result

    monkeypatch.setattr(main, "store", test_store)
    monkeypatch.setattr(main, "load_managed_skill_files", lambda _skill_id: files)
    monkeypatch.setattr(main, "scan_skill", fake_scan)

    with TestClient(main.app) as client:
        response = client.post("/api/skills/demo-abc123/evaluate")

    assert response.status_code == 200
    assert response.json()["latest_scan"]["effective_risk"] == 54
    assert calls[0][2]["trigger"] == "manual_reevaluation"
    assert test_store.get_skill("demo-abc123")["latest_scan"]["classification_status"] == "classified"
