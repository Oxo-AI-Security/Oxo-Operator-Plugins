from __future__ import annotations

import base64

import pytest

from backend.skill_repository import (
    ManagedSkillStorageError,
    delete_managed_skill_files,
    load_managed_skill_files,
    save_managed_skill_files,
)


def encoded_file(path: str, content: bytes) -> dict:
    return {
        "path": path,
        "content_base64": base64.b64encode(content).decode("ascii"),
        "size": len(content),
    }


def test_managed_skill_round_trip_and_delete(tmp_path):
    files = [
        encoded_file("example/SKILL.md", b"---\nname: example\n---\n"),
        encoded_file("example/scripts/run.py", b"print('ok')\n"),
    ]
    target = save_managed_skill_files("example-abc123", files, root=tmp_path)

    assert target == (tmp_path / "example-abc123").resolve()
    assert (target / "example" / "SKILL.md").read_bytes() == b"---\nname: example\n---\n"
    assert (target / "example" / "scripts" / "run.py").read_bytes() == b"print('ok')\n"
    loaded = load_managed_skill_files("example-abc123", root=tmp_path)
    loaded_by_path = {item["path"]: item for item in loaded}
    assert set(loaded_by_path) == {"example/SKILL.md", "example/scripts/run.py"}
    assert base64.b64decode(loaded_by_path["example/scripts/run.py"]["content_base64"]) == b"print('ok')\n"
    assert delete_managed_skill_files("example-abc123", root=tmp_path) is True
    assert not target.exists()


@pytest.mark.parametrize("unsafe", ["../escape.txt", "/absolute.txt", "folder/../../escape.txt"])
def test_managed_skill_rejects_path_traversal(tmp_path, unsafe):
    with pytest.raises(ManagedSkillStorageError):
        save_managed_skill_files(
            "example-abc123",
            [encoded_file(unsafe, b"unsafe")],
            root=tmp_path,
        )
    assert not (tmp_path / "example-abc123").exists()


def test_load_managed_skill_requires_existing_non_empty_package(tmp_path):
    with pytest.raises(ManagedSkillStorageError, match="does not exist"):
        load_managed_skill_files("missing-abc123", root=tmp_path)

    (tmp_path / "empty-abc123").mkdir()
    with pytest.raises(ManagedSkillStorageError, match="empty"):
        load_managed_skill_files("empty-abc123", root=tmp_path)
