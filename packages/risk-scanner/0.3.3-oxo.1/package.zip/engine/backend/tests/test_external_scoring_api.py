import io
import json
import tarfile
import zipfile

import pytest
from fastapi.testclient import TestClient

from backend import main
from backend.application.score_jobs import ScoreJobFailure
from backend.external_payloads import PayloadFormatError, parse_skill_archive
from backend.store import Store


def configured_store(path) -> Store:
    result = Store(path)
    result.save_model_settings({
        "model": "qwen-plus",
        "base_url": "https://example.test/v1",
        "api_key": "sk-test-external-scoring-key",
    })
    return result


@pytest.fixture(autouse=True)
def stub_external_llm(monkeypatch):
    async def fake_extract_tool(_tool, _settings):
        return {
            "prompt_version": main.LLM_PROMPT_VERSION,
            "rule_set_version": main.RULE_SET_VERSION,
            "capability_rule_matches": [{
                "rule_id": "CAP-001",
                "confidence": 0.98,
                "rationale": "Fixed non-privileged lookup behavior.",
                "evidence": ["Search users by name or email address."],
            }],
            "rejected_candidates": [],
            "has_security_issue": False,
            "security_issue_types": [],
            "security_rule_matches": [],
            "untrusted_content": {"detected": False, "confidence": 0, "evidence": []},
            "data_classes": ["public"],
            "unknowns": [],
            "__audit": {"model": "test", "latency_ms": 1},
        }

    async def fake_scan_skill(name, _files, _settings, **_kwargs):
        return {
            "name": name,
            "effective_risk": 0,
            "findings": [],
            "classification_status": "classified",
            "llm_analysis": {
                "status": "completed",
                "axis_coverage": {"capability": True, "exposure": True},
                "missing_axes": [],
            },
            "flow_llm_analysis": {"status": "not_required"},
            "flow_candidates": [],
        }

    monkeypatch.setattr(main, "extract_tool", fake_extract_tool)
    monkeypatch.setattr(main, "scan_skill", fake_scan_skill)


def mcp_payload() -> str:
    return json.dumps({
        "jsonrpc": "2.0",
        "id": 2,
        "result": {
            "tools": [{
                "name": "search_users",
                "title": "Search Users",
                "description": "Search users by name or email address.",
                "inputSchema": {
                    "type": "object",
                    "properties": {"query": {"type": "string"}},
                    "required": ["query"],
                    "additionalProperties": False,
                },
                "annotations": {
                    "readOnlyHint": True,
                    "destructiveHint": False,
                    "idempotentHint": True,
                    "openWorldHint": False,
                },
            }],
        },
    })


def zip_archive(files: dict[str, str]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path, content in files.items():
            archive.writestr(path, content)
    return buffer.getvalue()


def test_mcp_snapshot_submit_and_poll(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "external-mcp.db")
    monkeypatch.setattr(main, "store", test_store)
    with TestClient(main.app) as client:
        submitted = client.post("/api/v1/score/mcp/requests", json={
            "payload": mcp_payload(),
            "name": "External HR MCP",
            "client_reference": "asset-42",
        })
        assert submitted.status_code == 202
        accepted = submitted.json()
        assert accepted["status"] == "queued"
        assert accepted["kind"] == "mcp"
        result = client.get(accepted["result_url"])
        assert result.status_code == 200
        body = result.json()
        assert body["status"] == "succeeded"
        assert body["client_reference"] == "asset-42"
        assert body["result"]["tool_count"] == 1
        assert body["result"]["name"] == "External HR MCP"
        inventory = client.get("/api/servers")
        assert inventory.status_code == 200
        items = inventory.json()
        assert len(items) == 1
        assert items[0]["id"] == body["result"]["id"]
        assert items[0]["source"] == "external_api"
        assert items[0]["inventory_mode"] == "external_snapshot"
        assert items[0]["refresh_supported"] is False


def test_mcp_snapshot_rejects_removed_inventory_controls(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "external-mcp-simple-contract.db")
    monkeypatch.setattr(main, "store", test_store)
    with TestClient(main.app) as client:
        persist_response = client.post("/api/v1/score/mcp/requests", json={
            "payload": mcp_payload(),
            "persist_to_inventory": False,
        })
        key_response = client.post("/api/v1/score/mcp/requests", json={
            "payload": mcp_payload(),
            "inventory_key": "legacy-key",
        })

    assert persist_response.status_code == 422
    assert key_response.status_code == 422
    assert test_store.list_servers() == []


def test_client_reference_updates_the_same_external_inventory_item(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "external-mcp-stable.db")
    monkeypatch.setattr(main, "store", test_store)
    with TestClient(main.app) as client:
        first = client.post("/api/v1/score/mcp/requests", json={
            "payload": mcp_payload(),
            "name": "HR MCP v1",
            "client_reference": "hr-production",
        })
        second = client.post("/api/v1/score/mcp/requests", json={
            "payload": mcp_payload(),
            "name": "HR MCP v2",
            "client_reference": "hr-production",
        })
        assert first.status_code == second.status_code == 202

    items = test_store.list_servers()
    assert len(items) == 1
    assert items[0]["name"] == "HR MCP v2"
    assert items[0]["client_reference"] == "hr-production"


def test_invalid_mcp_payload_fails_before_job_creation(tmp_path, monkeypatch):
    test_store = Store(tmp_path / "invalid-mcp.db")
    monkeypatch.setattr(main, "store", test_store)
    with TestClient(main.app) as client:
        response = client.post("/api/v1/score/mcp/requests", json={"payload": "not-json"})
    assert response.status_code == 422
    assert response.json()["detail"]["code"] == "INVALID_MCP_JSON"
    assert test_store.score_jobs == []


def test_skill_archive_uses_nearest_skill_md_anchor_for_multiple_skills():
    payload = zip_archive({
        "bundle/alpha/SKILL.md": "# Alpha",
        "bundle/alpha/scripts/a.py": "print('a')",
        "bundle/alpha/nested/SKILL.md": "# Nested",
        "bundle/alpha/nested/scripts/n.py": "print('n')",
        "bundle/beta/SKILL.md": "# Beta",
        "bundle/beta/reference.md": "beta",
        "bundle/readme.txt": "not owned by a Skill",
    })
    packages = parse_skill_archive(payload, "skills.zip")
    assert [item["name"] for item in packages] == ["alpha", "beta", "nested"]
    by_name = {item["name"]: {file["path"] for file in item["files"]} for item in packages}
    assert by_name["alpha"] == {"SKILL.md", "scripts/a.py"}
    assert by_name["nested"] == {"SKILL.md", "scripts/n.py"}
    assert by_name["beta"] == {"SKILL.md", "reference.md"}


def test_skill_tar_archive_is_supported():
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        raw = b"# Tar Skill"
        item = tarfile.TarInfo("tar-skill/SKILL.md")
        item.size = len(raw)
        archive.addfile(item, io.BytesIO(raw))
    packages = parse_skill_archive(buffer.getvalue(), "tar-skill.tgz")
    assert len(packages) == 1
    assert packages[0]["name"] == "tar-skill"


def test_skill_archive_submit_and_poll_returns_all_packages(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "store", configured_store(tmp_path / "external-skill.db"))
    payload = zip_archive({
        "alpha/SKILL.md": "# Alpha\nSummarize public text.",
        "beta/SKILL.md": "# Beta\nFormat JSON.",
    })
    with TestClient(main.app) as client:
        submitted = client.post(
            "/api/v1/score/skill/requests",
            files={"file": ("skills.zip", payload, "application/zip")},
            data={"client_reference": "release-7"},
        )
        assert submitted.status_code == 202
        accepted = submitted.json()
        result = client.get(accepted["result_url"])
        assert result.status_code == 200
        body = result.json()
        assert body["status"] == "succeeded"
        assert body["result"]["package_count"] == 2
        assert {item["name"] for item in body["result"]["skills"]} == {"alpha", "beta"}


def test_skill_archive_job_isolates_one_package_timeout(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "store", configured_store(tmp_path / "external-skill-partial.db"))

    async def scan_one(name, _files, _settings, **_kwargs):
        if name == "beta":
            raise ScoreJobFailure("LLM_SCORING_FAILED", "model timeout")
        return {
            "name": name,
            "effective_risk": 20,
            "findings": [{"id": "CAP-002"}],
            "classification_status": "classified",
            "llm_analysis": {
                "status": "completed",
                "axis_coverage": {"capability": True, "exposure": True},
                "missing_axes": [],
            },
            "flow_llm_analysis": {"status": "not_required"},
            "flow_candidates": [],
        }

    monkeypatch.setattr(main, "scan_skill", scan_one)
    payload = zip_archive({
        "alpha/SKILL.md": "# Alpha\nRead public metadata.",
        "beta/SKILL.md": "# Beta\nFormat JSON.",
        "gamma/SKILL.md": "# Gamma\nRead public documentation.",
    })
    with TestClient(main.app) as client:
        submitted = client.post(
            "/api/v1/score/skill/requests",
            files={"file": ("skills.zip", payload, "application/zip")},
        )
        body = client.get(submitted.json()["result_url"]).json()

    assert body["status"] == "succeeded"
    assert body["result"]["requested_package_count"] == 3
    assert body["result"]["package_count"] == 2
    assert body["result"]["failed_count"] == 1
    assert body["result"]["failures"][0]["name"] == "beta"
    assert {item["name"] for item in body["result"]["skills"]} == {"alpha", "gamma"}


def test_skill_archive_without_skill_md_is_rejected(tmp_path, monkeypatch):
    test_store = Store(tmp_path / "invalid-skill.db")
    monkeypatch.setattr(main, "store", test_store)
    payload = zip_archive({"README.md": "no anchor"})
    with TestClient(main.app) as client:
        response = client.post(
            "/api/v1/score/skill/requests",
            files={"file": ("bad.zip", payload, "application/zip")},
        )
    assert response.status_code == 422
    assert response.json()["detail"]["code"] == "SKILL_ANCHOR_NOT_FOUND"
    assert test_store.score_jobs == []


def test_unsupported_archive_format_is_explicitly_rejected():
    try:
        parse_skill_archive(b"fake", "skills.7z")
    except PayloadFormatError as exc:
        assert exc.code == "UNSUPPORTED_SKILL_ARCHIVE"
    else:
        raise AssertionError("Expected PayloadFormatError")


def test_external_scoring_requires_a_configured_model(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "store", Store(tmp_path / "model-required.db"))
    with TestClient(main.app) as client:
        response = client.post("/api/v1/score/mcp/requests", json={"payload": mcp_payload()})
    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "MODEL_NOT_CONFIGURED"


def test_pending_job_omits_empty_result_and_error(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "pending-job.db")
    monkeypatch.setattr(main, "store", test_store)
    job = main._create_score_job("mcp", client_reference=None, input_summary={"tool_count": 1})
    with TestClient(main.app) as client:
        response = client.get(f"/api/v1/score/mcp/requests/{job['request_id']}")
    assert response.status_code == 200
    assert response.headers["Retry-After"] == "2"
    assert response.json()["status"] == "queued"
    assert "result" not in response.json()
    assert "error" not in response.json()
    assert "completed_at" not in response.json()


def test_runtime_llm_failure_is_returned_by_polling(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "llm-failed.db")
    monkeypatch.setattr(main, "store", test_store)

    async def failed_extract(_tool, _settings):
        raise main.QwenError("upstream unavailable")

    monkeypatch.setattr(main, "extract_tool", failed_extract)
    with TestClient(main.app) as client:
        accepted = client.post("/api/v1/score/mcp/requests", json={"payload": mcp_payload()})
        result = client.get(accepted.json()["result_url"])
    body = result.json()
    assert body["status"] == "failed"
    assert body["error"]["code"] == "LLM_SCORING_FAILED"
    assert "result" not in body


def test_unclassified_mcp_tool_is_returned_as_failed_job(tmp_path, monkeypatch):
    test_store = configured_store(tmp_path / "mcp-unclassified.db")
    monkeypatch.setattr(main, "store", test_store)

    async def incomplete_extract(_tool, _settings):
        return {
            "prompt_version": main.LLM_PROMPT_VERSION,
            "rule_set_version": main.RULE_SET_VERSION,
            "capability_rule_matches": [],
            "exposure_rule_matches": [],
            "security_rule_matches": [],
            "has_security_issue": False,
            "security_issue_types": [],
            "untrusted_content": {"detected": False, "confidence": 0, "evidence": []},
            "data_classes": ["unknown"],
            "unknowns": ["No supported CAP"],
            "__audit": {"model": "test", "latency_ms": 1},
        }

    monkeypatch.setattr(main, "extract_tool", incomplete_extract)
    with TestClient(main.app) as client:
        accepted = client.post("/api/v1/score/mcp/requests", json={"payload": mcp_payload()})
        result = client.get(accepted.json()["result_url"])
    body = result.json()
    assert body["status"] == "failed"
    assert body["error"]["code"] == "LLM_SCORING_FAILED"
    assert "有证据支持" in body["error"]["message"]
