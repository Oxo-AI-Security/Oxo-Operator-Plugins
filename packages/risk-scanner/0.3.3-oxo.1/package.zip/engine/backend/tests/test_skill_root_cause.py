from backend.tests.profile_fixtures import isolate_operation_profile
"""Counterexamples for lost hypotheses, executable control and FLOW shape.

No remote model, package execution, confidence upgrade or score fixture.
"""
import asyncio
from copy import deepcopy
import json
import pytest
from backend import skill_scanner as ss
from backend.application.skill_prompt import prepare_skill_messages
from backend.tests.test_skill_scanner import package


def versions(flow=False):
    return {'prompt_version': ss.SKILL_FLOW_PROMPT_VERSION if flow else ss.SKILL_PROMPT_VERSION,
            'rule_set_version': ss.SKILL_RULE_SET_VERSION}


def decision(c, **extra):
    return {'candidate_id': c['candidate_id'], 'valid': True, 'confidence': .9,
            'rationale': 'Source reviewed', 'exclusion_analysis': 'Specific exclusion reviewed', **extra}


def test_a_silent_verifier_omission_cannot_prove_a_zero_baseline(monkeypatch):
    text='If available, read the private team document. Otherwise format user text.\n'
    requests=[]
    async def fake(settings,messages,**kwargs):
        r=json.loads(messages[1]['content']);requests.append(r)
        if r.get('analysis_family'):
            rules=['CAP-003'] if r['analysis_family']=='capability' else ['EXP-003'] if r['analysis_family']=='exposure' else []
            return {**versions(),'candidates':[{'rule_id':i,'confidence':.9,'evidence_id':'E0-0','rationale':'A reachable private-document read'} for i in rules]},1
        if r.get('verification_family'):
            rules=['CAP-001'] if r['verification_family']=='capability' else ['EXP-003'] if r['verification_family']=='exposure' else []
            return {**versions(),'verified_candidates':[{'rule_id':i,'confidence':.9,'evidence_id':'E0-0','rationale':'Only use fallback text'} for i in rules]},1
        if r.get('semantic_adjudication'):
            # Even a model that tries to approve the zero cannot silently
            # ignore the discarded grounded hypothesis anymore.
            return {**versions(),'candidate_decisions':[decision(c,
                **({'source_reason':'The declared private-document read remains reachable; the fallback does not remove it.'}
                    if c.get('prior_semantic_reviews') else {})) for c in r['candidates']]},1
        if r.get('missing_axis'):
            assert r['baseline_alternatives'][0]['rule_id']=='CAP-003'
            return {**versions(),'candidate':None,'unknown':'Contradiction unresolved'},1
        raise AssertionError(r)
    monkeypatch.setattr(ss,'_chat',fake)
    result=asyncio.run(ss.scan_skill('conditional',package(('SKILL.md',text)),{'api_key':'offline'}))
    assert result['classification_status']=='classified'
    assert 'CAP-003' in {f['id'] for f in result['findings']}
    assert 'CAP-001' not in {f['id'] for f in result['findings']}
    final=next(r for r in requests if r.get('semantic_adjudication'))
    assert final['baseline_alternatives'][0]['evidence']['quote']==text
    assert any(r.get('validation_error')=='baseline_alternatives_not_reviewed' for r in result['llm_analysis']['rejected'])


def test_low_confidence_flow_is_never_retried_into_agreement(monkeypatch):
    calls=[]
    async def fake(settings,messages,**kwargs):
        calls.append(1);return {**versions(True),'flow_rule_matches':[{'rule_id':'FLOW-003','confidence':0,
            'participants':'[]','rationale':'Uncertain','data_path':'unknown'}]},1
    monkeypatch.setattr(ss,'_chat',fake)
    matches,audit=asyncio.run(ss._llm_flow_findings([{'path':'SKILL.md','text':'Uncertain'}],['FLOW-003'],[],[],{'api_key':'offline'}))
    assert not matches and len(calls)==1 and audit['status']=='incomplete'


def test_authenticated_content_and_conditional_actor_are_shared_in_every_pass():
    for stage in [{'analysis_family':'exposure'},{'verification_family':'exposure'},
                  {'missing_axis':'exposure'},{'semantic_adjudication':True,'candidates':[]}]:
        messages,_,_=prepare_skill_messages([{'role':'system','content':'Review'},
            {'role':'user','content':json.dumps({**stage,'package_excerpts':[{'path':'SKILL.md','content':'Read issue comments with OAuth.'}]})}],{},2400)
        assert 'Authentication, content origin, executable control and instruction priority are distinct properties' in messages[0]['content']
