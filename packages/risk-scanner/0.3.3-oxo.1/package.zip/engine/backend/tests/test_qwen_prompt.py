from __future__ import annotations

import asyncio
import json

from backend import qwen
from backend.rules import FLOW_PROMPT_VERSION, LLM_PROMPT_VERSION, RULE_SET_VERSION


def test_extract_tool_sends_versioned_rules_and_untrusted_metadata(monkeypatch):
    captured = []

    async def fake_chat(_settings, messages, *, max_tokens=800):
        request = json.loads(messages[1]["content"])
        captured.append((request, messages[0]["content"], max_tokens))
        common = {
            "prompt_version": LLM_PROMPT_VERSION,
            "rule_set_version": RULE_SET_VERSION,
            "unknowns": [],
        }
        if request["family"].startswith("capability"):
            return {**common, "capability_rule_matches": [{
                "rule_id": "CAP-003", "confidence": 0.95,
                "rationale": "Reads internal security logs.",
                "evidence": ["Search firewall access logs in Stellar Cyber."],
            }], "rejected_candidates": [], "data_classes": ["internal"]}, 1
        if request["family"] == "exposure":
            return {**common, "exposure_rule_matches": [], "untrusted_content": {
                "detected": False, "confidence": 0, "evidence": [],
            }}, 2
        return {**common, "has_security_issue": False, "security_issue_types": [], "security_rule_matches": []}, 3

    monkeypatch.setattr(qwen, "_chat", fake_chat)
    tool = {
        "name": "search_access_logs",
        "description": "Search firewall access logs in Stellar Cyber.",
        "inputSchema": {"type": "object", "properties": {"query": {"type": "string"}}},
        "annotations": {"readOnlyHint": True},
        "outputSchema": {"type": "object"},
    }
    result = asyncio.run(qwen.extract_tool(tool, {"model": "qwen-plus"}))

    assert [item[0]["family"] for item in captured] == ["capability", "exposure", "metadata", "capability_verifier"]
    request = captured[0][0]
    assert request["prompt_version"] == LLM_PROMPT_VERSION
    assert request["family_catalog"]["version"] == RULE_SET_VERSION
    assert len(request["family_catalog"]["capability_rules"]) == 18
    cap_016 = next(rule for rule in request["family_catalog"]["capability_rules"] if rule["id"] == "CAP-016")
    assert any("防火墙日志" in text for text in cap_016["exclude_when"])
    assert request["tool_metadata"]["description"] == tool["description"]
    assert request["tool_metadata"]["outputSchema"] == tool["outputSchema"]
    assert [item[2] for item in captured] == [1500, 1200, 1200, 1500]
    assert result["__audit"]["model"] == "qwen-plus"
    assert result["__audit"]["latency_ms"] == 7
    assert set(result["__audit"]["families"]) == {"capability", "exposure", "metadata"}
    assert result["__audit"]["families"]["capability"]["independently_verified"] is True
    assert result["__audit"]["received_at"]


def test_extract_server_flows_sends_complete_tools_facts_and_professional_rules(monkeypatch):
    captured = {}

    async def fake_chat(_settings, messages, *, max_tokens=800):
        captured["messages"] = messages
        captured["max_tokens"] = max_tokens
        return {
            "prompt_version": FLOW_PROMPT_VERSION,
            "rule_set_version": RULE_SET_VERSION,
            "flow_rule_matches": [],
            "rejected_candidates": [],
            "unknowns": ["runtime reachability is not declared"],
        }, 9

    monkeypatch.setattr(qwen, "_chat", fake_chat)
    source = {
        "name": "read_secret", "description": "Read a secret credential from the team vault.",
        "inputSchema": {"type": "object"}, "outputSchema": {"type": "string"},
        "annotations": {"readOnlyHint": True}, "capabilities": ["CAP-005"],
        "matched_rules": [], "data_classes": ["secret"], "classification_status": "classified",
    }
    sink = {
        "name": "send_email", "description": "Send content to any external recipient.",
        "inputSchema": {"type": "object", "properties": {"recipient": {"type": "string"}, "content": {"type": "string"}}},
        "annotations": {"openWorldHint": True}, "capabilities": ["CAP-010"],
        "matched_rules": [{"id": "EXP-005"}], "data_classes": ["unknown"], "classification_status": "classified",
    }
    server = {"name": "Vault Mail MCP", "description": "Vault and email operations", "tools": [source, sink]}
    result = asyncio.run(qwen.extract_server_flows(server, [source, sink], ["FLOW-002"], {"model": "qwen-plus"}))

    request = json.loads(captured["messages"][1]["content"])
    assert request["prompt_version"] == FLOW_PROMPT_VERSION
    assert request["candidate_rule_ids"] == ["FLOW-002"]
    assert len(request["flow_rule_catalog"]["flow_rules"]) == 5
    assert request["flow_rule_catalog"]["deterministic_only_rules"] == []
    flow_002 = next(rule for rule in request["flow_rule_catalog"]["flow_rules"] if rule["id"] == "FLOW-002")
    assert flow_002["required_facts"]
    assert flow_002["exclude_when"]
    assert flow_002["evidence_requirements"]
    assert request["tools"][0]["outputSchema"] == source["outputSchema"]
    assert request["validated_tool_facts"][1]["validated_capability_rule_ids"] == ["CAP-010"]
    assert "coexistence" in captured["messages"][0]["content"].lower()
    assert captured["max_tokens"] == 2600
    assert result["__audit"]["latency_ms"] == 9


def test_extract_tool_repairs_selected_rule_without_evidence(monkeypatch):
    calls = []

    async def fake_chat(_settings, messages, *, max_tokens=800):
        request = json.loads(messages[1]["content"])
        calls.append((request["family"], messages))
        if request["family"] == "capability" and len(messages) == 2:
            return {
                "prompt_version": LLM_PROMPT_VERSION,
                "rule_set_version": RULE_SET_VERSION,
                "capability_rule_matches": [{
                    "rule_id": "CAP-002",
                    "confidence": 0.95,
                    "rationale": "Reads the public web.",
                    "evidence": None,
                }],
                "exposure_rule_matches": [],
                "security_rule_matches": [],
            }, 3
        if request["family"] == "capability_verifier":
            if (request["first_pass"].get("capability_rule_matches") or [{}])[0].get("evidence"):
                return request["first_pass"], 4
            return {
                "prompt_version": LLM_PROMPT_VERSION,
                "rule_set_version": RULE_SET_VERSION,
                "capability_rule_matches": [{
                    "rule_id": "CAP-002", "confidence": 0.95,
                    "rationale": "Reads the public web.", "evidence": None,
                }],
                "rejected_candidates": [], "data_classes": ["public"], "unknowns": [],
            }, 4
        if request["family"] == "capability":
            return {
                "prompt_version": LLM_PROMPT_VERSION,
                "rule_set_version": RULE_SET_VERSION,
                "capability_rule_matches": [{
                    "rule_id": "CAP-002",
                    "confidence": 0.95,
                    "rationale": "Reads the public web.",
                    "evidence": ["Read public release notes from the open internet."],
                }],
                "rejected_candidates": [],
                "data_classes": ["public"],
                "unknowns": [],
            }, 5
        if request["family"] == "exposure":
            return {
                "prompt_version": LLM_PROMPT_VERSION,
                "rule_set_version": RULE_SET_VERSION,
                "exposure_rule_matches": [],
                "untrusted_content": {"detected": False, "confidence": 0, "evidence": []},
                "unknowns": [],
            }, 2
        return {
            "prompt_version": LLM_PROMPT_VERSION,
            "rule_set_version": RULE_SET_VERSION,
            "has_security_issue": False,
            "security_issue_types": [],
            "security_rule_matches": [],
            "unknowns": [],
        }, 2

    monkeypatch.setattr(qwen, "_chat", fake_chat)
    result = asyncio.run(qwen.extract_tool({
        "name": "release_notes",
        "description": "Read public release notes from the open internet.",
        "inputSchema": {"type": "object"},
    }, {"model": "qwen-plus"}))

    assert [item[0] for item in calls].count("capability") == 2
    assert [item[0] for item in calls].count("capability_verifier") == 2
    repair_messages = next(messages for family, messages in calls if family == "capability" and len(messages) > 2)
    assert "Repair only this rule family" in repair_messages[-1]["content"]
    assert result["capability_rule_matches"][0]["evidence"]
    assert result["__audit"]["latency_ms"] == 20
    assert result["__audit"]["families"]["capability"]["repaired"] is True


def test_extract_tool_removes_cap001_when_a_privileged_capability_also_matches(monkeypatch):
    async def fake_chat(_settings, messages, *, max_tokens=800):
        request = json.loads(messages[1]["content"])
        common = {"prompt_version": LLM_PROMPT_VERSION, "rule_set_version": RULE_SET_VERSION, "unknowns": []}
        if request["family"].startswith("capability"):
            return {**common, "capability_rule_matches": [
                {"rule_id": "CAP-001", "confidence": 0.9, "rationale": "Wrong baseline", "evidence": ["Execute caller supplied code."]},
                {"rule_id": "CAP-011", "confidence": 0.98, "rationale": "Executes code", "evidence": ["Execute caller supplied code."]},
            ], "rejected_candidates": [], "data_classes": ["unknown"]}, 1
        if request["family"] == "exposure":
            return {**common, "exposure_rule_matches": [], "untrusted_content": {"detected": False, "confidence": 0, "evidence": []}}, 1
        return {**common, "has_security_issue": False, "security_issue_types": [], "security_rule_matches": []}, 1

    monkeypatch.setattr(qwen, "_chat", fake_chat)
    result = asyncio.run(qwen.extract_tool({
        "name": "run_code", "description": "Execute caller supplied code.",
        "inputSchema": {"type": "object"},
    }, {"model": "qwen-plus"}))
    assert [item["rule_id"] for item in result["capability_rule_matches"]] == ["CAP-011"]
