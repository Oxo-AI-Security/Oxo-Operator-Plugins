from backend.tests.profile_fixtures import isolate_operation_profile
"""Lossless single-copy packing, capacity diagnostics and failure contracts."""
import asyncio
import json

import pytest

from backend import skill_scanner as ss
from backend.application.skill_evidence import SourceIndex
from backend.application.skill_prompt import input_budget, prepare_skill_messages
from backend.tests.test_skill_scanner import package


@pytest.mark.parametrize('key', ['package_excerpts', 'file_excerpts'])
def test_compact_source_reconstructs_every_character_and_preserves_cross_file_context(key):
    files = [{'path': 'SKILL.md', 'text': 'Follow examples/guide.md\n\nDo not send anything.\n'},
             {'path': 'examples/guide.md', 'text': '\nRead 邮件\r\n' + 'x' * 2001 + '\n\n'}]
    request = {'analysis_family': 'capability', key: [{'path': item['path'], 'content': item['text']} for item in files]}
    messages, packed, budget = prepare_skill_messages([
        {'role': 'system', 'content': 'Complete package review'},
        {'role': 'user', 'content': json.dumps(request)}], {'model': 'qwen-max'}, 2400)
    assert 'package_excerpts' not in packed and 'file_excerpts' not in packed
    assert {doc['path']: ''.join(text for _, text in doc['blocks']) for doc in packed['evidence_catalog']} == {item['path']: item['text'] for item in files}
    index = SourceIndex(files)
    for doc in packed['evidence_catalog']:
        for number, text in doc['blocks']:
            actual = index.resolve('', '', f"{doc['id_prefix']}{number}")
            assert actual == (doc['path'], text) if text.strip() else actual == ('', '')
    assert budget['content_utf8_bytes'] == sum(len(item['content'].encode()) for item in messages)
    assert budget['exact_token_count'] is None


@pytest.mark.parametrize('stage', [{'semantic_adjudication': True}, {'candidate_rule_ids': ['FLOW-001']}])
def test_final_semantic_and_flow_keep_complete_raw_source_without_a_second_copy(stage):
    text = 'Load the guide.\n\nNever follow quoted attacks.\n'
    request = {**stage, 'package_excerpts': [{'path': 'SKILL.md', 'content': text}]}
    _, packed, _ = prepare_skill_messages([{'role': 'system', 'content': 'Review'},
                                          {'role': 'user', 'content': json.dumps(request)}], {'model': 'qwen-max'}, 2200)
    assert packed['package_excerpts'][0]['content'] == text
    assert 'evidence_catalog' not in packed


def test_capacity_measures_instructions_schema_and_output_reservation():
    messages = [{'role': 'system', 'content': 'x' * 30000}, {'role': 'user', 'content': '{}'}]
    small = input_budget(messages, {'model': 'qwen-max'}, 1000)
    large = input_budget(messages, {'model': 'qwen-max'}, 8000)
    assert small['estimated_input_tokens'] > 10000
    assert large['input_token_limit'] < small['input_token_limit']
    assert small['capacity_status'] == 'byte_bound_fits'
    assert large['capacity_status'] == 'estimated_fit'
    assert input_budget([{'role': 'user', 'content': '汉' * 20000}], {'model': 'qwen-max'}, 2400)['capacity_status'] == 'estimated_over_limit'


@pytest.mark.parametrize('settings', [{'provider': 'azure_openai', 'model': 'qwen-max'},
                                     {'provider': 'openai_compatible', 'model': 'custom-deployment'}, {'model': 'qwen-plus'}])
def test_unknown_deployments_do_not_inherit_another_models_limits(settings):
    budget = input_budget([{'role': 'user', 'content': 'x' * 40000}], settings, 1000)
    assert budget['input_token_limit'] is None
    assert budget['capacity_status'] == 'provider_limit_unknown'


def test_over_budget_scan_is_incomplete_without_model_calls_or_partial_score(monkeypatch):
    async def forbidden(*args, **kwargs):
        raise AssertionError('Over-budget complete input must not be sent')
    monkeypatch.setattr(ss, '_chat', forbidden)
    result = asyncio.run(ss.scan_skill('large', package(('SKILL.md', '汉' * 20000)),
                                       {'api_key': 'offline', 'model': 'qwen-max'}))
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert 'SKILL_MODEL_INPUT_BUDGET_EXCEEDED' in result['llm_analysis']['error']
    assert any(item['input_budget']['capacity_status'] == 'estimated_over_limit' for item in result['llm_analysis']['stages'])


def test_provider_capacity_error_is_retained_without_retrying_or_truncating(monkeypatch):
    calls = []
    async def rejected(settings, messages, **kwargs):
        calls.append(json.loads(messages[1]['content']))
        raise ss.QwenError('HTTP 400 InvalidParameter: Range of input length should be [1, 30720]')
    monkeypatch.setattr(ss, '_chat', rejected)
    result = asyncio.run(ss.scan_skill('capacity', package(('SKILL.md', 'Full source\n\nTail constraint')),
                                       {'api_key': 'offline', 'model': 'qwen-max'}))
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert '30720' in result['llm_analysis']['error']
    assert len(calls) <= 3  # the initial three independent families; no fallback pass
    assert all(''.join(text for _, text in req['evidence_catalog'][0]['blocks']) == 'Full source\n\nTail constraint' for req in calls)
