"""Semantic identity, reference boundaries and independent scope counterexamples."""
from copy import deepcopy
import httpx
import pytest
from backend.application.skill_evidence import SourceIndex
from backend.application.skill_response_contract import response_schema, decode_decisions
from backend.infrastructure.ai.schema_validation import validation_errors
from backend.infrastructure.ai.receipt import provider_receipt, ModelReply
from backend.tests.test_profile_wire import flatten
from backend.tests.test_effect_execution_contract import case
from backend.application.skill_profile_wire import decode_operations


def test_directory_list_resolves_only_explicit_members_and_retains_original_edge():
    text='Reference files:\n- **examples/** - optional patterns:\n  - `alpha.py` - a pattern\n  - `beta.py` - another pattern\n- **assets/** - images\n\nUnscoped `hidden.py`.\n'
    index=SourceIndex([{'path':'SKILL.md','text':text}, *[
        {'path':path,'text':'print(1)\n'} for path in ['examples/alpha.py','examples/beta.py','examples/hidden.py','assets/alpha.py']]])
    for path in ['examples/alpha.py','examples/beta.py']:
        chain=index.procedure_reference_chain(path)
        assert len(chain)==1 and chain[0]['quote'] in text
        assert chain[0]['kind']=='unclassified_scoped_member_reference'
    assert not index.procedure_reference_chain('examples/hidden.py')
    assert not index.procedure_reference_chain('assets/alpha.py')


def test_free_target_and_single_resource_are_independent_from_privilege_and_activation():
    _, operation=case()
    row=flatten(operation)
    row.update(target_count='single_object',target_selection='free_target',privilege='ordinary',activation='explicit')
    row.update(invocation_target_count='multiple_objects',invocation_target_selection='fixed',
               invocation_privilege='privileged',invocation_activation='automatic')
    result=decode_operations([row])[0]
    assert set(result['reach'])=={'single_object','free_target'}
    assert set(result['invocation']['reach'])=={'fixed','multiple_objects','privileged','automatic'}


def test_final_disputed_verdict_is_single_and_required_by_identity():
    request={'semantic_adjudication':True,'candidates':[
        {'candidate_id':'a','prior_semantic_reviews':[{'outcome':'excluded'}]}, {'candidate_id':'b'}]}
    schema=response_schema(request)
    decisions={'a':{'valid':False,'confidence':.8,'rationale':'Source excludes executable control.',
        'exclusion_analysis':'The program is fixed; caller supplies data only.', 'source_reason':'Earlier read was data, not executable selection.'},
        'b':{'valid':True,'confidence':.9,'rationale':'Read operation.', 'exclusion_analysis':'No contradictory source.',
             'source_reason':'The source establishes a read.'}}
    raw={'candidate_decisions':decisions}
    assert not validation_errors(schema,raw)
    assert 'disputed_claim_decisions' not in schema['properties']
    assert decode_decisions(raw,request)['candidate_decisions'][0]['valid'] is False
    for defect in ['identity','source_reason','extra_vote']:
        bad=deepcopy(raw)
        if defect=='identity':del bad['candidate_decisions']['b']
        elif defect=='source_reason':del bad['candidate_decisions']['a']['source_reason']
        else:bad['disputed_claim_decisions']=[]
        assert validation_errors(schema,bad)


def test_catalog_verifier_cannot_silently_omit_a_rule_or_default_uncertainty_to_exclusion():
    request={'verification_family':'exposure','rule_catalog':[{'rule_id':'EXP-004'},{'rule_id':'EXP-005'}]}
    schema=response_schema(request)
    row={'verdict':'unknown','confidence':.4,'rationale':'Target selection is unresolved.',
         'exclusion_analysis':'No source proof either way.','evidence_id':None}
    raw={'rule_decisions':{'EXP-004':row,'EXP-005':row}}
    assert not validation_errors(schema,raw)
    decoded=decode_decisions(raw,request)
    assert not decoded['verified_candidates'] and not decoded['rejected_candidates']
    assert len(decoded['incomplete_axes'])==2
    del raw['rule_decisions']['EXP-005']
    assert validation_errors(schema,raw)


def test_receipt_identifies_model_parameters_and_variance_without_auth_headers():
    body={'model':'alias','temperature':0,'input':[{'content':'fixed source'}]}
    response=httpx.Response(200,headers={'x-request-id':'request-1'})
    first=provider_receipt('https://example.test/responses',body,{'id':'a','model':'revision-1','status':'completed'},response)
    second=provider_receipt('https://example.test/responses',body,{'id':'b','model':'revision-1','status':'completed'},response)
    assert first['request_sha256']==second['request_sha256']
    assert first['response_sha256']!=second['response_sha256']
    assert first['request_sha256']!=provider_receipt('https://example.test/responses',{**body,'model':'another'}, {},response)['request_sha256']
    assert first['system_fingerprint'] is None
    reply=ModelReply({'result':True},first)
    assert deepcopy(reply).receipt==first and reply=={'result':True}
