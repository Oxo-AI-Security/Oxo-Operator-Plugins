from backend.tests.profile_fixtures import isolate_operation_profile
"""Regression tests for retiring the optional trace-field protocol.

The former correction-protocol tests are archived with the v4.12 source snapshot.
Primary-source grounding and full semantic adjudication remain authoritative.
"""
import asyncio
from copy import deepcopy
import json

import pytest

from backend import skill_scanner as ss
from backend.application.skill_evidence import SourceIndex, primary_source_response
from backend.tests.test_skill_scanner import package


TEXT = "Style only the text supplied in this task.\nThe input and target are fixed.\n"
CSV = ','.join(f'E0-{i}' for i in range(1, 73))


@pytest.mark.parametrize('value', [None, '', 'E0-1', CSV, ['E0-1'], ['E999-1'], {'E1-10-12': 'unknown'}])
def test_retired_source_extensions_are_audited_without_becoming_proof(value):
    row = {'rule_id': 'CAP-001', 'evidence_id': 'E0-0', 'confidence': .9, 'rationale': 'Frozen classification',
           'supporting_evidence_ids': value, 'supporting_evidence': [{'path': 'secrets.txt', 'quote': 'invented proof'}]}
    raw = {'verified_candidates': [row]}; original = deepcopy(raw)
    cleaned, notes = primary_source_response(raw)
    assert raw == original
    assert cleaned == {'verified_candidates': [{key: val for key, val in row.items() if key not in {'supporting_evidence_ids', 'supporting_evidence'}}]}
    assert len(notes) == 2 and all(item['status'] == 'quarantined_not_used' for item in notes)
    assert notes[0]['value_type'] == type(value).__name__


@pytest.mark.parametrize('key', ['candidates', 'verified_candidates', 'behavior_facts', 'candidate'])
def test_every_consumed_candidate_container_uses_the_same_primary_contract(key):
    row = {'evidence_id': 'E0-0', 'supporting_evidence_ids': CSV}
    raw = {key: row if key == 'candidate' else [row]}
    cleaned, notes = primary_source_response(raw)
    result = cleaned[key] if key == 'candidate' else cleaned[key][0]
    assert result == {'evidence_id': 'E0-0'} and len(notes) == 1
    assert raw[key] == (row if key == 'candidate' else [row])


def run(monkeypatch, value, *, bad_primary=False, reject_final=False, obsolete_reply=False):
    requests = []
    versions = {'prompt_version': ss.SKILL_PROMPT_VERSION, 'rule_set_version': ss.SKILL_RULE_SET_VERSION}
    async def fake(settings, messages, **kwargs):
        request = json.loads(messages[1]['content']); requests.append(request)
        if 'malformed_evidence' in request:
            return {'prompt_version':ss.SKILL_PROMPT_VERSION,'rule_id':request['rule_id'],
                    'confidence':0,'unknown':'No valid source selection'},1
        assert 'supporting_evidence_ids' not in json.dumps(request)
        assert 'source_reference_correction' not in request
        if request.get('analysis_family'):
            family = request['analysis_family']
            rows = [{'rule_id': 'CAP-001' if family == 'capability' else 'EXP-001', 'confidence': .9,
                     'evidence_id': 'E0-0', 'rationale': 'Only fixed transformation of task-supplied content',
                     'supporting_evidence_ids': value}] if family != 'integrity' else []
            return {**versions, 'candidates': rows, 'behavior_facts': [], 'unknowns': []}, 1
        if request.get('verification_family'):
            if obsolete_reply:
                return {**versions, 'corrections': [{'supporting_evidence_ids': 'E0-1'}]}, 1
            family = request['verification_family']
            rows = [{'rule_id': 'CAP-001' if family == 'capability' else 'EXP-001', 'confidence': 1.0,
                     'evidence_id': 'E999-1' if bad_primary else 'E0-0', 'evidence': TEXT,
                     'rationale': 'Only fixed transformation of task-supplied content',
                     'supporting_evidence_ids': value}] if family != 'integrity' else []
            return {**versions, 'verified_candidates': rows}, 1
        if request.get('semantic_adjudication'):
            assert all('supporting_evidence' not in item and 'supporting_evidence_ids' not in item for item in request['candidates'])
            assert any(item['content'] == TEXT for item in request['package_excerpts'])
            return {**versions, 'candidate_decisions': [{'candidate_id': item['candidate_id'], 'valid': not reject_final,
                'confidence': .95, 'rationale': 'Reviewed the complete package and exact primary source',
                'exclusion_analysis': 'Only fixed transformation; no actual external or durable action'} for item in request['candidates']]}, 1
        if request.get('missing_axis'):
            return {**versions, 'candidate': None, 'unknown': 'No supported replacement'}, 1
        raise AssertionError(request)
    monkeypatch.setattr(ss, '_chat', fake)
    result = asyncio.run(ss.scan_skill('fixed-format', package(('SKILL.md', TEXT)), {'api_key': 'offline'}))
    return result, requests


@pytest.mark.parametrize('value', [None, '', CSV, ['E0-1']])
def test_real_failure_shapes_cannot_block_or_change_an_independently_proven_baseline(monkeypatch, value):
    result, requests = run(monkeypatch, value)
    assert result['classification_status'] == 'classified'
    assert {item['id'] for item in result['findings']} == {'CAP-001', 'EXP-001'}
    assert result['effective_risk'] == 0 and len(requests) == 7
    assert all('supporting_evidence' not in item for item in result['findings'])
    stages = [item for item in result['llm_analysis']['stages'] if item.get('unsupported_evidence_fields')]
    assert len(stages) == 4
    assert all(item['response'].get('candidates', item['response'].get('verified_candidates'))[0]['supporting_evidence_ids'] == value for item in stages)


@pytest.mark.parametrize('value', [None, CSV])
def test_retired_data_cannot_rescue_an_invalid_primary_even_when_matching_words_exist(monkeypatch, value):
    result, requests = run(monkeypatch, value, bad_primary=True)
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert not any(item.get('semantic_adjudication') for item in requests)
    assert any(item.get('validation_error') == 'source_reference_not_found_or_path_mismatch' for item in result['llm_analysis']['rejected'])


@pytest.mark.parametrize('value', [None, CSV])
def test_final_rejection_is_preserved_after_legacy_fields_are_quarantined(monkeypatch, value):
    result, requests = run(monkeypatch, value, reject_final=True)
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert any(item.get('missing_axis') for item in requests)
    assert any(item.get('validation_error') == 'final_semantic_adjudication_rejected' for item in result['llm_analysis']['rejected'])


def test_obsolete_correction_reply_cannot_substitute_for_verified_candidates(monkeypatch):
    result, _ = run(monkeypatch, None, obsolete_reply=True)
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert '独立源码复核' in result['llm_analysis']['error']


def test_opaque_manifest_files_cannot_shift_wire_or_local_primary_ids():
    files = [{'path': '00.bin', 'text': '', 'is_text': False}, {'path': '01.empty', 'text': ''},
             {'path': 'SKILL.md', 'text': TEXT}, {'path': 'scripts/run.py', 'text': 'do_work()\n'}]
    local = SourceIndex(files); wire = SourceIndex.from_documents(local.documents)
    assert local.by_id == wire.by_id
    assert local.resolve('', '', 'E0-0') == ('SKILL.md', TEXT.splitlines(keepends=True)[0])
    assert {doc['path'] for doc in local.documents} == {'SKILL.md', 'scripts/run.py'}
