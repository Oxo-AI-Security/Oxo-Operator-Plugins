"""A complete local reference chain is context, never automatic execution proof."""
import pytest
from backend.application.skill_evidence import SourceIndex
from backend.application.skill_profile import _ground, _resolve_sources
from backend.tests.test_skill_operation_profile import operation


def sources():
    return SourceIndex([
        {'path':'SKILL.md','text':'Follow guides/trace.md for investigation.\n'},
        {'path':'guides/trace.md','text':'Use ../scripts/helper.sh for the requested diagnostic.\n'},
        {'path':'scripts/helper.sh','text':'Run a diagnostic.\n'},
        {'path':'fixture.md','text':'Quoted hypothetical procedure.\n'},
        {'path':'cycle-a.md','text':'See cycle-b.md.\n'},
        {'path':'cycle-b.md','text':'See cycle-a.md.\n'},
    ])


def test_transitive_entry_has_every_exact_rooted_edge_and_does_not_promote_unlinked_cycles():
    index=sources()
    chain=index.procedure_reference_chain('scripts/helper.sh')
    assert [(edge['path'],edge['target_path']) for edge in chain]==[
        ('SKILL.md','guides/trace.md'),('guides/trace.md','scripts/helper.sh')]
    assert all(edge['quote'] in index.texts[edge['path']] for edge in chain)
    assert not index.procedure_reference_chain('fixture.md')
    assert not index.procedure_reference_chain('cycle-a.md')
    assert not index.procedure_reference_chain('../outside.md')


def test_suffix_matches_and_external_links_cannot_fabricate_a_local_chain():
    index=SourceIndex([{'path':'SKILL.md','text':'Mention notfixture.md and https://external.test/fixture.md only.\n'},
                       {'path':'fixture.md','text':'Unlinked fixture.\n'}])
    assert not index.procedure_reference_chain('fixture.md')


def test_citation_resolution_is_distinct_from_runtime_entry_activation():
    index=sources()
    citation=next(row['evidence_id'] for row in index.catalog if row['path']=='fixture.md')
    effect={**operation(),'entry_evidence_id':citation,'action_evidence_id':citation,'input_evidence_id':citation}
    assert _resolve_sources(effect,index)['source_evidence']['entry_evidence']['path']=='fixture.md'
    with pytest.raises(ValueError,match='manifest-referenced'): _ground(effect,index)
    grounded=_ground({**effect,'actor':'inert'},index)
    assert grounded['actor']=='inert' and 'entry_reference_chain' not in grounded
