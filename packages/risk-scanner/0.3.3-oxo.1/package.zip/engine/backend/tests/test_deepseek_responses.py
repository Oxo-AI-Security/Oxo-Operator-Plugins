"""Responses transport keeps the same local contract and rejection boundaries."""
import asyncio
from copy import deepcopy
import json
import pytest
from backend.infrastructure.ai import qwen
from backend.infrastructure.ai.capabilities import CAPABILITY_SCHEMA
from backend.infrastructure.ai.contracts import structured_chat, ModelContractError
from backend.infrastructure.ai.structured_output import responses_content
from backend.tests.test_structured_output import mocked_provider


def payload():
    return {'object': 'response', 'status': 'completed', 'output': [{
        'type': 'message', 'role': 'assistant', 'status': 'completed',
        'content': [{'type': 'output_text', 'text': '{"contract_tag":"skill-contract-v1","items":[]}'}],
    }]}


def test_native_response_schema_and_original_messages_are_transmitted(monkeypatch):
    calls = mocked_provider(monkeypatch, payload())
    schema = deepcopy(CAPABILITY_SCHEMA)
    messages = [{'role': 'system', 'content': 'fixed'}, {'role': 'user', 'content': 'all source'}]
    result, _, _ = asyncio.run(structured_chat(qwen._chat, {
        'provider': 'deepseek', 'api_key': 'offline-key'}, messages, schema=schema, max_tokens=900))
    assert result['contract_tag'] == 'skill-contract-v1'
    assert len(calls) == 1 and str(calls[0].url) == 'https://api.deepseek.com/responses'
    body = json.loads(calls[0].content)
    assert body['input'] == messages and body['text']['format']['schema'] == CAPABILITY_SCHEMA == schema
    assert body['reasoning']['effort'] == 'none' and 'tools' not in body
    assert body['text']['format']['strict'] is True


@pytest.mark.parametrize('failure', ['incomplete', 'failed', 'refusal', 'tool', 'multiple', 'error', 'partial_message'])
def test_partial_refused_tool_or_multiple_answers_fail(failure):
    data = payload()
    if failure in {'incomplete', 'failed'}: data['status'] = failure
    elif failure == 'error': data['error'] = {'message': 'failed'}
    elif failure == 'refusal': data['output'][0]['content'][0]['type'] = 'refusal'
    elif failure == 'tool': data['output'][0]['type'] = 'function_call'
    elif failure == 'partial_message': data['output'][0]['status'] = 'in_progress'
    else: data['output'] *= 2
    with pytest.raises(ValueError): responses_content(data)


def test_wrong_enum_fails_without_retry_or_legacy_route_fallback(monkeypatch):
    data = payload()
    data['output'][0]['content'][0]['text'] = '{"contract_tag":"wrong-value","items":[]}'
    calls = mocked_provider(monkeypatch, data)
    with pytest.raises(ModelContractError):
        asyncio.run(structured_chat(qwen._chat, {'provider': 'deepseek', 'api_key': 'offline-key'}, [],
                                    schema=CAPABILITY_SCHEMA, max_tokens=900))
    assert len(calls) == 1
