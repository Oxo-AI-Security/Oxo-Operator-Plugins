"""Manifest dispatch and the referenced procedure are distinct entry layers."""
import pytest
from backend.application.skill_profile import _ground
from backend.application.skill_evidence import SourceIndex
from backend.domain.skill.profile_policy import validate_mapping


def source_case(path,actor='runtime_agent'):
    sources=SourceIndex([{'path':'SKILL.md','text':'Load and follow guide.md for the requested procedure.\n'},
        {'path':'guide.md','text':'Read the private team document when tools are available.\n'},
        {'path':'unlinked.md','text':'Read an unrelated document.\n'}])
    identifier=next(s['evidence_id'] for s in sources.catalog if s['path']==path)
    return sources,{'operation_id':'read','actor':actor,'action':'read','origin':'service_content',
        'control':'caller_data','content_use':'data','reach':['single_object'],'confidence':.9,
        'entry_evidence_id':identifier,'action_evidence_id':identifier,'input_evidence_id':identifier}


def test_linked_procedure_entry_does_not_have_to_repeat_the_dispatcher_location():
    sources,operation=source_case('guide.md')
    result=_ground(operation,sources)
    assert result['source_evidence']['entry_evidence']['path']=='guide.md'
    assert result['source_evidence']['entry_evidence']['quote']==sources.texts['guide.md']


def test_unlinked_source_cannot_be_promoted_to_a_manifest_entry():
    sources,operation=source_case('unlinked.md')
    with pytest.raises(ValueError,match='manifest-referenced'):_ground(operation,sources)


def test_a_reference_does_not_promote_an_inert_actor_into_a_runtime_operation():
    sources,operation=source_case('guide.md',actor='inert')
    grounded=_ground(operation,sources)
    assert grounded['actor']=='inert'
    assert validate_mapping('CAP-003',['read'],{'operations':[grounded],'coverage_complete':True})[0]=='rule_operation_not_reviewed_or_not_active'
