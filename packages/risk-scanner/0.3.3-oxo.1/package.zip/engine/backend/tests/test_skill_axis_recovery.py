from backend.tests.profile_fixtures import isolate_operation_profile
"""Offline acceptance-contract tests for static Skills and post-review gaps."""
from backend.tests.scripted_skill_chat import ScriptedSkillChat

import asyncio
import json

import pytest
from fastapi.testclient import TestClient

from backend import main, skill_scanner as ss
from backend.store import Store
from backend.tests.test_skill_archive_import import archive, configured_store, completed_scan
from backend.tests.test_skill_scanner import package


TEXT = "Apply packaged color and writing guidelines to text supplied in this task. The input and target are fixed."


def reply(**values):
    return {"prompt_version": ss.SKILL_PROMPT_VERSION, "rule_set_version": ss.SKILL_RULE_SET_VERSION,
            "unknowns": [], "candidates": [], **values}


def row(rule, quote=TEXT, confidence=.95):
    return {"rule_id": rule, "path": "SKILL.md", "evidence": quote, "confidence": confidence,
            "rationale": "Evaluate complete declared styling and writing behavior."}


def run(monkeypatch, *, baselines=False, recover="valid", keep_nonzero=False):
    requests = []; finals = 0
    async def fake(_settings, messages, *, max_tokens=800):
        nonlocal finals
        request = json.loads(messages[1]["content"]); requests.append(request)
        family = request.get("analysis_family")
        if family:
            rows = [row("CAP-006")] if family == "capability" else [row("EXP-005")] if family == "exposure" else []
            if baselines and rows:
                rows.append(row("CAP-001" if family == "capability" else "EXP-001"))
            return reply(candidates=rows), 1
        if request.get("challenge_family"):
            return reply(), 1
        if request.get("verification_family"):
            return reply(confirmed_candidates=chat.proposals(request), added_axis_candidates=[], incomplete_axes=[]), 1
        if request.get("semantic_adjudication"):
            finals += 1
            return reply(candidate_decisions=[{
                "candidate_id": item["candidate_id"],
                "valid": keep_nonzero or item["rule_id"] in {"CAP-001", "EXP-001"},
                "confidence": .95,
                "rationale": "The workflow only transforms task-supplied text; no durable file write or free target is declared.",
                "exclusion_analysis": "A conditional static baseline remains valid when the unsupported nonzero candidate is rejected.",
            } for item in request["candidates"]]), 1
        if request.get("missing_axis"):
            if recover == "unknown":
                return reply(candidate=None, unknown="Cannot prove a baseline"), 1
            rule = "CAP-001" if request["missing_axis"] == "capability" else "EXP-001"
            return reply(candidate=row(rule, "invented evidence" if recover == "ungrounded" else TEXT,
                                       .1 if recover == "weak" else .95)), 1
        if "malformed_evidence" in request:
            return reply(rule_id=request["rule_id"], evidence="", confidence=0, unknown="No exact source"), 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("static-guidance", package(("SKILL.md", TEXT)), {"api_key": "offline-fixture"}))
    return result, requests, finals


def test_conditional_baselines_survive_until_competing_candidates_are_reviewed(monkeypatch):
    result, requests, finals = run(monkeypatch, baselines=True)
    assert result["classification_status"] == "classified"
    assert {item["id"] for item in result["findings"]} == {"CAP-001", "EXP-001"}
    assert result["effective_risk"] == 0
    assert not any(item.get("missing_axis") for item in requests)
    assert finals == 1


def test_supported_nonzero_behavior_still_excludes_baselines(monkeypatch):
    result, _, _ = run(monkeypatch, baselines=True, keep_nonzero=True)
    assert {item["id"] for item in result["findings"]} == {"CAP-006", "EXP-005"}
    assert result["effective_risk"] > 0


def test_axes_removed_by_final_review_receive_one_grounded_recovery(monkeypatch):
    result, requests, finals = run(monkeypatch)
    assert result["classification_status"] == "classified"
    assert {item["id"] for item in result["findings"]} == {"CAP-001", "EXP-001"}
    assert finals == 2
    recoveries = [item for item in requests if item.get("missing_axis")]
    assert len(recoveries) == 2 and all(item["prior_rejections"] for item in recoveries)
    assert all(item["axis_recovery_after_adjudication"] for item in recoveries)
    assert len(result["llm_analysis"]["stages"]) == len(requests)


@pytest.mark.parametrize("recovery", ["unknown", "weak", "ungrounded"])
def test_unsupported_recovery_stays_incomplete_without_inventing_baseline(monkeypatch, recovery):
    result, requests, _ = run(monkeypatch, recover=recovery)
    assert result["classification_status"] == "incomplete"
    assert not result["findings"]
    assert len([item for item in requests if item.get("missing_axis")]) == 2
    assert result["llm_analysis"]["candidate_verification"]["semantic_adjudication"]["rejected"]


def test_invalid_stage_reply_is_retained_before_contract_failure(monkeypatch):
    async def fake(*args, **kwargs):
        return {"prompt_version": "stale", "rule_set_version": ss.SKILL_RULE_SET_VERSION, "candidates": []}, 1
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("static", package(("SKILL.md", TEXT)), {"api_key": "offline"}))
    audit = result["llm_analysis"]
    assert audit["status"] == "error"
    assert audit["stages"] and audit["stages"][0]["response"]["prompt_version"] == "stale"


def test_failed_upload_preserves_attempt_audit_in_response_and_inventory(tmp_path, monkeypatch):
    store = configured_store(tmp_path / "failed-audit.db")
    monkeypatch.setattr(main, "store", store)
    async def fake(name, files, _settings, **kwargs):
        result = completed_scan(name, files)
        result["classification_status"] = "incomplete"
        result["llm_analysis"] = {"status": "incomplete", "axis_coverage": {"capability": False, "exposure": True},
                                  "missing_axes": ["capability"], "stages": [{"stage": "semantic_adjudication", "response": {"reason": "fixture rejection"}}]}
        result["settings"] = {"api_key": "must-not-be-in-diagnostics"}
        return result
    monkeypatch.setattr(main, "scan_skill", fake)
    with TestClient(main.app) as client:
        response = client.post("/api/skills/import-archive", files={"file": ("guidance.zip", archive({"SKILL.md": TEXT}), "application/zip")})
    body = response.json()
    assert body["failed"] == 1 and body["scanned"] == 0
    diagnostic = body["failures"][0]["analysis"]
    assert diagnostic["llm_analysis"]["missing_axes"] == ["capability"]
    assert diagnostic["is_scored_result"] is False
    assert "must-not-be-in-diagnostics" not in json.dumps(body)
    stored = store.list_skills()[0]["latest_scan"]
    assert stored["failed_attempt"] == diagnostic
    assert "effective_risk" not in stored


def test_worker_restart_marks_interrupted_skill_without_restarting_scan(tmp_path):
    store = Store(tmp_path / "restart.db")
    store.upsert_skill({"id": "in-flight", "latest_scan": {"analysis_status": "running", "classification_status": "running", "snapshot_hash": "fixture"}})
    store.upsert_skill({"id": "already-failed", "latest_scan": {"analysis_status": "error", "analysis_error_code": "LLM_SCORING_INCOMPLETE"}})
    store.upsert_server({"id": "keep-mcp", "name": "Existing MCP"})
    restarted = Store(tmp_path / "restart.db")
    scan = restarted.get_skill("in-flight")["latest_scan"]
    assert scan["analysis_error_code"] == "WORKER_RESTARTED" and scan["analysis_status"] == "error"
    assert scan["interruption"]["auto_resumed"] is False
    assert "effective_risk" not in scan
    assert restarted.get_skill("already-failed")["latest_scan"]["analysis_error_code"] == "LLM_SCORING_INCOMPLETE"
    assert restarted.get_server("keep-mcp")["name"] == "Existing MCP"


def test_startup_migration_does_not_fabricate_scores_for_failed_or_interrupted_uploads(tmp_path, monkeypatch):
    store = Store(tmp_path / "migration.db")
    for status in ["error", "incomplete"]:
        store.upsert_skill({"id": status, "fingerprint_hash": "fixture", "latest_scan": {
            "analysis_status": status, "classification_status": status,
            "analysis_error_code": "WORKER_RESTARTED", "files": [],
        }})
    monkeypatch.setattr(main, "store", store)
    asyncio.run(main.migrate_rule_results())
    for skill in store.list_skills():
        scan = skill["latest_scan"]
        assert scan["classification_status"] == skill["id"]
        assert "effective_risk" not in scan and "decision" not in scan
