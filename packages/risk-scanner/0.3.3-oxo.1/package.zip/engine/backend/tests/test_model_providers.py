from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from backend import main
from backend.api.schemas import ModelSettingsInput
from backend.qwen import _adapt_unsupported_parameters, _azure_chat_url, _parse_json_content, _request_parts, public_settings
from backend.store import Store


def azure_settings(**changes):
    settings = {
        "provider": "azure_openai",
        "model": "gpt-4o",
        "azure_deployment": "gpt-4o-prod",
        "azure_endpoint": "https://example-resource.openai.azure.com",
        "api_key": "azure-secret-key-value",
    }
    settings.update(changes)
    return settings


def test_azure_foundry_uses_v1_route_deployment_and_api_key_header():
    url, headers, body = _request_parts(
        azure_settings(),
        [{"role": "user", "content": "Return JSON."}],
        120,
    )

    assert url == "https://example-resource.openai.azure.com/openai/v1/chat/completions"
    assert headers == {
        "api-key": "azure-secret-key-value",
        "Content-Type": "application/json",
    }
    assert "Authorization" not in headers
    assert body["model"] == "gpt-4o-prod"
    assert body["response_format"] == {"type": "json_object"}
    assert body["max_tokens"] == 120
    assert body["temperature"] == 0


def test_azure_gpt5_uses_reasoning_model_token_contract():
    _, _, body = _request_parts(
        azure_settings(model="gpt-5.6-sol", azure_deployment="gpt-5.6-sol"),
        [{"role": "user", "content": "Return JSON."}],
        240,
    )

    assert body["model"] == "gpt-5.6-sol"
    assert body["max_completion_tokens"] == 240
    assert "max_tokens" not in body
    assert "temperature" not in body


def test_explicit_provider_parameter_error_can_upgrade_unknown_model_contract():
    body = {"model": "future-reasoner", "max_tokens": 120, "temperature": 0}

    adapted = _adapt_unsupported_parameters(
        body,
        "Unsupported parameter: 'max_tokens'. Use 'max_completion_tokens' instead.",
    )

    assert adapted == {"model": "future-reasoner", "max_completion_tokens": 120}
    assert body == {"model": "future-reasoner", "max_tokens": 120, "temperature": 0}


def test_explicit_provider_error_can_remove_unsupported_response_format():
    body = {"model": "deepseek-flash", "max_tokens": 120, "response_format": {"type": "json_object"}}

    adapted = _adapt_unsupported_parameters(body, "Unknown parameter: response_format is not supported")

    assert adapted == {"model": "deepseek-flash", "max_tokens": 120}


def test_markdown_fenced_json_from_compatible_provider_is_parsed():
    assert _parse_json_content('```json\n{"matched_rule_ids": ["CAP-001"]}\n```') == {
        "matched_rule_ids": ["CAP-001"],
    }


def test_azure_complete_portal_url_and_query_are_preserved():
    endpoint = (
        "https://example-resource.openai.azure.com/openai/deployments/gpt-4o-prod/"
        "chat/completions?api-version=2024-10-21"
    )
    assert _azure_chat_url(azure_settings(azure_endpoint=endpoint)) == endpoint
    url, headers, body = _request_parts(
        azure_settings(azure_endpoint=endpoint),
        [{"role": "user", "content": "Return JSON."}],
        120,
    )
    assert url == endpoint
    assert headers["api-key"] == "azure-secret-key-value"
    assert "model" not in body


def test_openai_compatible_provider_keeps_bearer_contract():
    url, headers, body = _request_parts(
        {
            "provider": "openai_compatible",
            "model": "qwen-plus",
            "base_url": "https://example.test/v1",
            "api_key": "compatible-key",
        },
        [{"role": "user", "content": "Return JSON."}],
        80,
    )

    assert url == "https://example.test/v1/chat/completions"
    assert headers["Authorization"] == "Bearer compatible-key"
    assert "api-key" not in headers
    assert body["model"] == "qwen-plus"


def test_public_azure_settings_never_return_the_full_key():
    result = public_settings(azure_settings())

    assert result["configured"] is True
    assert result["provider"] == "azure_openai"
    assert result["azure_deployment"] == "gpt-4o-prod"
    assert result["azure_endpoint"] == "https://example-resource.openai.azure.com"
    assert result["key_masked"] != "azure-secret-key-value"
    assert "api_key" not in result


def test_azure_settings_require_endpoint_and_deployment():
    with pytest.raises(ValidationError):
        ModelSettingsInput(
            provider="azure_openai",
            model="gpt-4o",
            azure_endpoint="https://example-resource.openai.azure.com",
            azure_deployment="",
        )

    with pytest.raises(ValidationError):
        ModelSettingsInput(
            provider="azure_openai",
            model="gpt-4o",
            azure_endpoint="http://example-resource.openai.azure.com",
            azure_deployment="gpt-4o",
        )


def test_switching_provider_never_reuses_the_previous_cloud_key(tmp_path, monkeypatch):
    isolated_store = Store(tmp_path / "provider-switch.db")
    isolated_store.save_model_settings({
        "provider": "openai_compatible",
        "model": "qwen-plus",
        "base_url": "https://example.test/v1",
        "azure_endpoint": "",
        "azure_deployment": "",
        "api_key": "alibaba-only-secret",
    })
    monkeypatch.setattr(main, "store", isolated_store)

    response = TestClient(main.app).put("/api/settings/model", json={
        "provider": "azure_openai",
        "model": "gpt-4o",
        "base_url": "https://example.test/v1",
        "azure_endpoint": "https://example-resource.openai.azure.com",
        "azure_deployment": "gpt-4o-prod",
        "api_key": None,
    })

    assert response.status_code == 200
    assert response.json()["configured"] is False
    assert isolated_store.model_settings["api_key"] is None
