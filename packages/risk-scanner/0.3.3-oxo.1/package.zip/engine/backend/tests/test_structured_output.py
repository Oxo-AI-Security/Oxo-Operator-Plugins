"""Strict provider wire compatibility and fail-closed result extraction."""
import asyncio
from copy import deepcopy
import json

import httpx
import pytest

from backend.infrastructure.ai import capabilities, qwen
from backend.infrastructure.ai.contracts import structured_chat, ModelContractError
from backend.infrastructure.ai.structured_output import (
    CONTRACT_FUNCTION, JSON_SCHEMA, STRICT_FUNCTION, completion_content, schema_transport,
)


def settings(**changes):
    return {
        'provider': 'openai_compatible', 'model': 'deepseek-flash',
        'base_url': 'https://api.deepseek.com', 'api_key': 'offline-key', **changes,
    }


def function_payload(value=None):
    return {'choices': [{'finish_reason': 'tool_calls', 'message': {
        'content': '', 'tool_calls': [{'type': 'function', 'function': {
            'name': CONTRACT_FUNCTION,
            'arguments': json.dumps(value or {'contract_tag': 'wrong-value', 'items': []}),
        }}],
    }}]}


def mocked_provider(monkeypatch, payload):
    calls = []
    client = httpx.AsyncClient

    async def respond(request):
        calls.append(request)
        return httpx.Response(200, json=payload)

    monkeypatch.setattr(qwen.httpx, 'AsyncClient', lambda **kwargs: client(transport=httpx.MockTransport(respond), **kwargs))
    return calls


@pytest.mark.parametrize('base_url', ['https://api.deepseek.com', 'https://api.deepseek.com/v1', 'https://api.deepseek.com/beta'])
def test_official_schema_requests_use_beta_strict_function_and_preserve_original_schema(base_url):
    schema = deepcopy(capabilities.CAPABILITY_SCHEMA)
    original = deepcopy(schema)
    url, headers, body = qwen._request_parts(settings(base_url=base_url, _response_schema=schema), [], 800)
    assert url == 'https://api.deepseek.com/beta/chat/completions'
    assert headers['Authorization'] == 'Bearer offline-key'
    assert 'response_format' not in body
    assert body['tools'][0]['function']['parameters'] == schema == original
    assert body['tools'][0]['function']['strict'] is True
    assert body['thinking'] == {'type': 'disabled'}
    assert body['tool_choice']['function']['name'] == CONTRACT_FUNCTION
    assert 'max_tokens' not in body


def test_dialect_selection_does_not_change_foundry_gateways_or_plain_mcp_requests():
    for value in [settings(provider='azure_openai'), settings(base_url='https://api.deepseek.com.example.test'),
                  settings(base_url='https://gateway.test/v1')]:
        assert schema_transport(value) == JSON_SCHEMA
    url, _, plain = qwen._request_parts(settings(), [], 120)
    assert url == 'https://api.deepseek.com/chat/completions'
    assert plain['response_format'] == {'type': 'json_object'}
    assert plain['max_tokens'] == 120 and 'tools' not in plain


@pytest.mark.parametrize('failure', ['wrong_name', 'multiple_calls', 'missing_calls', 'extra_content', 'refusal', 'aborted', 'length'])
def test_invalid_function_envelopes_cannot_be_interpreted_as_a_result(failure):
    choice = function_payload()['choices'][0]
    message = choice['message']
    if failure == 'wrong_name':
        message['tool_calls'][0]['function']['name'] = 'run_command'
    elif failure == 'multiple_calls':
        message['tool_calls'] *= 2
    elif failure == 'missing_calls':
        message['tool_calls'] = []
    elif failure == 'extra_content':
        message['content'] = '{"contract_tag":"skill-contract-v1","items":[]}'
    elif failure == 'refusal':
        message['refusal'] = 'refused'
    else:
        choice['finish_reason'] = failure
    with pytest.raises(ValueError):
        completion_content(choice, STRICT_FUNCTION)


def test_observed_deepseek_wrong_enum_is_rejected_without_format_repair(monkeypatch):
    # Minimal response shape from the preserved native preflight, replayed offline.
    calls = mocked_provider(monkeypatch, function_payload())
    with pytest.raises(ModelContractError):
        asyncio.run(structured_chat(qwen._chat, settings(), [{'role': 'user', 'content': 'Fixed request.'}],
                                    schema=capabilities.CAPABILITY_SCHEMA, max_tokens=800))
    assert len(calls) == 1


def test_contract_probe_reports_real_protocol_without_relabeling_http_success(monkeypatch):
    calls = mocked_provider(monkeypatch, function_payload())
    capabilities._CAPABILITY_CACHE.clear()
    result = asyncio.run(capabilities.probe_contract(qwen._chat, settings()))
    assert result['format'] == STRICT_FUNCTION and result['supported'] is False
    assert result['validation_errors'][0]['validator'] == 'enum'
    assert len(calls) == 1
    capabilities._CAPABILITY_CACHE.clear()


def test_malformed_native_function_arguments_are_never_resampled(monkeypatch):
    payload = function_payload()
    payload['choices'][0]['message']['tool_calls'][0]['function']['arguments'] = '{'
    calls = mocked_provider(monkeypatch, payload)
    with pytest.raises(qwen.ModelResponseError, match='合法 JSON') as failure:
        asyncio.run(qwen._chat(settings(_response_schema=capabilities.CAPABILITY_SCHEMA), []))
    assert len(calls) == 1
    assert failure.value.audit['raw_content'] == '{'
    assert failure.value.audit['finish_reason'] == 'tool_calls'
    assert failure.value.audit['json_error']['offset'] == 1


def test_invalid_argument_diagnostics_redact_the_configured_key(monkeypatch):
    payload = function_payload()
    payload['choices'][0]['message']['tool_calls'][0]['function']['arguments'] = '{"echo":"offline-key",'
    calls = mocked_provider(monkeypatch, payload)
    with pytest.raises(qwen.ModelResponseError) as failure:
        asyncio.run(qwen._chat(settings(_response_schema=capabilities.CAPABILITY_SCHEMA), []))
    assert 'offline-key' not in json.dumps(failure.value.audit)
    assert '[REDACTED]' in failure.value.audit['raw_content']
    assert len(calls) == 1


@pytest.mark.parametrize('choice', [None, {'message': []}, {'finish_reason': 'tool_calls', 'message': {'tool_calls': [None]}}])
def test_invalid_envelope_types_are_rejected_as_provider_protocol_errors(choice):
    with pytest.raises(ValueError):
        completion_content(choice, STRICT_FUNCTION)


def test_an_incompatible_function_provider_is_blocked_before_sample_content_is_sent(monkeypatch):
    from backend.application import skill_scanner as scanner
    from backend.tests.test_skill_scanner import package

    calls = mocked_provider(monkeypatch, function_payload())
    capabilities._CAPABILITY_CACHE.clear()
    sample_text = 'Read the selected confidential file.'
    result = asyncio.run(scanner.scan_skill('fixture', package(('SKILL.md', sample_text)), settings()))
    assert result['llm_analysis']['error'].startswith('MODEL_SCHEMA_UNSUPPORTED')
    assert not result['findings'] and not result['llm_analysis'].get('stages')
    assert len(calls) == 1 and sample_text not in calls[0].content.decode()
    capabilities._CAPABILITY_CACHE.clear()
