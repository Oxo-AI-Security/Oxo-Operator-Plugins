from backend.tests.profile_fixtures import isolate_operation_profile
"""Navigation is source orientation; all rule and semantic gates still apply."""
import asyncio
import json

import pytest

from backend import skill_scanner as ss
from backend.application.skill_evidence import SourceIndex
from backend.application import skill_navigation as navigation
from backend.application.skill_prompt import prepare_skill_messages
from backend.tests.test_skill_scanner import package


ROOT = 'Use scripts/job.py for task-provided commands.\n'
CODE = '''"""Documentation: subprocess.Popen("example", shell=True)"""
import subprocess
def job(args):
    child = subprocess.Popen(args.command, shell=True)
    child.wait()
'''


def sources(code=CODE):
    return SourceIndex([{'path': 'SKILL.md', 'text': ROOT}, {'path': 'scripts/job.py', 'text': code}])


def test_actual_calls_are_separate_from_docstring_examples_and_preserve_exact_locations():
    index = sources(); result = navigation.python_call_navigation(index)
    assert result['kind'] == 'syntactic_navigation_not_semantic_evidence'
    calls = result['files'][0]['calls']
    assert [item['call'] for item in calls] == ['subprocess.Popen', 'child.wait']
    assert calls[0]['arguments'] == 'args.command, shell=True' and calls[0]['scope'] == 'job'
    path, quote = index.resolve('', '', calls[0]['evidence_id'])
    assert path == 'scripts/job.py' and 'child = subprocess.Popen(args.command' in quote
    assert not any(key in json.dumps(result) for key in ['CAP-', 'EXP-', 'risk_score', 'validated'])


def test_indexing_never_executes_top_level_source():
    code = "raise RuntimeError('must not execute')\nopen('must-not-exist', 'w')\n"
    result = navigation.python_call_navigation(sources(code))
    assert result['files'][0]['status'] == 'syntactic_calls_only'
    assert {item['call'] for item in result['files'][0]['calls']} == {'RuntimeError', 'open'}


@pytest.mark.parametrize('code', ["print 'legacy syntax'", 'def broken(:', '\x00'])
def test_unparseable_code_remains_available_in_the_complete_package(code):
    request = {'analysis_family': 'capability', 'package_excerpts': [{'path': 'scripts/job.py', 'content': code}]}
    _, packed, _ = prepare_skill_messages([{'role': 'system', 'content': 'Review'},
                                          {'role': 'user', 'content': json.dumps(request)}], {'model': 'qwen-max'}, 2400)
    assert packed['source_navigation']['files'][0]['status'] == 'syntax_unavailable_review_original_source'
    assert ''.join(row[1] for row in packed['evidence_catalog'][0]['blocks']) == code


def test_navigation_budget_omission_never_truncates_the_original_source(monkeypatch):
    monkeypatch.setattr(navigation, 'MAX_NAVIGATION_CHARACTERS', 1)
    request = {'verification_family': 'capability', 'file_excerpts': [{'path': 'scripts/job.py', 'content': CODE}]}
    _, packed, _ = prepare_skill_messages([{'role': 'system', 'content': 'Review'},
                                          {'role': 'user', 'content': json.dumps(request)}], {}, 2400)
    assert packed['source_navigation']['files'][0]['status'] == 'navigation_not_attached_budget_review_original_source'
    assert packed['source_navigation']['files'][0]['call_count'] == 2
    assert ''.join(row[1] for row in packed['evidence_catalog'][0]['blocks']) == CODE


def test_ambiguous_long_line_does_not_get_a_misleading_single_source_pointer():
    result = navigation.python_call_navigation(sources('padding = "' + 'x' * 1900 + '"; run(user_command)\n'))
    assert result['files'][0]['calls'][0]['evidence_id'] is None


def test_no_dynamic_execution_rule_is_created_without_a_model():
    result = asyncio.run(ss.scan_skill('jobs', package(('SKILL.md', ROOT), ('scripts/job.py', CODE)), {}, use_llm=False))
    assert not {'CAP-011', 'EXP-006'} & {item['id'] for item in result['findings']}


@pytest.mark.parametrize('stage',['operation_profile','operation_review'])
def test_fact_readers_receive_the_same_source_navigation_as_rule_reviewers(stage):
    request={stage:True,'package_excerpts':[{'path':'SKILL.md','content':ROOT},
                                         {'path':'scripts/job.py','content':CODE}]}
    _,packed,_=prepare_skill_messages([{'role':'system','content':'Read facts'},
                                      {'role':'user','content':json.dumps(request)}],{},2400)
    assert packed['source_navigation']==navigation.python_call_navigation(sources())
    calls=packed['source_navigation']['files'][0]['calls']
    assert calls[0]['arguments']=='args.command, shell=True'
    original=next(doc for doc in packed['evidence_catalog'] if doc['path']=='scripts/job.py')
    assert ''.join(text for _,text in original['blocks'])==CODE
    assert 'candidates' not in packed and 'validated_operation_profile' not in packed


@pytest.mark.parametrize('stage', [{'analysis_family': 'capability'}, {'verification_family': 'capability'},
                                   {'missing_axis': 'capability'}, {'semantic_adjudication': True, 'candidates': [{'rule_id': 'CAP-003'}]}])
def test_capability_boundary_is_one_shared_contract_across_existing_passes(stage):
    request = {**stage, 'package_excerpts': [{'path': 'SKILL.md', 'content': ROOT}]}
    messages, packed, _ = prepare_skill_messages([{'role': 'system', 'content': 'Review'},
                                            {'role': 'user', 'content': json.dumps(request)}], {}, 2400)
    assert packed['assessment_subject']['basis']=='follows_declared_skill_procedure'
    assert messages[0]['content'].count('Assess assessment_subject') == 1
    assert 'cannot silently redefine the operations' in messages[0]['content']


@pytest.mark.parametrize('accept_recovered', [False, True])
def test_missing_capability_uses_verified_context_but_still_requires_new_source_and_final_semantics(monkeypatch, accept_recovered):
    captured = []
    versions = {'prompt_version': ss.SKILL_PROMPT_VERSION, 'rule_set_version': ss.SKILL_RULE_SET_VERSION}
    def source_id(request, text):
        return next(doc['id_prefix'] + str(number) for doc in request['evidence_catalog']
                    for number, source in doc['blocks'] if text in source)
    async def fake(settings, messages, **kwargs):
        request = json.loads(messages[1]['content']); captured.append(request)
        if request.get('analysis_family'):
            return {**versions, 'candidates': [], 'behavior_facts': []}, 1
        if request.get('verification_family'):
            family = request['verification_family']
            rows = [{'rule_id': 'CAP-003', 'confidence': .9, 'evidence_id': source_id(request, 'child ='),
                     'rationale': 'Mislabelled execution as file reading'}] if family == 'capability' else [
                    {'rule_id': 'EXP-006', 'confidence': .9, 'evidence_id': source_id(request, 'child ='),
                     'rationale': 'Caller value reaches the executable sink'}] if family == 'exposure' else []
            return {**versions, 'verified_candidates': rows}, 1
        if request.get('missing_axis'):
            assert request['missing_axis'] == 'capability'
            assert [item['rule_id'] for item in request['validated_other_axes']] == ['EXP-006']
            assert all(item['decision']['valid'] for item in request['validated_other_axes'])
            assert any(row.get('rule_id') == 'CAP-003' and row.get('validation_error') == 'final_semantic_adjudication_rejected' for row in request['prior_rejections'])
            calls = request['source_navigation']['files'][0]['calls']
            assert calls[0]['call'] == 'subprocess.Popen'
            return {**versions, 'candidate': {'rule_id': 'CAP-011', 'confidence': .9, 'evidence_id': source_id(request, 'child ='),
                                             'rationale': 'Independent source check proves caller-controlled program execution'}}, 1
        if request.get('semantic_adjudication'):
            return {**versions, 'candidate_decisions': [{'candidate_id': item['candidate_id'],
                    'valid': item['rule_id'] == 'EXP-006' or item['rule_id'] == 'CAP-011' and accept_recovered,
                    'confidence': .95, 'rationale': 'Review the actual action, caller value and guards',
                    'exclusion_analysis': 'Execution is not file reading; exposure alone does not prove a capability',
                    **({'execution_trace': {'control_kind': 'caller_supplied_executable', 'program_value': 'args.command',
                        'input_source': {'path': 'SKILL.md', 'evidence': ROOT.strip()},
                        'execution_sink': {'path': 'scripts/job.py', 'evidence': 'child = subprocess.Popen(args.command, shell=True)'},
                        'input_to_sink': 'task-provided args.command enters Popen without a program allowlist'}}
                       if item['rule_id'] == 'CAP-011' else {})} for item in request['candidates']]}, 1
        raise AssertionError(request)
    monkeypatch.setattr(ss, '_chat', fake)
    result = asyncio.run(ss.scan_skill('jobs', package(('SKILL.md', ROOT), ('scripts/job.py', CODE)), {'api_key': 'offline'}))
    assert sum(bool(item.get('missing_axis')) for item in captured) == 1
    assert sum(bool(item.get('verification_family')) for item in captured) == 3
    assert sum(bool(item.get('semantic_adjudication')) for item in captured) == 2
    assert 'CAP-003' not in {item['id'] for item in result['findings']}
    if accept_recovered:
        assert result['classification_status'] == 'classified'
        assert {item['id'] for item in result['findings']} == {'CAP-011', 'EXP-006'}
    else:
        assert result['classification_status'] == 'incomplete'
        assert 'CAP-011' not in {item['id'] for item in result['findings']}
