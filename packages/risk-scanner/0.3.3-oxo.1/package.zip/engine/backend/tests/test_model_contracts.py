"""Strict schema repair preserves business meaning across every model stage."""
import asyncio
from copy import deepcopy
import json
import pytest
from backend.infrastructure.ai.contracts import structured_chat, ModelContractError
from backend.application.skill_profile_types import Discovery
from backend.tests.test_skill_operation_profile import operation


def invoke(first,second,schema):
    calls=[]
    async def chat(settings,messages,**kwargs):
        calls.append(messages)
        return deepcopy(first if len(calls)==1 else second),1
    return structured_chat(chat,{},[{'role':'user','content':'fixed input'}],schema=schema,max_tokens=1000),calls


def profile_reply():
    draft=operation()
    draft.pop('confidence')
    return {'prompt_version':'fixed','rule_set_version':'fixed','operations':[draft],
            'coverage':{'SKILL.md':'procedure'},'unknowns':[]}


def test_typed_feedback_can_fix_only_the_declared_invalid_fields():
    first=profile_reply();first['operations'][0]['reach']='single_object'
    fixed=deepcopy(first);fixed['operations'][0]['reach']=['single_object']
    call,calls=invoke(first,fixed,Discovery.model_json_schema())
    result,latency,audit=asyncio.run(call)
    assert result==fixed and latency==2 and len(calls)==2
    assert audit['status']=='format_corrected'
    feedback=json.loads(calls[1][-1]['content'])
    assert {tuple(e['location']) for e in feedback['validation_errors']}=={('operations',0,'reach')}
    assert audit['attempts'][0]['response']==first


@pytest.mark.parametrize('change',['confidence','action','claim_count'])
def test_format_repair_cannot_raise_certainty_or_change_a_valid_claim(change):
    first=profile_reply();first['operations'][0]['reach']='single_object'
    fixed=deepcopy(first);fixed['operations'][0]['reach']=['single_object']
    if change=='confidence':fixed['operations'][0]['confidence']=.99
    if change=='action':fixed['operations'][0]['action']='execute'
    if change=='claim_count':fixed['operations'].append(operation('invented'))
    call,calls=invoke(first,fixed,Discovery.model_json_schema())
    with pytest.raises(ModelContractError) as exc:asyncio.run(call)
    assert len(calls)==2 and len(exc.value.audit['attempts'])==2


FLOW_SCHEMA={'type':'object','properties':{
    'rule_id':{'enum':['FLOW-003']},'confidence':{'type':'number','minimum':0,'maximum':1},
    'participants':{'type':'array','items':{'type':'object','properties':{'role':{'type':'string'},'evidence':{'type':'string'}},
        'required':['role','evidence'],'additionalProperties':False}}},
    'required':['rule_id','confidence','participants'],'additionalProperties':False}


@pytest.mark.parametrize('tamper',[False,True])
def test_encoded_container_repair_preserves_every_role_and_quotation(tamper):
    participants=[{'role':'source','evidence':'actual source'},{'role':'sink','evidence':'actual sink'}]
    first={'rule_id':'FLOW-003','confidence':.85,'participants':json.dumps(participants)}
    fixed={**first,'participants':deepcopy(participants)}
    if tamper:fixed['participants'][0]['evidence']='invented source'
    call,calls=invoke(first,fixed,FLOW_SCHEMA)
    if tamper:
        with pytest.raises(ModelContractError):asyncio.run(call)
    else:
        result,_,_=asyncio.run(call);assert result==fixed
    assert len(calls)==2


@pytest.mark.parametrize('update',[{'confidence':0},{'confidence':'0.85'},{'confidence':1.1},{'rule_id':'FLOW-999'}])
def test_uncertainty_invalid_confidence_and_unknown_rule_are_never_retried(update):
    first={'rule_id':'FLOW-003','confidence':.85,'participants':'[]',**update}
    fixed={'rule_id':'FLOW-003','confidence':.99,'participants':[]}
    call,calls=invoke(first,fixed,FLOW_SCHEMA)
    with pytest.raises(ModelContractError):asyncio.run(call)
    assert len(calls)==1


def test_a_second_bad_response_exhausts_the_fixed_repair_bound():
    first=profile_reply();first['operations'][0]['reach']='single_object'
    call,calls=invoke(first,first,Discovery.model_json_schema())
    with pytest.raises(ModelContractError):asyncio.run(call)
    assert len(calls)==2


def test_a_valid_response_requires_no_repair_request():
    first=profile_reply();call,calls=invoke(first,None,Discovery.model_json_schema())
    result,latency,audit=asyncio.run(call)
    assert result==first and latency==1 and len(calls)==1 and audit['status']=='valid'


@pytest.mark.parametrize('error',['semantic_enum','missing_fact','claim_cardinality'])
def test_semantic_and_container_constraints_are_never_format_repaired(error):
    first=profile_reply();fixed=deepcopy(first);schema=Discovery.model_json_schema()
    if error=='semantic_enum':first['operations'][0]['origin']='internal'
    if error=='missing_fact':del first['operations'][0]['action']
    if error=='claim_cardinality':
        schema['properties']['operations']['uniqueItems']=True
        first['operations'].append(deepcopy(first['operations'][0]))
    call,calls=invoke(first,fixed,schema)
    with pytest.raises(ModelContractError):asyncio.run(call)
    assert len(calls)==1


@pytest.mark.parametrize('encoded,corrected', [('[1]', [True]), ('{"nested":[0]}', {'nested': [False]})])
def test_encoded_container_repair_cannot_change_numbers_into_booleans(encoded, corrected):
    schema = {'type': 'object', 'properties': {'data': {'type': ['array', 'object']}},
              'required': ['data'], 'additionalProperties': False}
    call, calls = invoke({'data': encoded}, {'data': corrected}, schema)
    with pytest.raises(ModelContractError):
        asyncio.run(call)
    assert len(calls) == 2
