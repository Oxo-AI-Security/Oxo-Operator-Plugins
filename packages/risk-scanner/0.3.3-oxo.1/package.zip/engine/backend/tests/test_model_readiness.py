"""A reachable API is not proof that the provider enforces a contract."""
import asyncio
import json
import httpx
import pytest
from fastapi.testclient import TestClient
from backend import qwen, main, skill_scanner as ss
from backend.infrastructure.ai import capabilities as contracts
from backend.store import Store
from backend.tests.test_skill_scanner import package

@pytest.fixture(autouse=True)
def isolated_cache():
    contracts._CAPABILITY_CACHE.clear()
    yield
    contracts._CAPABILITY_CACHE.clear()


def settings(**values):
    return {'provider':'openai_compatible','model':'test-model','base_url':'https://provider.test/v1',
            'api_key':'offline-key',**values}


def test_schema_is_sent_as_a_strict_provider_contract_without_mutating_settings():
    original=settings();schema=contracts.CAPABILITY_SCHEMA
    _,_,body=qwen._request_parts({**original,'_response_schema':schema},[],800)
    assert body['response_format']=={'type':'json_schema','json_schema':{'name':'skill_contract','strict':True,'schema':schema}}
    assert 'max_tokens' not in body and 'max_completion_tokens' not in body
    assert '_response_schema' not in original
    assert qwen._adapt_unsupported_parameters(body,'Unsupported parameter: response_format') is None
    plain={**body,'response_format':{'type':'json_object'}}
    assert 'response_format' not in qwen._adapt_unsupported_parameters(plain,'Unsupported parameter: response_format')


def test_a_http_success_with_ignored_schema_is_not_a_compatible_model():
    calls=[]
    async def chat(s,messages,**kwargs):
        calls.append(s)
        assert s['_response_schema']==contracts.CAPABILITY_SCHEMA
        return {'contract_tag':'wrong-value','items':'not-an-array'},1
    async def run():
        result=await contracts.probe_contract(chat,settings())
        assert result['supported'] is False
        with pytest.raises(qwen.QwenError,match='MODEL_SCHEMA_UNSUPPORTED'):
            await contracts.require_contract(chat,settings())
    asyncio.run(run())
    assert len(calls)==1


def test_capability_cache_is_bound_to_model_endpoint_and_credential():
    calls=[]
    async def chat(s,messages,**kwargs):
        calls.append(1);return {'contract_tag':'skill-contract-v1','items':[1]},1
    async def run():
        assert (await contracts.probe_contract(chat,settings()))['supported']
        assert (await contracts.probe_contract(chat,settings()))['cache_hit']
        await contracts.probe_contract(chat,settings(model='other-model'))
        await contracts.probe_contract(chat,settings(api_key='changed-key'))
        await contracts.probe_contract(chat,settings(base_url='https://other.test/v1'))
    asyncio.run(run())
    assert len(calls)==4


@pytest.mark.parametrize('cause',['HTTP 401: unauthorized','模型网络请求失败','HTTP 429: quota'])
def test_auth_network_and_quota_errors_are_not_relabelled_as_unsupported(cause):
    async def chat(*args,**kwargs):raise qwen.QwenError(cause)
    with pytest.raises(qwen.QwenError,match=cause):asyncio.run(contracts.probe_contract(chat,settings()))
    assert not contracts._CAPABILITY_CACHE


def test_unsupported_model_fails_before_any_sample_analysis(monkeypatch):
    calls=[]
    async def chat(s,messages,**kwargs):
        calls.append(messages);return {'contract_tag':'wrong-value','items':'not-an-array'},1
    monkeypatch.setattr(ss,'_chat',chat)
    result=asyncio.run(ss.scan_skill('sample',package(('SKILL.md','Read a selected file.')),settings()))
    assert len(calls)==1 and not result['findings']
    assert result['llm_analysis']['error'].startswith('MODEL_SCHEMA_UNSUPPORTED')
    with pytest.raises(main.ScoreJobFailure) as exc:main._require_completed_skill_llm(result)
    assert exc.value.code=='MODEL_SCHEMA_UNSUPPORTED'


def test_settings_reports_contract_incompatibility_without_changing_configuration(tmp_path,monkeypatch):
    local=Store(tmp_path/'state.db');original=dict(local.model_settings)
    monkeypatch.setattr(main,'store',local)
    transport=httpx.MockTransport(lambda request:httpx.Response(200,json={'choices':[{'finish_reason':'stop','message':{
        'content':json.dumps({'contract_tag':'wrong-value','items':'not-an-array'} if json.loads(request.content)['response_format']['type']=='json_schema' else {'ok':True})}}]}))
    client=httpx.AsyncClient
    monkeypatch.setattr(qwen.httpx,'AsyncClient',lambda **kwargs:client(transport=transport,**kwargs))
    response=TestClient(main.app).post('/api/settings/model/test',json=settings())
    assert response.status_code==200 and response.json()['ok'] is True
    assert response.json()['skill_contract']['supported'] is False
    assert local.model_settings==original
    assert 'api_key' not in response.json()
