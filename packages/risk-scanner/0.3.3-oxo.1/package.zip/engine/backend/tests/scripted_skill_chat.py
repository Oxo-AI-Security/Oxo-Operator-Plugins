"""Adapt existing fixed model fixtures to independent-review test requests.

Legacy fixtures deliberately repeat their scripted classifications in round two.
Keep that fixture state in the fake model, never in the production request.
New protocol/independence regressions use direct fakes without this adapter.
"""
from copy import deepcopy
import json


class ScriptedSkillChat:
    def __init__(self, reply):
        self.reply = reply
        self.classifications = {}

    def proposals(self, request):
        family = request.get('verification_family')
        prefixes = {'capability': ('CAP-',), 'exposure': ('EXP-',), 'integrity': ('SEM-', 'MAL-')}.get(family, ())
        return [deepcopy(item) for item in self.classifications.get(family, [])
                if str(item.get('rule_id') or '').startswith(prefixes)]

    async def __call__(self, settings, messages, **kwargs):
        request = json.loads(messages[1]['content'])
        # These legacy fixtures isolate source/role checks; the new independent
        # FLOW decision protocol has direct positive/adversarial tests.
        if request.get('flow_adjudication'):
            return {**{k:request[k] for k in ('prompt_version','rule_set_version')},
                'candidate_decisions':[{'candidate_id':c['candidate_id'],'valid':True,'confidence':.99,
                    'rationale':'Fixed legacy fixture path','exclusion_analysis':'Fixture declares the source-to-sink join.'}
                    for c in request['candidates']]},1
        response, latency = await self.reply(settings, messages, **kwargs)
        if request.get('analysis_family'):
            self.classifications[request['analysis_family']] = deepcopy(response.get('candidates', []))
        if request.get('verification_family') and 'verified_candidates' not in response:
            response = {**response, 'verified_candidates': response.get('confirmed_candidates', response.get('candidates', [])) + response.get('added_axis_candidates', [])}
        return response, latency
