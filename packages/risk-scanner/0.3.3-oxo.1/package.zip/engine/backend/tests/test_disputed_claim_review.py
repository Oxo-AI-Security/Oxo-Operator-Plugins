from backend.tests.profile_fixtures import isolate_operation_profile
import asyncio,json
import pytest
from backend import skill_scanner as scanner
from backend.tests.test_skill_scanner import package
from backend.domain.skill.profile_policy import validate_mapping


@pytest.mark.parametrize('resolution',['confirm','exclude','missing'])
def test_a_lower_nonzero_verifier_class_cannot_silently_erase_a_source_backed_higher_claim(monkeypatch,resolution):
    requests=[];v={'prompt_version':scanner.SKILL_PROMPT_VERSION,'rule_set_version':scanner.SKILL_RULE_SET_VERSION}
    def row(rule):return {'rule_id':rule,'confidence':.9,'evidence_id':'E0-0','rationale':'Source-grounded read.'}
    async def reply(settings,messages,**kwargs):
        r=json.loads(messages[1]['content']);requests.append(r)
        if r.get('analysis_family'):
            return {**v,'candidates':[row('CAP-004')] if r['analysis_family']=='capability' else [row('EXP-003')] if r['analysis_family']=='exposure' else []},1
        if r.get('verification_family'):
            return {**v,'verified_candidates':[row('CAP-003')] if r['verification_family']=='capability' else [row('EXP-003')] if r['verification_family']=='exposure' else [],
                'rejected_candidates':[{'rule_id':'CAP-004','rationale':'Only direct PII extraction counts.'}] if r['verification_family']=='capability' else []},1
        if r.get('semantic_adjudication'):
            disputed=[c for c in r['candidates'] if c.get('prior_semantic_reviews')]
            assert disputed and disputed[0]['rule_id']=='CAP-004'
            assert disputed[0]['prior_semantic_reviews'][0]['rationale']=='Only direct PII extraction counts.'
            return {**v,'candidate_decisions':[{'candidate_id':c['candidate_id'],'valid':c['rule_id']!='CAP-004' or resolution!='exclude',
                'confidence':.9,'rationale':'Independent full-source decision.','exclusion_analysis':'Apply the actual communication-data definition.',
                **({'source_reason':'Specific source-based resolution of the prior exclusion.'} if resolution!='missing' else {})} for c in r['candidates']]},1
        raise AssertionError(r)
    monkeypatch.setattr(scanner,'_chat',reply)
    result=asyncio.run(scanner.scan_skill('messages',package(('SKILL.md','Read internal email and company documents.\n')),{'api_key':'offline'}))
    assert ('CAP-004' in {f['id'] for f in result['findings']}) is (resolution=='confirm')
    assert result['classification_status']==('incomplete' if resolution=='missing' else 'classified')


def test_static_integrity_statements_do_not_require_a_runtime_effect_but_runtime_predicates_do():
    inert={'operation_id':'text','actor':'inert','confidence':.9}
    profile={'operations':[inert],'coverage_complete':True}
    assert validate_mapping('SEM-014',[],profile)==(None,1)
    assert validate_mapping('MAL-006',[],profile)==(None,1)
    assert validate_mapping('CAP-011',['text'],profile)[0]=='rule_operation_not_reviewed_or_not_active'
    assert validate_mapping('SEM-006',['text'],profile)[0]=='rule_operation_not_reviewed_or_not_active'
