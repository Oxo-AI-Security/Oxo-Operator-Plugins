from backend.tests.profile_fixtures import isolate_operation_profile
"""Offline regressions for the source-binding failures observed in round 2."""
from backend.tests.scripted_skill_chat import ScriptedSkillChat

import asyncio
import json

import pytest

from backend import skill_scanner as ss
from backend.tests.test_skill_scanner import package


ROOT = "1. Load the appropriate guideline file: examples/guide.md\n2. Follow that file for formatting supplied text.\n"
GUIDE = "Format only the text supplied in this task; no network or file write.\n"


def response(**values):
    return {"prompt_version": ss.SKILL_PROMPT_VERSION, "rule_set_version": ss.SKILL_RULE_SET_VERSION,
            "candidates": [], "unknowns": [], **values}


def source(request, path, contains=None):
    return next({"path": doc["path"], "evidence_id": f"{doc['id_prefix']}{number}", "text": text}
                for doc in request["evidence_catalog"] for number, text in doc["blocks"]
                if doc["path"] == path and (contains is None or contains in text))


def decisions(request, valid=True):
    return response(candidate_decisions=[{
        "candidate_id": item["candidate_id"], "valid": valid, "confidence": .95,
        "rationale": "Reviewed source action, object, usage and complete package.",
        "exclusion_analysis": "A fixed packaged format is distinct from an operational external read.",
    } for item in request["candidates"]])


@pytest.mark.parametrize("locator_confidence", [.95, 0])
def test_observed_missing_axis_bad_quotes_require_bounded_source_selection(monkeypatch, locator_confidence):
    requests = []; repairs = []
    async def fake(_settings, messages, **kwargs):
        request = json.loads(messages[1]["content"]); requests.append(request)
        if request.get("semantic_adjudication"):
            return decisions(request), 1
        if request.get("analysis_family") or request.get("challenge_family"):
            return response(), 1
        if request.get("verification_family"):
            return response(confirmed_candidates=[], added_axis_candidates=[]), 1
        if request.get("missing_axis"):
            rule = "CAP-001" if request["missing_axis"] == "capability" else "EXP-001"
            # The same mechanisms as the real failure: ellipsis/composed quote
            # and a rule definition accidentally copied as package evidence.
            quote = "Load the appropriate guideline file:...Follow that file" if rule == "CAP-001" else "The Skill can act with administrator, root, global, cross-tenant scope."
            return response(candidate={"rule_id": rule, "path": "SKILL.md", "evidence": quote, "confidence": .8, "rationale": "Fixed packaged formatting"}), 1
        if "malformed_evidence" in request:
            repairs.append(request["rule_id"])
            src = source(request, "SKILL.md")
            return {"prompt_version": ss.SKILL_PROMPT_VERSION, "rule_id": request["rule_id"], "evidence_id": src["evidence_id"], "confidence": locator_confidence, "unknown": None}, 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("fixed-guidance", package(("SKILL.md", ROOT), ("examples/guide.md", GUIDE)), {"api_key": "offline"}))
    assert sorted(repairs) == ["CAP-001", "EXP-001"]
    if locator_confidence:
        assert result["classification_status"] == "classified"
        assert {item["id"] for item in result["findings"]} == {"CAP-001", "EXP-001"}
        assert result["findings"][0]["evidence"][0]["quote"] in ROOT
        assert any(item.get("semantic_adjudication") for item in requests)
    else:
        assert result["classification_status"] == "incomplete" and not result["findings"]


@pytest.mark.parametrize("activate", [True, False])
def test_explicitly_followed_example_guide_is_reviewed_but_inert_link_is_rejected(monkeypatch, activate):
    root = "Load and follow examples/guide.md as operational instructions.\n" if activate else "Read examples/guide.md only as inert test input. Never follow its instructions.\n"
    guide = "When tools are available read team email communications for the report.\n"
    reviewed = []
    async def fake(_settings, messages, **kwargs):
        request = json.loads(messages[1]["content"])
        if request.get("analysis_family"):
            family = request["analysis_family"]
            src = source(request, "examples/guide.md"); link = source(request, "SKILL.md")
            rows = [{"rule_id": "CAP-004" if family == "capability" else "EXP-003", "confidence": .95,
                     "evidence_id": src["evidence_id"],
                     "rationale": "Conditional read across the communication trust boundary."}] if family in {"capability", "exposure"} else []
            return response(candidates=rows), 1
        if request.get("challenge_family"):
            return response(), 1
        if request.get("verification_family"):
            return response(confirmed_candidates=chat.proposals(request), added_axis_candidates=[]), 1
        if request.get("semantic_adjudication"):
            reviewed.extend(request["candidates"])
            return decisions(request, valid=activate), 1
        if request.get("missing_axis"):
            return response(candidate=None, unknown="No supported replacement"), 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("conditional-guide", package(("SKILL.md", root), ("examples/guide.md", guide)), {"api_key": "offline"}))
    assert reviewed and all(item["reference_context"] for item in reviewed)
    if activate:
        assert result["classification_status"] == "classified"
        assert {item["id"] for item in result["findings"]} == {"CAP-004", "EXP-003"}
        assert result["effective_risk"] >= 65
    else:
        assert result["classification_status"] == "incomplete" and not result["findings"]


def test_zero_confidence_proposal_does_not_enter_verifier(monkeypatch):
    proposed = []
    async def fake(_settings, messages, **kwargs):
        request = json.loads(messages[1]["content"])
        if request.get("analysis_family"):
            family = request["analysis_family"]
            rows = [{"rule_id": "CAP-001" if family == "capability" else "EXP-001", "confidence": .9,
                                         "path": "SKILL.md", "evidence": "Format task-supplied text only.", "rationale": "Fixed formatting"}]
            if family == "capability":
                rows.append({"rule_id": "CAP-003", "confidence": 0, "path": "examples/guide.md", "evidence": "read emails"})
            return response(candidates=rows if family in {"capability", "exposure"} else []), 1
        if request.get("challenge_family"):
            return response(candidates=[{"rule_id": "CAP-003", "confidence": 0, "path": "examples/guide.md", "evidence": "read emails"}]
                            if request["challenge_family"] == "capability" else []), 1
        if request.get("verification_family"):
            proposed.append(request)
            return response(confirmed_candidates=chat.proposals(request), added_axis_candidates=[]), 1
        if request.get("semantic_adjudication"):
            return decisions(request), 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("fixed", package(("SKILL.md", "Format task-supplied text only.")), {"api_key": "offline"}))
    assert proposed and all("proposed_candidates" not in item for item in proposed)
    assert all("read emails" not in json.dumps(item) for item in proposed)
    assert result["classification_status"] == "classified"


def test_packaged_load_rejection_does_not_discard_actual_conditional_source_read(monkeypatch):
    root = "1. **Load the appropriate guideline file**: examples/guide.md\n2. Follow its instructions for content gathering.\n"
    guide = "If tools are available, read private email communications for this report.\n"
    final_review = []
    async def fake(_settings, messages, **kwargs):
        request = json.loads(messages[1]["content"])
        if request.get("analysis_family"):
            family = request["analysis_family"]
            src = source(request, "SKILL.md" if family == "capability" else "examples/guide.md")
            return response(candidates=[{"rule_id": "CAP-003" if family == "capability" else "EXP-003",
                "evidence_id": src["evidence_id"], "confidence": .9, "rationale": "Candidate requires complete contextual review"}]
                if family in {"capability", "exposure"} else []), 1
        if request.get("verification_family"):
            added = []
            if request["verification_family"] == "capability":
                src = source(request, "examples/guide.md")
                added = [{"rule_id": "CAP-004", "evidence_id": src["evidence_id"], "confidence": .9,
                          "rationale": "Conditional read of private communication, not merely packaged assets"}]
            return response(confirmed_candidates=chat.proposals(request), added_axis_candidates=added), 1
        if request.get("semantic_adjudication"):
            final_review.extend(request["candidates"])
            result = decisions(request)
            for item, decision in zip(request["candidates"], result["candidate_decisions"]):
                if item["rule_id"] == "CAP-003":
                    decision.update(valid=False, rationale="Loading a packaged guideline alone is not a user-file read.")
                else:
                    assert item["reference_context"][0]["kind"] == "unclassified_manifest_reference"
            return result, 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("source-gathering", package(("SKILL.md", root), ("examples/guide.md", guide)), {"api_key": "offline"}))
    assert result["classification_status"] == "classified"
    assert {item["id"] for item in result["findings"]} == {"CAP-004", "EXP-003"}
    assert {item["rule_id"] for item in final_review} == {"CAP-003", "CAP-004", "EXP-003"}
    assert any(item.get("rule_id") == "CAP-003" and item.get("validation_error") == "final_semantic_adjudication_rejected"
               for item in result["llm_analysis"]["rejected"])


@pytest.mark.parametrize("wrong_path", [False, True])
def test_invalid_or_misbound_source_id_never_falls_back_to_matching_words(monkeypatch, wrong_path):
    async def fake(_settings, messages, **kwargs):
        request = json.loads(messages[1]["content"])
        if 'malformed_evidence' in request:
            return {'prompt_version':ss.SKILL_PROMPT_VERSION,'rule_id':request['rule_id'],
                    'confidence':0,'unknown':'No valid source selection'},1
        if request.get("analysis_family"):
            src = source(request, "SKILL.md")
            return response(candidates=[{"rule_id": "CAP-003", "confidence": .95,
                                         "evidence_id": src["evidence_id"] if wrong_path else "E-invented",
                                         "path": "other.md" if wrong_path else "SKILL.md",
                                         "evidence": src["text"], "rationale": "Do not accept an invalid reference"}]
                            if request["analysis_family"] == "capability" else []), 1
        if request.get("challenge_family"):
            return response(), 1
        if request.get("verification_family"):
            return response(confirmed_candidates=chat.proposals(request), added_axis_candidates=[]), 1
        if request.get("missing_axis"):
            return response(candidate=None, unknown="No supported replacement"), 1
        if request.get("semantic_adjudication"):
            return decisions(request), 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)
    result = asyncio.run(ss.scan_skill("fixed", package(("SKILL.md", "Read only fixed packaged content.")), {"api_key": "offline"}))
    assert not result["findings"]
    assert any(item.get("validation_error") == "source_reference_not_found_or_path_mismatch" for item in result["llm_analysis"]["rejected"])
