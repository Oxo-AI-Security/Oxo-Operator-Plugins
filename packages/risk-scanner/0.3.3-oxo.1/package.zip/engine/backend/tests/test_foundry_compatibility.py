"""Offline provider-contract regressions; no real cloud credentials or calls."""

from __future__ import annotations

import asyncio
import json

import httpx
import pytest
from fastapi.testclient import TestClient

from backend import main, qwen
from backend.store import Store


def settings(**changes):
    value = {
        "provider": "azure_openai",
        "model": "DeepSeek-example",
        "azure_deployment": "custom-deployment",
        "azure_endpoint": "https://resource.services.ai.azure.com/openai/v1",
        "api_key": "offline-test-secret",
    }
    return {**value, **changes}


def completion(content='{"ok":true}', finish_reason="stop", **message):
    return {"choices": [{"message": {"content": content, **message}, "finish_reason": finish_reason}]}


def mock_provider(monkeypatch, handler):
    real_client = httpx.AsyncClient
    transport = httpx.MockTransport(handler)
    monkeypatch.setattr(qwen.httpx, "AsyncClient", lambda **kwargs: real_client(transport=transport, **kwargs))


@pytest.mark.parametrize("endpoint", [
    "https://resource.openai.azure.com",
    "https://resource.openai.azure.com/openai/v1/",
    "https://resource.openai.azure.com/openai/v1/chat/completions",
    "https://resource.services.ai.azure.com/openai/v1",
])
def test_foundry_url_auth_and_exact_deployment_at_http_boundary(monkeypatch, endpoint):
    def handle(request):
        assert request.url.path == "/openai/v1/chat/completions"
        assert not request.url.query
        assert request.headers["api-key"] == "offline-test-secret"
        body = json.loads(request.content)
        assert body["model"] == "custom-deployment"
        return httpx.Response(200, json=completion())

    mock_provider(monkeypatch, handle)
    assert asyncio.run(qwen.test_connection(settings(azure_endpoint=endpoint)))["ok"] is True


def test_foundry_connection_probe_has_room_for_reasoning_with_opaque_deployment(monkeypatch):
    def handle(request):
        body = json.loads(request.content)
        budget = body.get("max_tokens", body.get("max_completion_tokens", 0))
        if budget < 1024:
            return httpx.Response(200, json=completion(None, "length", reasoning_content="internal reasoning"))
        return httpx.Response(200, json=completion())

    mock_provider(monkeypatch, handle)
    assert asyncio.run(qwen.test_connection(settings()))["ok"] is True


@pytest.mark.parametrize("content", [
    '<think>Reasoning with a misleading {"ok":false}.</think>\n{"ok":true}',
    '<think>Reasoning.</think>\n```json\n{"ok":true}\n```',
])
def test_deepseek_final_json_is_separated_from_leading_reasoning(content):
    assert qwen._parse_json_content(content) == {"ok": True}


@pytest.mark.parametrize("content", [
    '<think>unfinished {"ok":true}',
    'Some prose {"ok":true}',
    '<think>reasoning</think>{"ok":true} trailing prose',
    '<think>reasoning</think>[{"ok":true}]',
])
def test_reasoning_compatibility_keeps_strict_final_object_validation(content):
    with pytest.raises(qwen.QwenError):
        qwen._parse_json_content(content)


def test_three_explicit_parameter_rejections_then_deepseek_json(monkeypatch):
    bodies = []

    def handle(request):
        body = json.loads(request.content)
        bodies.append(body)
        if "response_format" in body:
            return httpx.Response(422, json={"error": {"message": "Extra inputs are not permitted", "param": "response_format"}})
        if "temperature" in body:
            return httpx.Response(400, json={"error": {"message": "Unknown parameter: temperature"}})
        if "max_tokens" in body:
            return httpx.Response(400, json={"error": {"message": "Unsupported parameter: max_tokens. Use max_completion_tokens instead."}})
        return httpx.Response(200, json=completion('<think>reasoning</think>{"ok":true}'))

    mock_provider(monkeypatch, handle)
    assert asyncio.run(qwen.test_connection(settings()))["ok"] is True
    assert len(bodies) == 4
    assert set(bodies[-1]) == {"model", "messages", "max_completion_tokens"}


@pytest.mark.parametrize("status", [401, 403, 404])
def test_non_parameter_errors_do_not_retry_or_rewrite_request(monkeypatch, status):
    calls = []

    def handle(request):
        calls.append(request)
        return httpx.Response(status, json={"error": {"code": "DeploymentNotFound", "message": "Unsupported parameter response_format; offline-test-secret"}})

    mock_provider(monkeypatch, handle)
    with pytest.raises(qwen.QwenError) as error:
        asyncio.run(qwen.test_connection(settings()))
    assert len(calls) == 1
    assert f"HTTP {status}" in str(error.value)
    assert "offline-test-secret" not in str(error.value)


def test_truncated_json_is_not_accepted_as_a_successful_model_answer(monkeypatch):
    mock_provider(monkeypatch, lambda request: httpx.Response(200, json=completion('{"ok":true}', "length")))
    with pytest.raises(qwen.QwenError, match="截断"):
        asyncio.run(qwen.test_connection(settings()))


def test_invalid_response_envelope_is_an_actionable_provider_error(monkeypatch):
    mock_provider(monkeypatch, lambda request: httpx.Response(200, text="<html>proxy failure</html>"))
    with pytest.raises(qwen.QwenError, match="JSON"):
        asyncio.run(qwen.test_connection(settings()))


def test_unrelated_validation_error_does_not_change_token_parameters(monkeypatch):
    calls = []

    def handle(request):
        calls.append(request)
        return httpx.Response(400, json={"error": {"message": "The sum of max_tokens and max_completion_tokens exceeds the context limit"}})

    mock_provider(monkeypatch, handle)
    with pytest.raises(qwen.QwenError, match="HTTP 400"):
        asyncio.run(qwen.test_connection(settings()))
    assert len(calls) == 1


def test_contradictory_gateway_parameter_errors_are_bounded(monkeypatch):
    calls = []

    def handle(request):
        body = json.loads(request.content)
        calls.append(body)
        rejected, replacement = ("max_tokens", "max_completion_tokens") if "max_tokens" in body else ("max_completion_tokens", "max_tokens")
        return httpx.Response(400, json={"error": {"message": f"Unsupported parameter: {rejected}. Use {replacement} instead."}})

    mock_provider(monkeypatch, handle)
    with pytest.raises(qwen.QwenError, match="HTTP 400"):
        asyncio.run(qwen.test_connection(settings()))
    assert len(calls) <= 4
    assert len({json.dumps(body, sort_keys=True) for body in calls}) == len(calls)


def test_qwen_connection_probe_keeps_existing_contract(monkeypatch):
    def handle(request):
        assert request.url == "https://example.test/v1/chat/completions"
        assert request.headers["Authorization"] == "Bearer compatible-test-key"
        body = json.loads(request.content)
        assert body["model"] == "qwen-plus"
        assert body["max_tokens"] == 20
        assert body["temperature"] == 0
        assert body["response_format"] == {"type": "json_object"}
        return httpx.Response(200, json=completion())

    mock_provider(monkeypatch, handle)
    assert asyncio.run(qwen.test_connection({"provider": "openai_compatible", "model": "qwen-plus", "base_url": "https://example.test/v1", "api_key": "compatible-test-key"}))["ok"] is True


def test_save_reload_and_connection_test_use_same_foundry_settings_without_persisting_probe(tmp_path, monkeypatch):
    isolated_store = Store(tmp_path / "model-state.db")
    monkeypatch.setattr(main, "store", isolated_store)
    candidate = settings(base_url="https://dashscope.aliyuncs.com/compatible-mode/v1")
    client = TestClient(main.app)
    response = client.put("/api/settings/model", json=candidate)
    assert response.status_code == 200
    assert "api_key" not in response.json()
    reloaded = Store(tmp_path / "model-state.db")
    assert reloaded.model_settings == isolated_store.model_settings
    assert reloaded.model_settings["api_key"] == candidate["api_key"]
    original = dict(reloaded.model_settings)
    monkeypatch.setattr(main, "store", reloaded)

    def handle(request):
        assert request.url.path == "/openai/v1/chat/completions"
        assert request.headers["api-key"] == candidate["api_key"]
        assert json.loads(request.content)["model"] == "temporary-probe-deployment"
        return httpx.Response(200, json=completion())

    mock_provider(monkeypatch, handle)
    response = client.post("/api/settings/model/test", json={**candidate, "api_key": None, "azure_deployment": "temporary-probe-deployment"})
    assert response.status_code == 200
    assert response.json()["model"] == "temporary-probe-deployment"
    assert reloaded.model_settings == original
    assert Store(tmp_path / "model-state.db").model_settings == original


def test_connection_api_returns_diagnostic_instead_of_unhandled_500(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "store", Store(tmp_path / "test-state.db"))
    mock_provider(monkeypatch, lambda request: httpx.Response(200, text="not-json"))
    response = TestClient(main.app).post("/api/settings/model/test", json=settings())
    assert response.status_code == 502
    assert "JSON" in response.json()["detail"]
