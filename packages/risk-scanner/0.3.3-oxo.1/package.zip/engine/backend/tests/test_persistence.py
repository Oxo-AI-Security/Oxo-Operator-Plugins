from __future__ import annotations

from backend.store import Store


def test_servers_results_and_model_settings_survive_restart(tmp_path):
    database_path = tmp_path / "state.db"
    first = Store(database_path)
    first.upsert_server(
        {
            "id": "server-one",
            "name": "Persisted MCP",
            "transport": "streamable_http",
            "url": "https://mcp.example.test/mcp",
            "headers": {"Authorization": "Bearer top-secret-token"},
            "status": "connected",
            "tools": [{"name": "send_message", "description": "Send a message"}],
            "tool_count": 1,
            "risk_score": 73,
            "risk_label": "high",
            "matched_rules": [{"id": "CAP-010"}],
            "source_snapshot_hash": "sha256:test",
        }
    )
    first.save_model_settings(
        {
            "model": "qwen-max",
            "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "api_key": "sk-test-persistent-secret",
        }
    )

    database_bytes = database_path.read_bytes()
    assert b"top-secret-token" not in database_bytes
    assert b"sk-test-persistent-secret" not in database_bytes

    restarted = Store(database_path)
    server = restarted.get_server("server-one")
    assert server["risk_score"] == 73
    assert server["matched_rules"] == [{"id": "CAP-010"}]
    assert server["headers"] == {"Authorization": "Bearer top-secret-token"}
    assert restarted.model_settings["model"] == "qwen-max"
    assert restarted.model_settings["api_key"] == "sk-test-persistent-secret"


def test_delete_is_persistent(tmp_path):
    database_path = tmp_path / "state.db"
    store = Store(database_path)
    store.upsert_server({"id": "remove-me", "name": "Temporary", "headers": {}})
    assert store.delete_server("remove-me") is True
    assert Store(database_path).list_servers() == []


def test_azure_model_settings_and_key_survive_restart(tmp_path):
    database_path = tmp_path / "azure-state.db"
    first = Store(database_path)
    first.save_model_settings({
        "provider": "azure_openai",
        "model": "gpt-4o",
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "azure_endpoint": "https://example-resource.openai.azure.com",
        "azure_deployment": "gpt-4o-prod",
        "api_key": "azure-persistent-secret",
    })

    assert b"azure-persistent-secret" not in database_path.read_bytes()
    restarted = Store(database_path)
    assert restarted.model_settings["provider"] == "azure_openai"
    assert restarted.model_settings["azure_deployment"] == "gpt-4o-prod"
    assert restarted.model_settings["api_key"] == "azure-persistent-secret"
