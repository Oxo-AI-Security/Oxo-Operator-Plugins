from backend.tests.profile_fixtures import isolate_operation_profile
"""Offline regressions for acceptance semantics, scores and failure lifecycle.

Model replies are adversarial test doubles, never proof of real LLM accuracy.
"""
from backend.tests.scripted_skill_chat import ScriptedSkillChat

import asyncio
from copy import deepcopy
import json

import pytest

from backend import qwen, skill_scanner as ss
from backend.scoring import score_tool, score_server
from backend.rules import RULE_SET_VERSION, LLM_PROMPT_VERSION, FLOW_PROMPT_VERSION
from backend.application.score_jobs import create_score_job, run_skill_score_job, run_mcp_score_job
from backend.store import Store
from backend.tests.test_scoring import tool, llm
from backend.tests.test_skill_scanner import package


def exp(rule):
    return {"rule_id": rule, "confidence": .95, "rationale": "Declared reach.", "evidence": ["Read workspace records recursively with admin scope."]}


def test_mcp_exposure_is_order_and_duplicate_invariant():
    meta = tool("read", "Read workspace records recursively with admin scope.")
    values = []
    for rows in [[exp("EXP-004"), exp("EXP-006")], [exp("EXP-006"), exp("EXP-004")],
                 [exp("EXP-004"), exp("EXP-004"), exp("EXP-006")]]:
        result = score_tool(meta, llm(meta, "CAP-003", exposure_rules=rows))
        values.append((result["exposure"], result["risk_score"]))
    assert values == [(5, 61)] * 3


@pytest.mark.parametrize("key,value", [("prompt_version", "old"), ("rule_set_version", "old")])
def test_mcp_version_mismatch_cannot_classify(key, value):
    meta = tool("read", "Read a workspace file.")
    extraction = llm(meta, "CAP-003"); extraction[key] = value
    result = score_tool(meta, extraction)
    assert result["classification_status"] == "unclassified"
    assert not result["capabilities"]


def test_mcp_cache_requires_the_entire_metadata_snapshot():
    meta = tool("read", "Read a workspace file. Example only: delete the file.")
    first = score_server({"tools": [meta]}, {"read": llm(meta, "CAP-008", evidence="delete the file")})
    changed = deepcopy(first["tools"][0])
    changed["description"] = "Never delete the file. This is defensive documentation."
    result = score_server({"tools": [changed]})
    assert not result["tools"][0]["capabilities"]


@pytest.mark.parametrize("swap", [False, True])
def test_mcp_flow_roles_bind_to_each_participant_capability(swap):
    source = tool("secret", "Read a secret credential.", annotations={"openWorldHint": False})
    sink = tool("send", "Send content to an external endpoint.")
    flow = {"prompt_version": FLOW_PROMPT_VERSION, "rule_set_version": RULE_SET_VERSION,
            "flow_rule_matches": [{"rule_id": "FLOW-002", "confidence": .95,
                "rationale": "The secret value can be used as outgoing content.", "data_path": "secret -> send",
                "participants": [
                    {"tool_name": "send" if swap else "secret", "role": "secret_source",
                     "evidence": ["Send content" if swap else "Read a secret credential"]},
                    {"tool_name": "secret" if swap else "send", "role": "external_sink",
                     "evidence": ["Read a secret credential" if swap else "Send content"]}]}]}
    result = score_server({"tools": [source, sink]}, {"secret": llm(source, "CAP-005"), "send": llm(sink, "CAP-010")}, flow_extraction=flow)
    assert bool(result["toxic_combinations"]) is not swap


def test_missing_flow_array_is_incomplete_not_an_empty_negative():
    source = tool("secret", "Read a secret credential.")
    sink = tool("send", "Send content to an external endpoint.")
    result = score_server({"tools": [source, sink]},
                          {"secret": llm(source, "CAP-005"), "send": llm(sink, "CAP-010")},
                          flow_extraction={"prompt_version": FLOW_PROMPT_VERSION, "rule_set_version": RULE_SET_VERSION})
    assert result["flow_classification_status"] == "partial"
    assert not result["toxic_combinations"]


def skill_reply(**values):
    return {"prompt_version": ss.SKILL_PROMPT_VERSION, "rule_set_version": ss.SKILL_RULE_SET_VERSION,
            "candidates": [], "unknowns": [], **values}


def candidate(rule, quote, confidence=.95):
    return {"rule_id": rule, "path": "SKILL.md", "evidence": quote, "confidence": confidence,
            "rationale": "Operational behavior must be evaluated in its full context."}


def install_fake(monkeypatch, *, cap_quote="Read the user-selected file.", extra=None,
                 verifier_low=False, repair_confidence=.95, reject_final=False,
                 reject_install=False, incomplete_final=False, captured=None):
    async def fake(_settings, messages, *, max_tokens=800):
        request = json.loads(messages[1]["content"])
        if captured is not None:
            captured.append(request)
        if request.get("semantic_adjudication"):
            decisions = [{"candidate_id": item["candidate_id"], "valid": not (reject_final and item["rule_id"] in {"CAP-011", "CAP-020"}),
                          "confidence": .95, "rationale": "Checked active actor, action, object and complete context.",
                          "exclusion_analysis": "Quoted examples are data; operational steps remain capabilities."}
                         for item in request["candidates"]]
            for item, decision in zip(request['candidates'], decisions):
                if item['rule_id'] == 'CAP-011':
                    decision['execution_trace'] = {'control_kind': 'caller_supplied_executable', 'program_value': 'explicit user commands',
                        'input_source': {'path': 'SKILL.md', 'evidence': 'execute arbitrary commands'},
                        'execution_sink': {'path': 'SKILL.md', 'evidence': 'execute arbitrary commands'},
                        'input_to_sink': 'The active procedure explicitly accepts and executes user-requested arbitrary commands.'}
            return skill_reply(candidate_decisions=decisions[:-1] if incomplete_final else decisions), 1
        if request.get("analysis_family"):
            family = request["analysis_family"]
            rows = [candidate("CAP-003", cap_quote)] if family == "capability" else [candidate("EXP-002", "one file")] if family == "exposure" else []
            if family == "capability" and extra:
                rows.append(extra)
            return skill_reply(candidates=rows), 1
        if request.get("challenge_family"):
            return skill_reply(candidates=[]), 1
        if request.get("verification_family"):
            rows = deepcopy(chat.proposals(request))
            if reject_install:
                rows = [row for row in rows if row["rule_id"] != "CAP-020"]
            if verifier_low:
                for row in rows:
                    if row["rule_id"] == "CAP-011":
                        row["confidence"] = .1
            return skill_reply(confirmed_candidates=rows, added_axis_candidates=[], incomplete_axes=[]), 1
        if "malformed_evidence" in request:
            return {"prompt_version": ss.SKILL_PROMPT_VERSION, "rule_id": request["rule_id"], "path": "SKILL.md", "evidence": "execute arbitrary commands",
                    "confidence": repair_confidence, "unknown": None}, 1
        if request.get("missing_axis"):
            return skill_reply(candidate=None, unknown="Insufficient evidence"), 1
        raise AssertionError(request)
    chat = ScriptedSkillChat(fake)
    monkeypatch.setattr(ss, "_chat", chat)


def scan(text):
    return asyncio.run(ss.scan_skill("offline", package(("SKILL.md", text)), {"api_key": "offline-fixture"}))


def test_skill_verifier_low_confidence_is_not_replaced(monkeypatch):
    install_fake(monkeypatch, extra=candidate("CAP-011", "execute arbitrary commands"), verifier_low=True)
    result = scan("Read the user-selected file. Only one file. Never execute arbitrary commands.")
    assert "CAP-011" not in {item["id"] for item in result["findings"]}


@pytest.mark.parametrize("quote", ["Do not execute installation.", "Quoted example: pip install malware"])
def test_skill_cap020_reject_is_not_resurrected_by_regex(monkeypatch, quote):
    install_fake(monkeypatch, extra=candidate("CAP-020", quote), reject_install=True)
    result = scan("Read the user-selected file. Only one file. " + quote)
    assert "CAP-020" not in {item["id"] for item in result["findings"]}


def test_skill_repair_low_confidence_is_rejected(monkeypatch):
    install_fake(monkeypatch, extra=candidate("CAP-011", "invented supporting quotation"), repair_confidence=0)
    result = scan("Read the user-selected file. Only one file. Never execute arbitrary commands.")
    assert "CAP-011" not in {item["id"] for item in result["findings"]}
    audit = result["llm_analysis"]["candidate_verification"]["evidence_repairs"]
    assert audit[0]["accepted"] is False


@pytest.mark.parametrize("context", ["Never execute arbitrary commands.", "Defensively detect 'execute arbitrary commands' in quoted data.",
                                      "Example only: execute arbitrary commands; do not run this example."])
def test_skill_final_semantics_can_reject_negation_quotes_and_examples(monkeypatch, context):
    captured = []
    install_fake(monkeypatch, extra=candidate("CAP-011", "malformed quotation"), reject_final=True, captured=captured)
    result = scan("Read the user-selected file. Only one file. " + context)
    assert "CAP-011" not in {item["id"] for item in result["findings"]}
    final = next(item for item in captured if item.get("semantic_adjudication"))
    repaired = next(item for item in final["candidates"] if item["rule_id"] == "CAP-011")
    assert repaired["evidence"][0]["quote"] == "execute arbitrary commands"
    assert context in final["package_excerpts"][0]["content"]


def test_skill_valid_operational_risk_survives_final_semantics(monkeypatch):
    install_fake(monkeypatch, extra=candidate("CAP-011", "execute arbitrary commands"))
    result = scan("Read the user-selected file. Only one file. On explicit user request execute arbitrary commands.")
    assert "CAP-011" in {item["id"] for item in result["findings"]}
    assert result["effective_risk"] >= 90


def test_skill_full_context_is_preserved_for_every_semantic_pass(monkeypatch):
    captured = []
    install_fake(monkeypatch, captured=captured)
    text = "Read the user-selected file. Only one file.\n" + ("context\n" * 5000) + "NEVER_EXECUTE_THIS_QUOTED_ATTACK"
    result = scan(text)
    assert result["classification_status"] == "classified"
    for request in captured:
        excerpts = request.get("file_excerpts") or request.get("package_excerpts")
        if excerpts:
            assert any(item["content"] == text for item in excerpts)
        elif request.get("evidence_catalog"):
            assert any("".join(block[1] for block in doc["blocks"]) == text for doc in request["evidence_catalog"])
        else:
            raise AssertionError("Semantic pass lost full source context")


def test_skill_oversized_context_fails_before_model_calls(monkeypatch):
    async def forbidden(*args, **kwargs):
        raise AssertionError("No model call is allowed before complete-context validation")
    monkeypatch.setattr(ss, "_chat", forbidden)
    result = scan("X" * 410000)
    assert result["classification_status"] == "incomplete"
    assert "SKILL_CONTEXT_TOO_LARGE" in result["llm_analysis"]["error"]
    assert not result["findings"]


def test_skill_incomplete_final_decisions_fail_instead_of_scoring(monkeypatch):
    install_fake(monkeypatch, incomplete_final=True)
    result = scan("Read the user-selected file. Only one file.")
    assert result["classification_status"] == "incomplete"
    assert not result["findings"]
    assert result["llm_analysis"]["status"] == "error"


@pytest.mark.parametrize("confidence", [float("nan"), float("inf"), True, 1.5])
def test_invalid_confidence_is_not_a_supported_match(confidence):
    meta = tool("read", "Read a workspace file.")
    result = score_tool(meta, llm(meta, "CAP-003", confidence=confidence))
    assert not result["capabilities"]


def test_qwen_wrong_family_version_is_not_stamped_current(monkeypatch):
    async def fake(*args, **kwargs):
        return {"prompt_version": "old", "rule_set_version": RULE_SET_VERSION}, 1
    monkeypatch.setattr(qwen, "_chat", fake)
    with pytest.raises(qwen.QwenError, match="版本"):
        asyncio.run(qwen.extract_tool(tool("read", "Read a workspace file."), {}))


@pytest.mark.parametrize("missing_family", ["capability", "exposure", "metadata"])
def test_missing_family_payload_does_not_become_an_empty_success(monkeypatch, missing_family):
    async def fake(_settings, messages, **kwargs):
        request = json.loads(messages[1]["content"])
        result = {"prompt_version": LLM_PROMPT_VERSION, "rule_set_version": RULE_SET_VERSION}
        if request["family"] != missing_family:
            result.update(capability_rule_matches=[], exposure_rule_matches=[], security_rule_matches=[],
                          has_security_issue=False, untrusted_content={"detected": False})
        return result, 1
    monkeypatch.setattr(qwen, "_chat", fake)
    with pytest.raises(qwen.QwenError, match="缺少"):
        asyncio.run(qwen.extract_tool(tool("read", "Read a workspace file."), {}))


def test_stage_group_cancels_and_awaits_siblings():
    from backend.infrastructure.ai.concurrency import gather_stages
    async def exercise():
        started = asyncio.Event(); stopped = asyncio.Event()
        async def blocked():
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                stopped.set()
        async def failed():
            await started.wait()
            raise qwen.QwenError("invalid response")
        with pytest.raises(qwen.QwenError):
            await gather_stages(blocked(), failed())
        assert stopped.is_set()
    asyncio.run(exercise())


def test_shared_model_concurrency_is_bounded_and_recovers_after_failure(monkeypatch):
    async def exercise():
        active = peak = 0
        async def request(_settings, messages, *, max_tokens):
            nonlocal active, peak
            active += 1; peak = max(peak, active)
            try:
                await asyncio.sleep(.001)
                if messages == ["fail"]:
                    raise qwen.QwenError("expected fixture failure")
                return {}, 1
            finally:
                active -= 1
        monkeypatch.setattr(qwen, "_chat_request", request)
        await asyncio.gather(*(qwen._chat({}, ["fail"] if i == 0 else [], max_tokens=10) for i in range(10)), return_exceptions=True)
        assert peak == 3 and active == 0
        assert await qwen._chat({}, [], max_tokens=10) == ({}, 1)
    asyncio.run(exercise())


@pytest.mark.parametrize("kind", ["mcp", "skill"])
def test_cancelled_job_is_visible_and_not_redispatched(tmp_path, kind):
    store = Store(tmp_path / "state.db")
    job = create_score_job(store, kind, client_reference=None, input_summary={})
    async def exercise():
        entered = asyncio.Event(); calls = 0
        async def pending(*args, **kwargs):
            nonlocal calls
            calls += 1; entered.set()
            await asyncio.Event().wait()
        async def run():
            if kind == "skill":
                await run_skill_score_job(store, job["request_id"], [{"name": "fixture", "files": [], "root": "", "anchor": "SKILL.md"}], True, scan_package=pending)
            else:
                await run_mcp_score_job(store, job["request_id"], {}, True, score_snapshot=pending, serialize_result=lambda value: value)
        task = asyncio.create_task(run()); await entered.wait()
        await run()  # Duplicate dispatch must return without issuing another call.
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
        assert calls == 1
    asyncio.run(exercise())
    saved = store.get_score_job(job["request_id"])
    assert saved["status"] == "failed" and saved["result"] is None
    assert saved["error"]["code"] == "SCORING_CANCELLED"


@pytest.mark.parametrize("recover", [False, True])
def test_json_recovery_is_bounded_and_keeps_original_contract(monkeypatch, recover):
    calls = []
    async def request(settings, messages, *, max_tokens):
        calls.append(messages)
        if len(calls) == 1 or not recover:
            raise qwen.QwenError("模型未返回合法 JSON")
        return {"prompt_version": "kept"}, 1
    monkeypatch.setattr(qwen, "_chat_request", request)
    messages = [{"role": "system", "content": "exact contract"}, {"role": "user", "content": "untrusted input"}]
    if recover:
        result, _ = asyncio.run(qwen._chat({}, messages, max_tokens=20))
        assert result["prompt_version"] == "kept"
    else:
        with pytest.raises(qwen.QwenError):
            asyncio.run(qwen._chat({}, messages, max_tokens=20))
    assert len(calls) == 2
    assert calls[1][:2] == messages


def test_mcp_failed_fresh_review_is_error_then_can_recover(tmp_path, monkeypatch):
    from backend import main
    from fastapi import HTTPException
    store = Store(tmp_path / "live-fixture.db")
    meta = tool("reader", "Read one workspace file.")
    prior = score_server({"id": "fixture", "status": "connected", "tools": [meta]}, {"reader": llm(meta, "CAP-003")})
    store.upsert_server(prior)
    store.save_model_settings({"api_key": "fixture-only", "model": "fixture"})
    monkeypatch.setattr(main, "store", store)
    async def unavailable(*args, **kwargs):
        raise qwen.QwenError("fixture timeout")
    monkeypatch.setattr(main, "extract_tool", unavailable)
    with pytest.raises(HTTPException) as error:
        asyncio.run(main.evaluate_server("fixture", main.EvaluateRequest(use_llm=True)))
    assert error.value.status_code == 502
    failed = store.get_server("fixture")
    assert failed["evaluation_status"] == "error"
    assert "fixture timeout" in failed["evaluation_error"]
    assert failed["risk_score"] == prior["risk_score"]  # Prior evidence is retained as old, with an error state.
    async def restored(item, _settings):
        return llm(item, "CAP-003")
    monkeypatch.setattr(main, "extract_tool", restored)
    result = asyncio.run(main.evaluate_server("fixture", main.EvaluateRequest(use_llm=True)))
    assert result["evaluation_status"] == "completed"
    assert not result.get("evaluation_error")


def test_stage_timeout_cancels_request_releases_slot_and_recovers(monkeypatch):
    async def exercise():
        stopped = asyncio.Event()
        async def pending(*args, **kwargs):
            try:
                await asyncio.Event().wait()
            finally:
                stopped.set()
        monkeypatch.setattr(qwen, "_chat_request", pending)
        monkeypatch.setattr(qwen, "MODEL_STAGE_DEADLINE_SECONDS", .01)
        with pytest.raises(qwen.QwenError, match="MODEL_STAGE_TIMEOUT"):
            await qwen._chat({}, [])
        assert stopped.is_set()
        async def ready(*args, **kwargs):
            return {}, 1
        monkeypatch.setattr(qwen, "_chat_request", ready)
        assert await qwen._chat({}, []) == ({}, 1)
    asyncio.run(exercise())


def test_queue_timeout_makes_no_duplicate_request(monkeypatch):
    async def exercise():
        entered = 0; ready = asyncio.Event(); release = asyncio.Event()
        async def pending(*args, **kwargs):
            nonlocal entered
            entered += 1
            if entered == 3:
                ready.set()
            await release.wait()
            return {}, 1
        monkeypatch.setattr(qwen, "_chat_request", pending)
        monkeypatch.setattr(qwen, "MODEL_QUEUE_WAIT_SECONDS", .01)
        tasks = [asyncio.create_task(qwen._chat({}, [])) for _ in range(3)]
        await ready.wait()
        with pytest.raises(qwen.QwenError, match="MODEL_QUEUE_TIMEOUT"):
            await qwen._chat({}, [])
        assert entered == 3
        release.set(); await asyncio.gather(*tasks)
        assert await qwen._chat({}, []) == ({}, 1)
    asyncio.run(exercise())


def test_transient_provider_error_retries_with_original_body_then_recovers(monkeypatch):
    import httpx
    calls = []
    async def handler(request):
        calls.append(json.loads(request.content))
        if len(calls) == 1:
            return httpx.Response(429, json={"error": {"message": "temporary capacity"}})
        return httpx.Response(200, json={"choices": [{"message": {"content": '{"ok": true}'}, "finish_reason": "stop"}]})
    real_client = httpx.AsyncClient
    monkeypatch.setattr(qwen.httpx, "AsyncClient", lambda **kwargs: real_client(transport=httpx.MockTransport(handler), **kwargs))
    async def no_wait(*args):
        pass
    monkeypatch.setattr(qwen.asyncio, "sleep", no_wait)
    result, _ = asyncio.run(qwen._chat({"api_key": "offline", "model": "fixture", "base_url": "https://fixture.invalid/v1"}, []))
    assert result == {"ok": True}
    assert len(calls) == 2 and calls[0] == calls[1]
