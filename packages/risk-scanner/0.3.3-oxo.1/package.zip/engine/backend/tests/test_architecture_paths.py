from pathlib import Path

from backend.infrastructure.persistence.database import DEFAULT_DATA_DIR, PROJECT_ROOT


def test_default_data_directory_stays_at_repository_root_after_refactors():
    expected_root = Path(__file__).resolve().parents[2]

    assert PROJECT_ROOT == expected_root
    assert DEFAULT_DATA_DIR == expected_root / "data"
