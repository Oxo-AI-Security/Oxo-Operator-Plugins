import asyncio,json
import pytest
from backend.application.skill_flow_review import review_flow_paths

VERSIONS={'prompt_version':'flow-fixed','rule_set_version':'rules-fixed'}
CATALOG=[{'rule_id':'FLOW-003','definition':'Untrusted value reaches execution.','roles':['source','sink']}]
FINDING={'id':'FLOW-003','llm_confidence':.85,'data_path':'content -> run(content)'}
PROPOSAL={'flow_rule_matches':[{'rule_id':'FLOW-003','data_path':FINDING['data_path']}],'rejected_candidates':[]}


@pytest.mark.parametrize('valid',[False,True])
def test_second_source_review_can_exclude_coexistence_and_cap_actual_path_certainty(valid):
    async def reply(settings,messages,**kwargs):
        request=json.loads(messages[1]['content'])
        assert request['flow_adjudication'] and len(request['package_excerpts'])==1
        return {**VERSIONS,'candidate_decisions':[{'candidate_id':'0','valid':valid,'confidence':.75,
            'rationale':'Review actual value flow.','exclusion_analysis':'Access alone does not prove the join.'}]},1
    accepted,audit=asyncio.run(review_flow_paths(reply,{},[{'path':'SKILL.md','text':'content = read(); run(content)'}],
        CATALOG,[FINDING],PROPOSAL,[],VERSIONS,ValueError))
    assert audit['status']=='completed'
    assert len(accepted)==int(valid)
    if valid:assert accepted[0]['llm_confidence']==.75
    else:assert audit['rejected'][0]['validation_error']=='final_flow_adjudication_rejected'


@pytest.mark.parametrize('mode',['uncertain','missing_identity','promote_exclusion'])
def test_unknown_missing_decisions_and_new_unproven_paths_cannot_complete(mode):
    async def reply(*args,**kwargs):
        return {**VERSIONS,'candidate_decisions':[] if mode=='missing_identity' else [{
            'candidate_id':'0','valid':True,'confidence':.2 if mode=='uncertain' else .9,
            'rationale':'Actual decision','exclusion_analysis':'Actual exclusion'}]},1
    findings=[] if mode=='promote_exclusion' else [FINDING]
    proposal={'flow_rule_matches':[],'rejected_candidates':[{'rule_id':'FLOW-003','rationale':'No join.'}]} if mode=='promote_exclusion' else PROPOSAL
    with pytest.raises(ValueError):asyncio.run(review_flow_paths(reply,{},[{'path':'SKILL.md','text':'Original data'}],
        CATALOG,findings,proposal,[],VERSIONS,ValueError))
