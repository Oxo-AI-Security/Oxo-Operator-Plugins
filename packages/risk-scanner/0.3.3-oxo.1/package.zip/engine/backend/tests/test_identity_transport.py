"""Array transport preserves exact identity coverage and full acceptance gates."""
from copy import deepcopy
import pytest
from backend.application.identity_wire import identity_wire_schema, restore_identity_maps
from backend.application.skill_response_contract import response_schema, decode_decisions
from backend.infrastructure.ai.schema_validation import validation_errors


def catalog_request():
    return {'verification_family':'exposure','rule_catalog':[{'rule_id':'EXP-004'},{'rule_id':'EXP-005'}],
        'validated_operation_profile':{'operations':[{'operation_id':'read'}]}}


def test_complete_catalog_transport_roundtrip_does_not_add_votes_or_drop_unknowns():
    schema=response_schema(catalog_request())
    wire,layout=identity_wire_schema(schema)
    raw={'rule_decisions':[{'rule_id':identity,'verdict':'unknown','confidence':.4,
        'evidence_id':None,'operation_ids':[],'rationale':'No target proof.','exclusion_analysis':'Cannot exclude or confirm.'}
        for identity in ['EXP-004','EXP-005']]}
    original=deepcopy(raw)
    assert not validation_errors(wire,raw)
    restored=restore_identity_maps(raw,layout)
    assert not validation_errors(schema,restored)
    result=decode_decisions(restored,catalog_request())
    assert not result['verified_candidates'] and len(result['incomplete_axes'])==2
    assert raw==original


@pytest.mark.parametrize('defect',['missing','duplicate','unknown'])
def test_missing_and_duplicate_identities_still_fail_without_default_decisions(defect):
    schema=response_schema(catalog_request())
    _,layout=identity_wire_schema(schema)
    rows=[{'rule_id':'EXP-004'}, {'rule_id':'EXP-005'}]
    if defect=='missing':rows.pop()
    elif defect=='duplicate':rows[1]['rule_id']='EXP-004'
    else:rows[1]['rule_id']='EXP-999'
    with pytest.raises(ValueError):restore_identity_maps({'rule_decisions':rows},layout)


@pytest.mark.parametrize('defect',['source','operation'])
def test_homogeneous_null_fields_cannot_admit_a_match_without_proof(defect):
    request=catalog_request()
    row={'verdict':'matched','confidence':.9,'evidence_id':'E0-1','operation_ids':['read'],
         'rationale':'Proposed','exclusion_analysis':'Source checked'}
    row['evidence_id' if defect=='source' else 'operation_ids']=None if defect=='source' else []
    with pytest.raises(ValueError):decode_decisions({'rule_decisions':{'EXP-004':row}},request)
