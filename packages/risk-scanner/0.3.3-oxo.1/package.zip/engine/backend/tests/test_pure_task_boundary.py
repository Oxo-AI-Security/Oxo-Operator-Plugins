"""Task interaction is explicit; unknown effects and persistent IO stay excluded."""
import pytest
from backend.domain.skill.profile_policy import profile_rule_error
from backend.tests.test_skill_operation_profile import operation


def profile(*effects):
    return {'coverage_complete':True,'operations':list(effects)}


def test_task_conversation_and_selected_packaged_data_are_pure_without_becoming_fixed_scope():
    question={**operation('question'),'action':'interact','origin':'task','reach':['single_object']}
    asset={**operation('asset'),'action':'read','origin':'packaged','control':'caller_data','reach':['single_object']}
    transform={**operation('transform'),'action':'transform','origin':'task','reach':['single_object']}
    assert profile_rule_error('CAP-001',profile(question,asset,transform)) is None
    assert profile_rule_error('EXP-001',profile(question,asset,transform))=='fixed_baseline_conflicts_with_reviewed_operations'


@pytest.mark.parametrize('action,origin',[('other','task'),('read','workspace'),('modify','workspace'),
    ('send','service_content'),('install','public_content'),('execute','task'),('interface','task')])
def test_interaction_category_cannot_rescue_other_effects(action,origin):
    question={**operation('question'),'action':'interact','origin':'task'}
    effect={**operation('effect'),'action':action,'origin':origin}
    assert profile_rule_error('CAP-001',profile(question,effect))=='zero_baseline_conflicts_with_reviewed_operations'


def invoked_effect(action='transform',control='fixed_data',kind='tool_or_api'):
    return {**operation('effect'),'action':action,'origin':'task',
            'invocation':{'kind':kind,'control':control}}


def test_fixed_api_identity_does_not_exclude_pure_content_but_its_write_does():
    assert profile_rule_error('CAP-001',profile(invoked_effect())) is None
    for action in ('create','modify','delete','read','send','install','interface','other'):
        assert profile_rule_error('CAP-001',profile(invoked_effect(action)))=='zero_baseline_conflicts_with_reviewed_operations'


@pytest.mark.parametrize('control,kind',[('caller_executable','tool_or_api'),
    ('unknown','tool_or_api'),('agent_selected_program','tool_or_api'),('fixed_data','program')])
def test_invocation_uncertainty_or_execution_cannot_become_pure(control,kind):
    assert profile_rule_error('CAP-001',profile(invoked_effect(control=control,kind=kind)))=='zero_baseline_conflicts_with_reviewed_operations'


def test_inert_sensitive_words_cannot_establish_an_active_capability():
    from backend.domain.skill.profile_policy import validate_mapping
    inert={**operation('quote'),'actor':'inert','action':'install',
           'resource':'Quoted negative example: sudo install token delete'}
    assert validate_mapping('CAP-020',['quote'],profile(inert))[0]=='rule_operation_not_reviewed_or_not_active'
