from backend.tests.profile_fixtures import isolate_operation_profile
"""Frozen-failure regressions; synthetic replies are not live model acceptance."""
import asyncio
import json
import pytest
from backend import skill_scanner as ss
from backend.application.skill_prompt import prepare_skill_messages
from backend.tests.test_skill_scanner import package

TEXT = 'Read the user-selected log file.\n\nProcess that selected log only.\n'

@pytest.mark.parametrize('accept,confidence', [(True, .7), (False, .7), (True, .4)])
def test_explicit_blank_pointer_gets_bounded_correction_but_never_bypasses_semantics(monkeypatch, accept, confidence):
    calls=[]; locator=[]
    versions={'prompt_version':ss.SKILL_PROMPT_VERSION,'rule_set_version':ss.SKILL_RULE_SET_VERSION}
    async def fake(settings, messages, **kwargs):
        r=json.loads(messages[1]['content']); calls.append(r)
        if r.get('analysis_family') or r.get('verification_family'):
            family=r.get('analysis_family') or r['verification_family']
            rows=[] if family=='integrity' else [{'rule_id':'CAP-003' if family=='capability' else 'EXP-002',
                'confidence':.95 if family=='capability' else confidence,
                'evidence_id':'E0-0' if family=='capability' else 'E0-1',
                'rationale':'One selected file, no other targets.'}]
            return {**versions,'candidates':rows,'verified_candidates':rows,'behavior_facts':[]},1
        if 'malformed_evidence' in r:
            locator.append(r)
            assert r['invalid_evidence_id']=='E0-1'
            assert r['source_validation_error']=='evidence_id_points_to_blank_source'
            return {'prompt_version':ss.SKILL_PROMPT_VERSION,'rule_id':'EXP-002','confidence':.95,
                    'evidence_id':'E0-1' if len(locator)==1 else 'E0-2','unknown':None},1
        if r.get('semantic_adjudication'):
            return {**versions,'candidate_decisions':[{'candidate_id':item['candidate_id'],
                'valid':accept if item['rule_id']=='EXP-002' else True,'confidence':.9,
                'rationale':'Independent complete-source judgment.','exclusion_analysis':'No broader scope.'}
                for item in r['candidates']]},1
        if r.get('missing_axis'):
            return {**versions,'candidate':None,'unknown':'No supported alternative'},1
        raise AssertionError(r)
    monkeypatch.setattr(ss,'_chat',fake)
    result=asyncio.run(ss.scan_skill('log',package(('SKILL.md',TEXT)),{'api_key':'offline'}))
    findings={x['id']:x for x in result['findings']}
    assert len(locator)==(2 if confidence>=.6 else 0)
    if accept and confidence>=.6:
        assert result['classification_status']=='classified'
        assert findings['EXP-002']['llm_confidence']==confidence
        assert findings['EXP-002']['evidence'][0]['quote']=='Process that selected log only.\n'
        assert findings['EXP-002']['semantic_adjudication']['valid']
    else:
        assert result['classification_status']=='incomplete' and 'EXP-002' not in findings
    if locator:
        assert len(locator[-1]['validation_errors'])>0

@pytest.mark.parametrize('stage',[{'analysis_family':'capability'},{'verification_family':'capability'},
                                 {'semantic_adjudication':True},{'missing_axis':'exposure'},
                                 {'candidate_rule_ids':['FLOW-003']}])
def test_same_runtime_actor_contract_reaches_every_semantic_stage(stage):
    request={**stage,'prompt_version':'fixed','rule_set_version':'fixed',
             'package_excerpts':[{'path':'SKILL.md','content':'Load and follow the guide.'}]}
    messages,packed,_=prepare_skill_messages([{'role':'system','content':'Review'},
        {'role':'user','content':json.dumps(request)}],{},2200)
    assert packed['assessment_subject']['basis']=='follows_declared_skill_procedure'
    assert packed['assessment_subject']['runtime_environment']=='not_assessed'
    assert messages[0]['content'].count('Assess assessment_subject')==1
    assert 'immutable actor/action/origin/control/reach facts' in messages[0]['content']
    assert 'response_schema' in packed
    assert 'default' not in json.dumps(packed['response_schema'])
    if 'candidate_rule_ids' in stage:
        participants=packed['response_schema']['properties']['flow_rule_matches']['items']['properties']['participants']
        assert participants['type']=='array' and participants['items']['type']=='object'

@pytest.mark.parametrize('confidence,participants',[(0,[]),(.95,'[]')])
def test_flow_low_confidence_and_stringified_participants_never_create_a_floor(monkeypatch,confidence,participants):
    async def fake(settings,messages,**kwargs):
        return {'prompt_version':ss.SKILL_FLOW_PROMPT_VERSION,'rule_set_version':ss.SKILL_RULE_SET_VERSION,
            'flow_rule_matches':[{'rule_id':'FLOW-003','confidence':confidence,'rationale':'proposed only',
             'data_path':'source -> execution','participants':participants}],'rejected_candidates':[],'unknowns':[]},1
    monkeypatch.setattr(ss,'_chat',fake)
    _,files,_=ss._snapshot(package(('SKILL.md',TEXT)))
    matches,audit=asyncio.run(ss._llm_flow_findings(files,['FLOW-003'],[],[],{'api_key':'offline'}))
    assert not matches and audit['status']=='incomplete'
