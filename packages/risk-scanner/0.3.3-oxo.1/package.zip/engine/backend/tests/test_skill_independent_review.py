from backend.tests.profile_fixtures import isolate_operation_profile
"""Direct protocol regressions; no legacy fake-model adapter or real requests."""
import asyncio
import json

import pytest

from backend import skill_scanner as ss
from backend.application.skill_evidence import SourceIndex
from backend.tests.test_skill_scanner import package


_OMITTED = object()

ROOT = 'Use scripts/runner.py to execute task-provided jobs.\n'
CODE = "jobs = args.jobs\nfor job in jobs:\n    subprocess.Popen(job, shell=True)\nwait_for_ready(port)\n"


def reply(**values):
    return {'prompt_version': ss.SKILL_PROMPT_VERSION, 'rule_set_version': ss.SKILL_RULE_SET_VERSION,
            'candidates': [], 'unknowns': [], 'rejected_candidates': [], **values}


def block(request, path, contains):
    return next(f"{doc['id_prefix']}{number}" for doc in request['evidence_catalog']
                if doc['path'] == path for number, text in doc['blocks'] if contains in text)


def run(monkeypatch, *, invalid_trace=_OMITTED, fixed=False, reject=False, missing_schema=False):
    captured = []
    code = "subprocess.run(['python', 'packaged.py', '--port', str(port)])\n" if fixed else CODE
    async def fake(settings, messages, **kwargs):
        request = json.loads(messages[1]['content']); captured.append(request)
        if request.get('analysis_family'):
            # Deliberately misleading draft. Its rationale and source pointers
            # must not be copied into the independent verifier's request.
            family = request['analysis_family']
            return reply(candidates=[{'rule_id': 'CAP-006' if family == 'capability' else 'EXP-005',
                'confidence': .8, 'evidence_id': block(request, 'examples/log.py', 'open('),
                'rationale': 'DRAFT_ANCHOR_MUST_NOT_LEAK'}] if family in {'capability', 'exposure'} else []), 1
        if request.get('verification_family'):
            assert request['review_mode'] == 'independent_source_review'
            assert 'proposed_candidates' not in request
            assert 'DRAFT_ANCHOR_MUST_NOT_LEAK' not in json.dumps(request)
            family = request['verification_family']
            assert 'CAP-011' in request['permitted_rule_ids'] if family == 'capability' else True
            if missing_schema:
                return reply(), 1
            primary = block(request, 'scripts/runner.py', 'subprocess.')
            rows = [{'rule_id': rule, 'confidence': .95, 'evidence_id': primary,
                     'rationale': 'Follow the caller value to the actual operation; readiness is not an executable guard.'}
                    for rule in (['CAP-011'] if family == 'capability' else ['EXP-006', 'EXP-004'] if family == 'exposure' else [])]
            if invalid_trace is not _OMITTED:
                for row in rows:
                    row['supporting_evidence_ids'] = invalid_trace
            return reply(verified_candidates=rows), 1
        if request.get('semantic_adjudication'):
            for item in request['candidates']:
                assert item['evidence'][0]['path'] == 'scripts/runner.py'
                assert 'supporting_evidence' not in item
                assert any(excerpt['content'] == code for excerpt in request['package_excerpts'])
                assert len(item['evidence']) == 1  # context cannot widen FLOW prerequisites
            return reply(candidate_decisions=[{'candidate_id': item['candidate_id'], 'valid': not (fixed or reject),
                'confidence': .95, 'rationale': 'Inspect the input-to-operation chain and strongest exclusion.',
                'exclusion_analysis': 'A fixed packaged executable is excluded; readiness alone is not an allowlist.',
                **({'execution_trace': {'control_kind': 'caller_supplied_executable', 'program_value': 'job',
                    'input_source': {'path': 'scripts/runner.py', 'evidence': 'jobs = args.jobs'},
                    'execution_sink': {'path': 'scripts/runner.py', 'evidence': 'subprocess.Popen(job, shell=True)'},
                    'input_to_sink': 'args.jobs -> jobs -> job in loop -> Popen, readiness checks follow execution'}}
                   if item['rule_id'] == 'CAP-011' and not fixed else {})}
                for item in request['candidates']]), 1
        if request.get('missing_axis'):
            return reply(candidate=None, unknown='No supported replacement'), 1
        raise AssertionError(request)
    monkeypatch.setattr(ss, '_chat', fake)
    result = asyncio.run(ss.scan_skill('generic-runner', package(('SKILL.md', ROOT), ('scripts/runner.py', code),
                    ('examples/log.py', "with open('example.log', 'w') as stream:\n    stream.write('example')\n")),
                    {'api_key': 'offline', 'model': 'qwen-max'}))
    return result, captured


def test_independent_review_recovers_actual_operation_without_reusing_draft(monkeypatch):
    result, requests = run(monkeypatch)
    assert result['classification_status'] == 'classified'
    assert {item['id'] for item in result['findings']} == {'CAP-011', 'EXP-006', 'EXP-004'}
    assert result['effective_risk'] > 0
    assert len(requests) == 7  # existing three families + three reviews + final, no new pass
    final = next(item for item in requests if item.get('semantic_adjudication'))
    assert any('jobs = args.jobs' in item['content'] for item in final['package_excerpts'])
    references = result['llm_analysis']['source_references']
    assert any('subprocess.Popen(job' in item['text'] for item in references)
    assert not ss._skill_role_supported('FLOW-006', 'arbitrary_execution', 'SKILL.md', result['findings'], [])


@pytest.mark.parametrize('options', [{'fixed': True}, {'reject': True}])
def test_fixed_command_or_final_rejection_is_not_overridden_to_complete_axes(monkeypatch, options):
    result, requests = run(monkeypatch, **options)
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert any(item.get('missing_axis') for item in requests)
    assert any(row.get('validation_error') == 'final_semantic_adjudication_rejected' for row in result['llm_analysis']['rejected'])


@pytest.mark.parametrize('trace', [['E999-1'], [None], [{}], 'E0-1', ['E0-1'] * 13])
def test_retired_trace_cannot_change_primary_or_add_a_model_stage(monkeypatch, trace):
    result, requests = run(monkeypatch, invalid_trace=trace)
    assert result['classification_status'] == 'classified'
    assert len(requests) == 7
    assert any(stage.get('unsupported_evidence_fields') for stage in result['llm_analysis']['stages'])
    assert all('supporting_evidence' not in item for item in result['findings'])


def test_missing_independent_schema_is_incomplete_not_a_fallback_to_draft(monkeypatch):
    result, requests = run(monkeypatch, missing_schema=True)
    assert result['classification_status'] == 'incomplete' and not result['findings']
    assert '独立源码复核' in result['llm_analysis']['error']
    assert not any(item.get('semantic_adjudication') for item in requests)


def test_presentation_priority_preserves_ids_and_every_source_character():
    files = [{'path': 'LICENSE', 'text': 'Legal text\n'}, {'path': 'examples/demo.py', 'text': 'demo\n'},
             {'path': 'scripts/runner.py', 'text': CODE}, {'path': 'SKILL.md', 'text': ROOT}]
    index = SourceIndex(files)
    assert [item['path'] for item in index.documents] == ['SKILL.md', 'scripts/runner.py', 'examples/demo.py', 'LICENSE']
    assert index.resolve('', '', 'E0-0') == ('LICENSE', 'Legal text\n')
    assert index.resolve('', '', 'E3-0') == ('scripts/runner.py', 'jobs = args.jobs\n')
    assert {doc['path']: ''.join(text for _, text in doc['blocks']) for doc in index.documents} == {item['path']: item['text'] for item in files}


def test_source_keywords_never_create_an_execution_rule_without_a_model():
    result = asyncio.run(ss.scan_skill('runner', package(('SKILL.md', ROOT), ('scripts/runner.py', CODE)), {}, use_llm=False))
    assert not {'CAP-011', 'EXP-006'} & {item['id'] for item in result['findings']}
