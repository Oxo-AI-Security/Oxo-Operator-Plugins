from fastapi.testclient import TestClient

from backend.main import app


client = TestClient(app)


def test_swagger_is_exposed_on_the_backend_port_root():
    response = client.get("/docs")
    assert response.status_code == 200
    assert "Swagger UI" in response.text
    assert "/openapi.json" in response.text


def test_openapi_catalog_exposes_mcp_and_skill_operations():
    response = client.get("/openapi.json")
    assert response.status_code == 200
    schema = response.json()
    assert schema["info"]["title"] == "Risk score API"
    assert "/api/servers/{server_id}/evaluate" in schema["paths"]
    assert "/api/skills" in schema["paths"]
    assert "/api/skills/import-archive" in schema["paths"]
    assert "/api/skills/{skill_id}/scan" not in schema["paths"]
    assert "/api/skills/{skill_id}/scan-managed" not in schema["paths"]
    assert "/api/skills/{skill_id}/open-folder" not in schema["paths"]
    assert "post" not in schema["paths"]["/api/skills"]
    assert "/api/skills/rules" in schema["paths"]
    assert "/api/v1/score/mcp/requests" in schema["paths"]
    assert "/api/v1/score/mcp/requests/{request_id}" in schema["paths"]
    assert "/api/v1/score/skill/requests" in schema["paths"]
    assert "/api/v1/score/skill/requests/{request_id}" in schema["paths"]
