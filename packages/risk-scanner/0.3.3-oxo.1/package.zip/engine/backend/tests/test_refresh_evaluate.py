from __future__ import annotations

import asyncio

import pytest
from fastapi import HTTPException

from backend import main
from backend.mcp_client import McpConnectionError
from backend.store import Store


def configured_server() -> dict:
    return {
        "id": "refresh-me",
        "name": "Refresh MCP",
        "description": "Refresh behavior test.",
        "transport": "streamable_http",
        "url": "http://127.0.0.1:9999/mcp",
        "headers": {},
        "status": "connected",
        "tools": [{"name": "calculate", "description": "Calculate a deterministic result.", "inputSchema": {"type": "object", "properties": {}}}],
        "tool_count": 1,
    }


def test_refresh_evaluate_fetches_latest_tool_list_before_scoring(tmp_path, monkeypatch):
    test_store = Store(tmp_path / "refresh.db")
    test_store.upsert_server(configured_server())
    test_store.save_model_settings({"model": "qwen-plus", "base_url": "https://example.test/v1", "api_key": "sk-test"})
    monkeypatch.setattr(main, "store", test_store)
    calls = []

    async def fake_fetch(server: dict):
        calls.append(server["id"])
        return {
            "tools": [{
                "name": "run_shell",
                "description": "Execute an arbitrary shell command supplied by the caller.",
                "inputSchema": {"type": "object", "properties": {"command": {"type": "string"}}},
                "annotations": {"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False, "openWorldHint": False},
            }],
            "server_info": {"name": "Refresh MCP", "version": "1.0"},
            "instructions": "",
        }

    monkeypatch.setattr(main, "fetch_server_tools", fake_fetch)
    async def fake_extract(item: dict, _settings: dict):
        return {
            "prompt_version": main.LLM_PROMPT_VERSION,
            "rule_set_version": main.RULE_SET_VERSION,
            "capability_rule_matches": [{
                "rule_id": "CAP-011", "confidence": 0.99,
                "rationale": "Arbitrary shell execution",
                "evidence": [{"field": "description", "text": item["description"]}],
            }],
            "rejected_candidates": [], "has_security_issue": False,
            "security_issue_types": [], "security_rule_matches": [],
            "untrusted_content": {"detected": False, "confidence": 0, "evidence": []},
            "data_classes": ["internal"], "unknowns": [],
        }

    monkeypatch.setattr(main, "extract_tool", fake_extract)
    result = asyncio.run(main.evaluate_server("refresh-me", main.EvaluateRequest(use_llm=True, refresh_tools=True)))

    assert calls == ["refresh-me"]
    assert result["tools"][0]["name"] == "run_shell"
    assert result["capability_risk_score"] >= 90
    assert test_store.get_server("refresh-me")["tools"][0]["name"] == "run_shell"


def test_refresh_failure_does_not_score_the_stale_tool_list(tmp_path, monkeypatch):
    test_store = Store(tmp_path / "refresh-failure.db")
    test_store.upsert_server(configured_server())
    monkeypatch.setattr(main, "store", test_store)

    async def failed_fetch(_server: dict):
        raise McpConnectionError("fresh tools/list unavailable")

    monkeypatch.setattr(main, "fetch_server_tools", failed_fetch)
    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(main.evaluate_server("refresh-me", main.EvaluateRequest(use_llm=False, refresh_tools=True)))

    assert exc_info.value.status_code == 502
    stored = test_store.get_server("refresh-me")
    assert stored["status"] == "error"
    assert stored.get("risk_score") is None
    assert stored["tools"][0]["name"] == "calculate"
