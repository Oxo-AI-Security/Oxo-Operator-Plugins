"""Replay actual provider failure shape; never call the real provider."""
import asyncio
import httpx
import pytest
from backend.infrastructure.ai import qwen
from backend.application import skill_scanner as scanner
from backend.main import _require_completed_skill_llm
from backend.application.score_jobs import ScoreJobFailure
from backend.tests.test_skill_scanner import package


def test_provider_account_rejection_preserves_code_and_is_not_format_or_transport_retried(monkeypatch):
    calls=[];client=httpx.AsyncClient
    async def rejected(request):
        calls.append(request)
        return httpx.Response(400,json={'error':{'code':'Arrearage','type':'Arrearage','message':'Account is not in good standing.'}})
    transport=httpx.MockTransport(rejected)
    monkeypatch.setattr(qwen.httpx,'AsyncClient',lambda **kwargs:client(transport=transport,**kwargs))
    with pytest.raises(qwen.ModelServiceError) as error:
        asyncio.run(qwen._chat_request({'provider':'openai_compatible','base_url':'https://example.test/v1',
            'model':'fixed','api_key':'offline-key'},[{'role':'user','content':'Return JSON.'}]))
    assert len(calls)==1
    assert error.value.provider_error=={'http_status':400,'code':'Arrearage'}


def test_upstream_rejection_is_not_labeled_as_a_semantic_classification_failure(monkeypatch):
    async def rejected(*args,**kwargs):
        raise qwen.ModelServiceError('HTTP 400: account unavailable',http_status=400,provider_code='Arrearage')
    monkeypatch.setattr(scanner,'_chat',rejected)
    result=asyncio.run(scanner.scan_skill('data',package(('SKILL.md','Format the supplied text.')),{'api_key':'offline-key'}))
    assert result['llm_analysis']['provider_error']=={'http_status':400,'code':'Arrearage'}
    with pytest.raises(ScoreJobFailure) as error:_require_completed_skill_llm(result)
    assert error.value.code=='MODEL_PROVIDER_REJECTED'
