"""Complete source -> reviewed operations -> rule mapping protocol tests."""
import asyncio
from copy import deepcopy
import json
import pytest
from backend import skill_scanner as ss
from backend.application.skill_prompt import OPERATION_PROFILE
from backend.domain.skill.profile_policy import profile_rule_error
from backend.tests.test_skill_scanner import package

ROOT='Read and update the selected issue using service.py.\n'
CODE='issue = client.get_issue(issue_id)\nclient.update_issue(issue_id, body)\n'


def operation(identifier='read'):
    return {'operation_id':identifier,'invocation':None,'actor':'runtime_agent','action':'read','resource':'private issue',
            'origin':'service_content','control':'caller_data','content_use':'data','reach':['single_object','free_target'],
            'condition':'When the selected issue workflow is requested','entry_evidence_id':'E0-0',
            'action_evidence_id':'E1-0','input_evidence_id':'E1-0','value_path':'issue_id -> get_issue -> issue content','confidence':.9}


def run(monkeypatch, *, forced_rules=None, bad_source=False, missing_coverage=False, missing_review=False,
        unlinked_actor=None, accept_unlinked=False, review_confidence=.85):
    from backend.infrastructure.ai.capabilities import _CAPABILITY_CACHE
    _CAPABILITY_CACHE.clear()
    requests=[]
    async def fake(settings,messages,**kwargs):
        if settings.get('_response_schema',{}).get('properties',{}).get('contract_tag'):
            return {'contract_tag':'skill-contract-v1','items':[1]},1
        r=json.loads(messages[1]['content']);requests.append(r)
        v={'prompt_version':ss.SKILL_PROMPT_VERSION,'rule_set_version':ss.SKILL_RULE_SET_VERSION}
        if r.get('operation_profile'):
            read=operation();write={**operation('write'),'action':'modify','action_evidence_id':'E1-1',
                                  'value_path':'issue_id/body -> update_issue -> shared issue state'}
            if bad_source:read['action_evidence_id']='E99-999'
            effects=[read,write]
            if unlinked_actor:
                effects.append({**operation('unlinked'),'actor':unlinked_actor,
                    'entry_evidence_id':'E2-0','action_evidence_id':'E2-0','input_evidence_id':'E2-0'})
            from backend.tests.test_profile_wire import flatten
            rows=[flatten({key:value for key,value in effect.items() if key!='confidence'}) for effect in effects]
            paths=['SKILL.md','service.py'] + (['unlinked.md'] if unlinked_actor else [])
            return {**v,'operations':rows,'coverage':{p:'procedure' if p=='SKILL.md' else 'implementation'
                    for p in (['SKILL.md'] if missing_coverage else paths)},'unknowns':[]},1
        if r.get('operation_review'):
            assert 'source_evidence' not in r['operations'][0]  # full source transmitted once
            return {**v,'decisions':{o['operation_id']:{
                    'valid':o['operation_id']!='unlinked' or accept_unlinked,'confidence':review_confidence,
                    'source_reason':'The active root procedure invokes this exact private-service read/update.'}
                   for o in r['operations'] if not missing_review or o['operation_id']=='read'},
                    'additional_operations':[],'coverage_complete':True,'unknowns':[]},1
        if r.get('analysis_family') or r.get('verification_family'):
            profile=r['validated_operation_profile']
            if profile['operations']:
                assert profile['operations'][0]['origin']=='service_content'
                assert profile['operations'][0]['confidence']==review_confidence
                assert 'source_evidence' not in profile['operations'][0]
            family=r.get('analysis_family') or r.get('verification_family')
            rules=(forced_rules or {}).get(family,['CAP-007'] if family=='capability' else ['EXP-003'] if family=='exposure' else [])
            if not profile['operations']:
                rules=[]
            rows=[{'rule_id':rule,'confidence':.9,'evidence_id':'E1-1' if rule.startswith('CAP') else 'E1-0',
                   'rationale':'Map the reviewed operation to the supplied rule.',
                   'operation_ids':['read','write'] if rule in {'CAP-001','EXP-001'} else ['write'] if rule=='CAP-007' else ['read']} for rule in rules]
            if r.get('analysis_family'):
                return {**v,'candidates':rows,'behavior_facts':[],'rejected_candidates':[],'unknowns':[]},1
            if family in {'capability','exposure'}:
                by_rule = {row['rule_id']:row for row in rows}
                return {**v,'rule_decisions':{rule['rule_id']:
                    ({k:value for k,value in by_rule[rule['rule_id']].items() if k!='rule_id'} |
                        {'verdict':'matched','exclusion_analysis':'Source establishes this declared effect.'})
                    if rule['rule_id'] in by_rule else {'verdict':'excluded','confidence':.9,
                        'rationale':'Absent from the complete reviewed operations.','exclusion_analysis':'No supporting operation.',
                        'evidence_id':None,'operation_ids':[]}
                    for rule in r['rule_catalog']}},1
            return {**v,'verified_candidates':rows,'rejected_candidates':[],'incomplete_axes':[]},1
        if r.get('semantic_adjudication'):
            return {**v,'candidate_decisions':{c['candidate_id']:{'valid':True,'confidence':.9,
                'rationale':'Rule mapping approved','exclusion_analysis':'Specific exclusion reviewed',
                'source_reason':'Source resolves the claim and any earlier exclusion.'} for c in r['candidates']}},1
        if r.get('missing_axis'):
            return {**v,'candidate':None,'unknown':'No supported replacement'},1
        raise AssertionError(r)
    async def native(settings,messages,**kwargs):
        from backend.application.identity_wire import IDENTITIES
        response,latency=await fake(settings,messages,**kwargs)
        for field,identity in IDENTITIES.items():
            if isinstance(response.get(field),dict):
                response[field]=[{identity:key,**value} for key,value in response[field].items()]
        return response,latency
    monkeypatch.setattr(ss,'_chat',native)
    source_files=[('SKILL.md',ROOT),('service.py',CODE)]
    if unlinked_actor: source_files.append(('unlinked.md','Quoted test scenario without a manifest entry.\n'))
    result=asyncio.run(ss.scan_skill('service-example',package(*source_files),{'api_key':'offline'}))
    return result,requests


@pytest.mark.parametrize('actor',['runtime_agent','inert'])
def test_unlinked_candidate_can_be_rejected_by_independent_review_before_activation_check(monkeypatch,actor):
    result,requests=run(monkeypatch,unlinked_actor=actor)
    assert any(request.get('operation_review') for request in requests)
    assert result['classification_status']=='classified'
    assert 'unlinked' not in {operation['operation_id'] for operation in result['llm_analysis']['operation_profile']['operations']}


def test_even_review_approval_cannot_activate_unlinked_runtime_source(monkeypatch):
    result,_=run(monkeypatch,unlinked_actor='runtime_agent',accept_unlinked=True)
    assert result['classification_status']=='incomplete'
    assert 'manifest-referenced' in result['llm_analysis']['error']


def test_reviewed_operations_are_shared_without_leaking_classification_drafts(monkeypatch):
    result,requests=run(monkeypatch)
    assert result['classification_status']=='classified'
    assert {f['id'] for f in result['findings']}=={'CAP-007','EXP-003'}
    assert all(f['llm_confidence']==.85 for f in result['findings'])
    assert len(requests)==9
    assert [s['stage'] for s in result['llm_analysis']['stages'][:2]]==['operation_profile','operation_review']
    assert OPERATION_PROFILE.get() is None


def test_fact_discovery_has_no_admission_confidence_and_uncertain_review_still_blocks(monkeypatch):
    result,requests=run(monkeypatch,review_confidence=.55)
    draft=next(r for r in requests if r.get('operation_profile'))
    assert 'confidence' not in draft['response_schema']['$defs']['OperationFacts']['anyOf'][0]['properties']
    assert result['classification_status']=='incomplete'
    assert not result['llm_analysis']['operation_profile']['coverage_complete']


@pytest.mark.parametrize('options',[{'bad_source':True},{'missing_coverage':True},{'missing_review':True}])
def test_invalid_or_incomplete_operational_record_cannot_reach_rule_scoring(monkeypatch,options):
    result,requests=run(monkeypatch,**options)
    assert result['classification_status']=='incomplete' and not result['findings']
    assert result['llm_analysis']['status']=='error'
    assert not any(r.get('analysis_family') for r in requests)
    assert OPERATION_PROFILE.get() is None


def test_even_unanimous_zero_rule_votes_cannot_erase_reviewed_read_write(monkeypatch):
    result,_=run(monkeypatch,forced_rules={'capability':['CAP-001'],'exposure':['EXP-001']})
    assert result['classification_status']=='incomplete'
    assert not {'CAP-001','EXP-001'} & {f['id'] for f in result['findings']}
    assert any('reviewed_operations' in r.get('validation_error','') for r in result['llm_analysis']['rejected'])


@pytest.mark.parametrize('extra',['SEM-006','CAP-011'])
def test_rule_stage_cannot_invent_instruction_promotion_or_executable_control(monkeypatch,extra):
    rules={'capability':['CAP-007',extra] if extra.startswith('CAP') else ['CAP-007'],
           'exposure':['EXP-003'],'integrity':[extra] if extra.startswith('SEM') else []}
    result,_=run(monkeypatch,forced_rules=rules)
    assert result['classification_status']=='classified'
    assert extra not in {f['id'] for f in result['findings']}
    assert any(r.get('rule_id')==extra and r.get('validation_error')=='rule_prerequisite_not_in_reviewed_operations'
               for r in result['llm_analysis']['rejected'])


def test_generic_declarative_control_policy_distinguishes_program_from_task_initiation():
    o={**operation(),'action':'execute','origin':'task','control':'agent_selected_program'}
    profile={'operations':[o],'coverage_complete':True}
    assert profile_rule_error('CAP-011',profile)
    assert profile_rule_error('EXP-006',profile)
    profile['operations'][0]['control']='caller_executable'
    assert profile_rule_error('CAP-011',profile) is None
    assert profile_rule_error('EXP-006',profile) is None


def test_pure_profile_can_still_support_legitimate_zero_and_no_invented_execution():
    o={**operation(),'action':'transform','origin':'task','control':'fixed_data','reach':['fixed']}
    profile={'operations':[o],'coverage_complete':True}
    assert profile_rule_error('CAP-001',profile) is None
    assert profile_rule_error('EXP-001',profile) is None
    assert profile_rule_error('CAP-011',profile)
    assert profile_rule_error('SEM-006',profile)


def test_a_claim_cannot_borrow_executable_control_from_an_unrelated_operation():
    from backend.domain.skill.profile_policy import validate_mapping
    read=operation('read')
    execute={**operation('execute'),'action':'execute','control':'caller_executable'}
    profile={'operations':[read,execute],'coverage_complete':True}
    assert validate_mapping('CAP-011',['read'],profile)[0]=='rule_prerequisite_not_in_reviewed_operations'
    assert validate_mapping('CAP-011',['execute'],profile)==(None,.9)
    assert validate_mapping('CAP-011',['invented'],profile)[0]=='rule_operation_not_reviewed_or_not_active'
