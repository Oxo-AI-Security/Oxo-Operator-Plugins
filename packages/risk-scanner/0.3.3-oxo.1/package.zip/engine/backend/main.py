"""FastAPI service for multi-MCP discovery and deterministic risk evaluation."""

from __future__ import annotations

import asyncio

import re
import uuid
import hashlib
from contextlib import asynccontextmanager
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Literal

from fastapi import BackgroundTasks, File, Form, HTTPException, Response, UploadFile
from .api.app import create_api_app
from .infrastructure.mcp.client import McpConnectionError, fetch_server_tools
from .application.mcp_scoring import score_mcp_tools_snapshot
from .application.model_settings import compose_model_settings
from .infrastructure.ai.provider_config import public_provider_options
from .application.score_jobs import (
    ScoreJobFailure,
    accepted_job,
    create_score_job,
    run_mcp_score_job,
    run_skill_score_job,
)
from .api.schemas import (
    EvaluateRequest,
    ModelSettingsInput,
    ServerCreate,
)
from .api.external_payloads import (
    ExternalMcpScoreRequest,
    PayloadFormatError,
    ScoreJobAccepted,
    ScoreJobStatus,
    parse_mcp_tools_payload,
    parse_skill_archive,
)
from .infrastructure.ai.qwen import QwenError, extract_server_flows, extract_tool, public_settings, test_connection
from .domain.mcp.rules import LLM_PROMPT_VERSION, RULE_SET_VERSION, public_rules
from .domain.mcp.scoring import score_server
from .infrastructure.skills.repository import (
    delete_managed_skill_files,
    load_managed_skill_files,
    save_managed_skill_files,
)
from .application.skill_scanner import (
    SKILL_FLOW_PROMPT_VERSION,
    SKILL_PROMPT_VERSION,
    SKILL_RULE_SET_VERSION,
    SKILL_SCORING_VERSION,
    migrate_persisted_skill_scan,
    public_skill_rules,
    scan_skill,
    skill_snapshot_hash,
)
from .infrastructure.persistence.store import store


def _slug(name: str) -> str:
    stem = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "mcp-server"
    return f"{stem}-{uuid.uuid4().hex[:6]}"


def _public_server(server: dict[str, Any]) -> dict[str, Any]:
    safe = dict(server)
    if safe.get("headers"):
        safe["headers"] = {key: "••••••••" for key in safe["headers"]}
    return safe


def _external_inventory_id(identity: str | None, request_id: str) -> str:
    """Create a stable, URL-safe inventory ID without trusting caller text as a path."""
    if not identity:
        return request_id
    stem = re.sub(r"[^a-z0-9]+", "-", identity.lower()).strip("-") or "snapshot"
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:10]
    return f"external-{stem[:54]}-{digest}"


def _require_server(server_id: str) -> dict[str, Any]:
    server = store.get_server(server_id)
    if not server:
        raise HTTPException(status_code=404, detail="MCP Server 不存在")
    return server


async def _refresh_server_tools(server: dict[str, Any]) -> dict[str, Any]:
    """Reconnect and persist a fresh MCP tools/list snapshot before scoring."""
    try:
        discovery = await fetch_server_tools(server)
    except McpConnectionError as exc:
        server["status"] = "error"
        server["evaluation_status"] = "error"
        server["evaluation_error"] = str(exc)
        server["connection_error"] = str(exc)
        store.upsert_server(server)
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    server["tools"] = discovery["tools"]
    server["tool_count"] = len(discovery["tools"])
    server["status"] = "connected"
    server["evaluation_status"] = "pending"
    server.pop("connection_error", None)
    server.pop("evaluation_error", None)
    server["server_info"] = discovery.get("server_info", {})
    if not server.get("description") and discovery.get("instructions"):
        server["description"] = discovery["instructions"]
    store.upsert_server(server)
    return server


async def migrate_rule_results() -> None:
    """Recompute persisted metadata snapshots when the deterministic rules change."""
    for server in store.list_servers():
        if not server.get("tools") or server.get("rule_set_version") == RULE_SET_VERSION:
            continue
        previous_version = server.get("rule_set_version") or "unknown"
        if previous_version == "3.3.0":
            id_map = {
                "META-006": "META-005",
                "META-007": "META-006",
                "META-008": "META-007",
                "FLOW-007": "FLOW-005",
            }

            def remap(value: Any) -> Any:
                if isinstance(value, dict):
                    return {key: remap(item) for key, item in value.items()}
                if isinstance(value, list):
                    return [remap(item) for item in value]
                return id_map.get(value, value) if isinstance(value, str) else value

            server = remap(server)
        evaluated = score_server(
            server,
            previous_score=server.get("risk_score"),
            flow_extraction=server.get("flow_llm_raw_response"),
        )
        evaluated["change_status"] = "changed"
        evaluated["approval_required"] = evaluated.get("risk_score", 0) >= 40
        evaluated["change_reason"] = f"规则版本从 {previous_version} 更新为 {RULE_SET_VERSION}，已确定性重算"
        store.upsert_server(evaluated)
    for skill in store.list_skills():
        legacy_history = skill.pop("history", [])
        latest = skill.get("latest_scan") or (legacy_history[-1] if legacy_history else None)
        changed = False
        for field in ("monitor_enabled", "monitor_interval_seconds", "client_watch_mode", "last_check_at", "last_check_status"):
            if field in skill:
                skill.pop(field, None)
                changed = True
        if legacy_history:
            changed = True
        unfinished = {"error", "failed", "incomplete", "pending", "queued", "running", "analyzing"}
        if (latest and latest.get("rule_set_version")
                and latest.get("rule_set_version") != SKILL_RULE_SET_VERSION
                and latest.get("classification_status") not in unfinished
                and latest.get("analysis_status") not in unfinished):
            latest = migrate_persisted_skill_scan(latest)
            skill["last_check_at"] = datetime.now(timezone.utc).isoformat()
            skill["last_check_status"] = "policy_recalculated"
            changed = True
        if latest:
            latest.pop("version", None)
            latest.pop("changed", None)
            latest.pop("change_summary", None)
            latest.pop("next_check_at", None)
            skill["latest_scan"] = latest
        if latest and not skill.get("fingerprint_hash"):
            skill["fingerprint_hash"] = latest.get("snapshot_hash")
            skill["fingerprint_algorithm"] = latest.get("fingerprint_algorithm", "sha256-canonical-package-v1")
            skill["fingerprint_created_at"] = latest.get("scanned_at")
            changed = True
        if changed:
            store.upsert_skill(skill)
    for job in store.score_jobs:
        result = job.get("result") if job.get("kind") == "mcp" and job.get("status") == "succeeded" else None
        if not isinstance(result, dict) or result.get("transport") != "snapshot":
            continue
        if store.get_server(str(result.get("id") or "")):
            continue
        restored = {
            **result,
            "source": "external_api",
            "inventory_mode": "external_snapshot",
            "refresh_supported": False,
            "client_reference": job.get("client_reference"),
            "last_score_request_id": job.get("request_id"),
        }
        store.upsert_server(restored)


@asynccontextmanager
async def lifespan(_app):
    """Run deterministic data migrations before accepting requests."""
    await migrate_rule_results()
    yield


app = create_api_app(lifespan=lifespan)


@app.get("/api/health", tags=["System"], summary="Check service health and rule versions")
async def health() -> dict[str, Any]:
    return {"ok": True, "rule_set_version": RULE_SET_VERSION, "server_count": len(store.servers), "skill_count": len(store.skills)}


@app.get("/api/servers", tags=["MCP Servers"], summary="List registered MCP Servers")
async def list_servers() -> list[dict[str, Any]]:
    return [_public_server(item) for item in store.list_servers()]


@app.post("/api/servers", status_code=201, tags=["MCP Servers"], summary="Register an MCP Server")
async def add_server(payload: ServerCreate) -> dict[str, Any]:
    if payload.transport == "stdio":
        if not payload.command:
            raise HTTPException(status_code=422, detail="stdio Server 需要启动命令")
        if not payload.stdio_acknowledged:
            raise HTTPException(status_code=422, detail="必须确认 stdio 命令执行风险")
    elif not payload.url:
        raise HTTPException(status_code=422, detail="HTTP/SSE Server 需要 URL")
    server = {
        "id": _slug(payload.name),
        **payload.model_dump(),
        "status": "configured",
        "tools": [],
        "tool_count": 0,
        "risk_score": None,
        "risk_label": "informational",
        "evaluation_status": "pending",
    }
    store.upsert_server(server)
    return _public_server(server)


@app.post("/api/servers/{server_id}/connect", tags=["MCP Servers"], summary="Connect and refresh tools/list")
async def connect_server(server_id: str) -> dict[str, Any]:
    server = _require_server(server_id)
    server["status"] = "connecting"
    server["evaluation_status"] = "connecting"
    server.pop("connection_error", None)
    server.pop("evaluation_error", None)
    store.upsert_server(server)
    server = await _refresh_server_tools(server)
    return _public_server(server)


async def _score_mcp_snapshot(
    server: dict[str, Any],
    *,
    use_llm: bool,
    previous_score: int | None = None,
) -> dict[str, Any]:
    """Compatibility wrapper around the MCP scoring use case."""
    return await score_mcp_tools_snapshot(
        server,
        use_llm=use_llm,
        previous_score=previous_score,
        model_settings=store.model_settings,
        model_is_configured=public_settings(store.model_settings)["configured"],
        extract_tool=extract_tool,
        extract_server_flows=extract_server_flows,
        score_server=score_server,
        semantic_error_type=QwenError,
    )


@app.post("/api/servers/{server_id}/evaluate", tags=["MCP Servers"], summary="Evaluate an MCP Server and its Tools")
async def evaluate_server(server_id: str, payload: EvaluateRequest) -> dict[str, Any]:
    server = _require_server(server_id)
    if payload.refresh_tools:
        server = await _refresh_server_tools(server)
    if server.get("status") != "connected":
        raise HTTPException(status_code=409, detail="请先连接 Server 并读取 tools/list")

    server["evaluation_status"] = "running"
    server.pop("evaluation_error", None)
    store.upsert_server(server)
    try:
        evaluated = await _score_mcp_snapshot(
            server,
            use_llm=payload.use_llm,
            previous_score=server.get("risk_score"),
        )
        if payload.use_llm:
            _require_completed_mcp_llm(evaluated)
    except asyncio.CancelledError:
        failed = store.get_server(server_id) or server
        failed["evaluation_status"] = "error"
        failed["evaluation_error"] = "评分已中断，未形成完整结果"
        store.upsert_server(failed)
        raise
    except Exception as exc:
        failed = store.get_server(server_id) or server
        failed["evaluation_status"] = "error"
        failed["evaluation_error"] = str(exc)[:500] or type(exc).__name__
        store.upsert_server(failed)
        raise HTTPException(status_code=502, detail={"code": getattr(exc, "code", "MCP_SCORING_FAILED"), "message": failed["evaluation_error"]}) from exc
    evaluated["evaluation_status"] = "completed"
    evaluated.pop("evaluation_error", None)
    store.upsert_server(evaluated)
    return _public_server(evaluated)


def _require_completed_mcp_llm(result: dict[str, Any]) -> None:
    missing = [str(tool.get("name") or "unnamed") for tool in result.get("tools", [])
               if tool.get("classification_status") != "classified"
               or not tool.get("capabilities")
               or (tool.get("llm_raw_response") or {}).get("prompt_version") != LLM_PROMPT_VERSION
               or (tool.get("llm_raw_response") or {}).get("rule_set_version") != RULE_SET_VERSION]
    if missing:
        causes = [str(item) for item in result.get("unknowns", []) if "LLM" in str(item)]
        raise ScoreJobFailure("LLM_SCORING_FAILED", f"MCP Tool 当前版本且有证据支持的语义分类未完成：{', '.join(missing[:10])}。{'；'.join(causes)[:300]}")
    if result.get("flow_candidates") and result.get("flow_classification_status") != "classified":
        raise ScoreJobFailure("LLM_SCORING_FAILED", "MCP FLOW 语义确认未完整完成，未形成完整评分")


@app.delete("/api/servers/{server_id}", status_code=204, tags=["MCP Servers"], summary="Remove an MCP Server")
async def delete_server(server_id: str) -> Response:
    if not store.delete_server(server_id):
        raise HTTPException(status_code=404, detail="MCP Server 不存在")
    return Response(status_code=204)


def _create_score_job(
    kind: Literal["mcp", "skill"],
    *,
    client_reference: str | None,
    input_summary: dict[str, Any],
) -> dict[str, Any]:
    return create_score_job(
        store,
        kind,
        client_reference=client_reference,
        input_summary=input_summary,
    )


def _accepted_job(job: dict[str, Any]) -> dict[str, Any]:
    return accepted_job(job)


async def _run_mcp_score_job(
    request_id: str,
    server: dict[str, Any],
) -> None:
    async def required_llm_score(snapshot: dict[str, Any], *, use_llm: bool) -> dict[str, Any]:
        result = await _score_mcp_snapshot(snapshot, use_llm=True)
        _require_completed_mcp_llm(result)
        return result

    await run_mcp_score_job(
        store,
        request_id,
        server,
        True,
        score_snapshot=required_llm_score,
        serialize_result=_public_server,
    )


async def _run_skill_score_job(request_id: str, packages: list[dict[str, Any]]) -> None:
    async def required_llm_scan(*args: Any, **kwargs: Any) -> dict[str, Any]:
        kwargs.pop("use_llm", None)
        result = await scan_skill(*args, **kwargs, use_llm=True)
        _require_completed_skill_llm(result)
        return result

    await run_skill_score_job(
        store,
        request_id,
        packages,
        True,
        scan_package=required_llm_scan,
    )


def _require_external_scoring_model() -> None:
    if public_settings(store.model_settings)["configured"]:
        return
    raise HTTPException(status_code=409, detail={
        "code": "MODEL_NOT_CONFIGURED",
        "message": "异步评分强制使用 LLM，请先在模型配置中设置 API Key。",
    })


def _score_job_or_404(request_id: str, kind: Literal["mcp", "skill"], response: Response) -> dict[str, Any]:
    job = store.get_score_job(request_id, kind)
    if not job:
        raise HTTPException(status_code=404, detail={
            "code": "SCORE_REQUEST_NOT_FOUND",
            "message": f"未找到 {kind.upper()} 评分请求：{request_id}",
        })
    if job.get("status") in {"queued", "running"}:
        response.headers["Retry-After"] = "2"
    return job


@app.post(
    "/api/v1/score/mcp/requests",
    status_code=202,
    response_model=ScoreJobAccepted,
    response_model_exclude_none=True,
    tags=["Async Scoring"],
    summary="Submit a captured MCP tools/list response",
)
async def submit_mcp_score(payload: ExternalMcpScoreRequest, background_tasks: BackgroundTasks) -> dict[str, Any]:
    try:
        tools = parse_mcp_tools_payload(payload.payload)
    except PayloadFormatError as exc:
        raise HTTPException(status_code=422, detail=exc.detail()) from exc
    _require_external_scoring_model()
    job = _create_score_job(
        "mcp",
        client_reference=payload.client_reference,
        input_summary={
            "name": payload.name,
            "tool_count": len(tools),
            "payload_bytes": len(payload.payload.encode("utf-8")),
            "llm_required": True,
        },
    )
    inventory_id = _external_inventory_id(payload.client_reference, job["request_id"])
    server = {
        "id": inventory_id,
        "name": payload.name,
        "description": payload.description,
        "transport": "snapshot",
        "status": "connected",
        "tools": tools,
        "tool_count": len(tools),
        "server_info": payload.server_info,
        "headers": {},
        "provenance_verified": False,
        "source": "external_api",
        "inventory_mode": "external_snapshot",
        "refresh_supported": False,
        "client_reference": payload.client_reference,
        "last_score_request_id": job["request_id"],
        "ingested_at": job["submitted_at"],
    }
    background_tasks.add_task(
        _run_mcp_score_job,
        job["request_id"],
        server,
    )
    return _accepted_job(job)


@app.get(
    "/api/v1/score/mcp/requests/{request_id}",
    response_model=ScoreJobStatus,
    response_model_exclude_none=True,
    tags=["Async Scoring"],
    summary="Get an MCP scoring result",
)
async def get_mcp_score(request_id: str, response: Response) -> dict[str, Any]:
    return _score_job_or_404(request_id, "mcp", response)


@app.post(
    "/api/v1/score/skill/requests",
    status_code=202,
    response_model=ScoreJobAccepted,
    response_model_exclude_none=True,
    tags=["Async Scoring"],
    summary="Upload a Skill archive containing one or more SKILL.md anchors",
)
async def submit_skill_score(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(description="zip or TAR-family archive containing one or more Skill packages"),
    client_reference: str | None = Form(default=None, max_length=200),
) -> dict[str, Any]:
    filename = file.filename or ""
    archive_bytes = await file.read(8_000_001)
    await file.close()
    try:
        packages = parse_skill_archive(archive_bytes, filename)
    except PayloadFormatError as exc:
        raise HTTPException(status_code=422, detail=exc.detail()) from exc
    _require_external_scoring_model()
    job = _create_score_job(
        "skill",
        client_reference=client_reference,
        input_summary={
            "archive_name": filename,
            "archive_bytes": len(archive_bytes),
            "package_count": len(packages),
            "file_count": sum(len(package["files"]) for package in packages),
            "anchors": [package["anchor"] for package in packages],
            "llm_required": True,
        },
    )
    background_tasks.add_task(_run_skill_score_job, job["request_id"], packages)
    return _accepted_job(job)


@app.get(
    "/api/v1/score/skill/requests/{request_id}",
    response_model=ScoreJobStatus,
    response_model_exclude_none=True,
    tags=["Async Scoring"],
    summary="Get one or more Skill scoring results",
)
async def get_skill_score(request_id: str, response: Response) -> dict[str, Any]:
    return _score_job_or_404(request_id, "skill", response)


@app.get("/api/rules", tags=["MCP Rules"], summary="Get the MCP scoring rule catalog")
async def rules() -> list[dict[str, Any]]:
    return public_rules()


@app.get("/api/settings/model", tags=["Model Settings"], summary="Get public model settings")
async def get_model_settings() -> dict[str, Any]:
    return public_settings(store.model_settings)


@app.get("/api/settings/model/providers", tags=["Model Settings"], summary="Get supported model service defaults")
async def get_model_providers() -> list[dict[str, Any]]:
    return public_provider_options()


@app.put("/api/settings/model", tags=["Model Settings"], summary="Update model settings")
async def update_model_settings(payload: ModelSettingsInput) -> dict[str, Any]:
    settings = compose_model_settings(store.model_settings, payload.model_dump())
    store.save_model_settings(settings)
    return public_settings(store.model_settings)


@app.post("/api/settings/model/test", tags=["Model Settings"], summary="Test model connectivity")
async def test_model_settings(payload: ModelSettingsInput) -> dict[str, Any]:
    candidate = compose_model_settings(store.model_settings, payload.model_dump())
    try:
        from .infrastructure.ai.capabilities import probe_contract
        from .infrastructure.ai.qwen import _chat
        connected=await test_connection(candidate)
        contract=await probe_contract(_chat,candidate,force=True)
        # Return only capability status to the UI, not the probe response.
        return {**connected,'skill_contract':{k:v for k,v in contract.items()
                if k in {'supported','format','model','latency_ms','error'}}}
    except QwenError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


def _skill_slug(name: str) -> str:
    stem = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "skill"
    return f"{stem}-{uuid.uuid4().hex[:6]}"


def _public_skill(skill: dict[str, Any]) -> dict[str, Any]:
    safe = dict(skill)
    for field in ("managed_path", "monitor_enabled", "monitor_interval_seconds", "client_watch_mode", "last_check_at", "last_check_status"):
        safe.pop(field, None)
    legacy_history = safe.pop("history", [])
    latest = safe.get("latest_scan") or (legacy_history[-1] if legacy_history else None)
    if latest:
        latest = dict(latest)
        for field in ("next_check_at", "version", "changed", "change_summary"):
            latest.pop(field, None)
    safe["latest_scan"] = latest
    return safe


def _pending_skill_inventory(
    package: dict[str, Any],
    filename: str,
    skill_id: str,
    *,
    status: str = "pending",
    error_code: str | None = None,
    error_message: str | None = None,
    diagnostics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Persist a parsed Skill before its independent LLM assessment finishes."""
    now = datetime.now(timezone.utc).isoformat()
    snapshot_hash = package["snapshot_hash"]
    files = [
        {
            "path": str(item.get("path") or ""),
            "size": int(item.get("size") or 0),
            "analysis_status": "pending" if status in {"pending", "running"} else "not_analyzed",
        }
        for item in package.get("files") or []
    ]
    latest_scan = {
        "id": f"pending-{snapshot_hash[:12]}",
        "name": package["name"],
        "scanned_at": now,
        "snapshot_hash": snapshot_hash,
        "snapshot_short": snapshot_hash[:12],
        "fingerprint_algorithm": "sha256-canonical-package-v1",
        "analysis_status": status,
        "classification_status": status,
        "file_count": len(files),
        "analyzable_file_count": 0,
        "ignored_file_count": 0,
        "findings": [],
        "files": files,
    }
    if error_code:
        latest_scan["analysis_error_code"] = error_code
    if error_message:
        latest_scan["analysis_error"] = error_message[:500]
    if diagnostics:
        latest_scan["failed_attempt"] = deepcopy(diagnostics)
    return {
        "id": skill_id,
        "name": package["name"],
        "storage_mode": "pending_upload",
        "source_label": filename,
        "package_root": package["root"],
        "created_at": now,
        "fingerprint_hash": snapshot_hash,
        "fingerprint_algorithm": "sha256-canonical-package-v1",
        "fingerprint_created_at": now,
        "latest_scan": latest_scan,
    }


def _cached_skill_by_snapshot(snapshot_hash: str) -> dict[str, Any] | None:
    """Reuse only results produced by the current scoring and prompt policy."""
    for skill in store.list_skills():
        history = skill.get("history") or []
        latest = skill.get("latest_scan") or (history[-1] if history else None)
        if not latest or latest.get("snapshot_hash") != snapshot_hash:
            continue
        if latest.get("rule_set_version") != SKILL_RULE_SET_VERSION:
            continue
        if latest.get("prompt_version") != SKILL_PROMPT_VERSION:
            continue
        if latest.get("flow_prompt_version") != SKILL_FLOW_PROMPT_VERSION:
            continue
        if latest.get("classification_status") != "classified":
            continue
        if (latest.get("analyzer_versions") or {}).get("scoring") != SKILL_SCORING_VERSION:
            continue
        if latest.get("policy_migrated_from"):
            continue
        return skill
    return None


def _skill_attempt_diagnostics(result: dict[str, Any]) -> dict[str, Any]:
    """Keep failure evidence separate from a completed scoring result/configuration."""
    fields = ("id", "name", "snapshot_hash", "scanned_at", "trigger", "rule_set_version",
              "prompt_version", "flow_prompt_version", "analyzer_versions", "classification_status",
              "llm_analysis", "flow_llm_analysis", "flow_candidates", "unknowns")
    return {**{key: deepcopy(result.get(key)) for key in fields},
            "partial_findings": deepcopy(result.get("findings", [])), "is_scored_result": False}


def _require_completed_skill_llm(result: dict[str, Any]) -> None:
    llm_status = (result.get("llm_analysis") or {}).get("status")
    axis_coverage = (result.get("llm_analysis") or {}).get("axis_coverage") or {}
    flow_candidates = result.get("flow_candidates") or []
    flow_status = (result.get("flow_llm_analysis") or {}).get("status")
    if (
        llm_status != "completed"
        or result.get("classification_status") != "classified"
        or not axis_coverage.get("capability")
        or not axis_coverage.get("exposure")
    ):
        missing = (result.get("llm_analysis") or {}).get("missing_axes") or []
        suffix = f" 缺失轴：{', '.join(missing)}。" if missing else ""
        cause = str((result.get("llm_analysis") or {}).get("error") or "")[:300]
        if (result.get('llm_analysis') or {}).get('error_code')=='MODEL_PROVIDER_REJECTED':
            raise ScoreJobFailure('MODEL_PROVIDER_REJECTED',cause,diagnostics=_skill_attempt_diagnostics(result))
        if cause.startswith('MODEL_SCHEMA_UNSUPPORTED'):
            raise ScoreJobFailure('MODEL_SCHEMA_UNSUPPORTED',cause,diagnostics=_skill_attempt_diagnostics(result))
        cause = f" 原因：{cause}" if cause else ""
        raise ScoreJobFailure("LLM_SCORING_INCOMPLETE", f"LLM 未完成 Skill 的 CAP/EXP 双轴分类。{suffix}{cause}", diagnostics=_skill_attempt_diagnostics(result))
    if flow_candidates and flow_status != "completed":
        if (result.get('flow_llm_analysis') or {}).get('error_code')=='MODEL_PROVIDER_REJECTED':
            raise ScoreJobFailure('MODEL_PROVIDER_REJECTED',str(result['flow_llm_analysis'].get('error') or ''),
                                  diagnostics=_skill_attempt_diagnostics(result))
        raise ScoreJobFailure("LLM_SCORING_FAILED", "LLM 未完成 Skill FLOW 语义确认。", diagnostics=_skill_attempt_diagnostics(result))


@app.get("/api/skills", tags=["Skills"], summary="List analyzed Skills")
async def list_skills() -> list[dict[str, Any]]:
    return [_public_skill(item) for item in store.list_skills()]


@app.get("/api/skills/rules", tags=["Skill Rules"], summary="Get the Skill scoring rule catalog")
async def skill_rules() -> dict[str, Any]:
    return public_skill_rules()


@app.get("/api/skills/{skill_id}", tags=["Skills"], summary="Get an analyzed Skill and its current result")
async def get_skill(skill_id: str) -> dict[str, Any]:
    skill = store.get_skill(skill_id)
    if not skill:
        raise HTTPException(status_code=404, detail="Skill 不存在")
    return _public_skill(skill)


def _skill_reassessment_state(
    skill: dict[str, Any],
    status: str,
    *,
    error_code: str | None = None,
    error_message: str | None = None,
    diagnostics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Keep the previous evidence visible while exposing reassessment state."""
    updated = dict(skill)
    latest = dict(updated.get("latest_scan") or {})
    latest["analysis_status"] = status
    latest["classification_status"] = status
    latest.pop("analysis_error_code", None)
    latest.pop("analysis_error", None)
    if error_code:
        latest["analysis_error_code"] = error_code
    if error_message:
        latest["analysis_error"] = error_message[:500]
    if diagnostics:
        latest["failed_attempt"] = deepcopy(diagnostics)
    updated["latest_scan"] = latest
    return updated


@app.post(
    "/api/skills/{skill_id}/evaluate",
    include_in_schema=False,
)
async def evaluate_skill(skill_id: str) -> dict[str, Any]:
    """Re-score one stored Skill with the current model, rules and prompts."""
    skill = store.get_skill(skill_id)
    if not skill:
        raise HTTPException(status_code=404, detail="Skill does not exist")
    if skill.get("storage_mode") != "managed_copy":
        raise HTTPException(status_code=409, detail="Skill 没有可用于重新评估的托管文件副本")
    _require_external_scoring_model()
    try:
        files = load_managed_skill_files(skill_id)
    except Exception as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    store.upsert_skill(_skill_reassessment_state(skill, "running"))
    try:
        result = await scan_skill(
            skill["name"],
            files,
            store.model_settings,
            use_llm=True,
            trigger="manual_reevaluation",
        )
        _require_completed_skill_llm(result)
    except asyncio.CancelledError:
        store.upsert_skill(_skill_reassessment_state(skill, "error", error_code="SCORING_CANCELLED", error_message="重新评估已中断"))
        raise
    except ScoreJobFailure as exc:
        failed = _skill_reassessment_state(
            skill,
            "error",
            error_code=exc.code,
            error_message=str(exc),
            diagnostics=exc.diagnostics,
        )
        store.upsert_skill(failed)
        raise HTTPException(status_code=502, detail={"code": exc.code, "message": str(exc), "analysis": exc.diagnostics}) from exc
    except Exception as exc:
        failed = _skill_reassessment_state(
            skill,
            "error",
            error_code="SKILL_SCAN_FAILED",
            error_message=str(exc) or type(exc).__name__,
        )
        store.upsert_skill(failed)
        raise HTTPException(status_code=502, detail={"code": "SKILL_SCAN_FAILED", "message": str(exc) or type(exc).__name__}) from exc

    updated = dict(skill)
    updated["latest_scan"] = result
    updated["created_at"] = result["scanned_at"]
    updated["fingerprint_hash"] = result["snapshot_hash"]
    updated["fingerprint_created_at"] = result["scanned_at"]
    store.upsert_skill(updated)
    return _public_skill(updated)


@app.post(
    "/api/skills/import-archive",
    tags=["Skills"],
    summary="Upload one archive and scan every exact SKILL.md package",
)
async def import_skill_archive(
    file: UploadFile = File(description="zip or TAR-family archive containing one or more exact SKILL.md files"),
) -> dict[str, Any]:
    filename = file.filename or "skills.zip"
    archive_bytes = await file.read(8_000_001)
    await file.close()
    try:
        packages = parse_skill_archive(archive_bytes, filename)
    except PayloadFormatError as exc:
        raise HTTPException(status_code=422, detail=exc.detail()) from exc

    prepared = [
        {**package, "snapshot_hash": skill_snapshot_hash(package["files"])}
        for package in packages
    ]
    cached = {
        package["snapshot_hash"]: _cached_skill_by_snapshot(package["snapshot_hash"])
        for package in prepared
    }
    if any(not cached[package["snapshot_hash"]] for package in prepared):
        _require_external_scoring_model()

    pending_ids: dict[str, str] = {}
    for package in prepared:
        snapshot_hash = package["snapshot_hash"]
        if cached.get(snapshot_hash) or snapshot_hash in pending_ids:
            continue
        skill_id = _skill_slug(package["name"])
        pending_ids[snapshot_hash] = skill_id
        store.upsert_skill(_pending_skill_inventory(package, filename, skill_id))

    results: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    cache_hits = 0
    scanned = 0
    for package in prepared:
        existing = cached.get(package["snapshot_hash"])
        if existing:
            public = _public_skill(existing)
            public["cache_hit"] = True
            public["submitted_package_root"] = package["root"]
            results.append(public)
            cache_hits += 1
            continue

        previous_inventories = [
            item for item in store.list_skills()
            if item.get("name") == package["name"] and item.get("package_root") == package["root"]
        ]
        skill_id = pending_ids[package["snapshot_hash"]]
        managed_path = None
        store.upsert_skill(_pending_skill_inventory(package, filename, skill_id, status="running"))
        try:
            result = await scan_skill(
                package["name"],
                package["files"],
                store.model_settings,
                use_llm=True,
                trigger="archive_upload",
            )
            _require_completed_skill_llm(result)
            managed_path = save_managed_skill_files(skill_id, package["files"])
        except asyncio.CancelledError:
            store.upsert_skill(_pending_skill_inventory(package, filename, skill_id, status="error", error_code="SCORING_CANCELLED", error_message="上传评分已中断"))
            raise
        except ScoreJobFailure as exc:
            if managed_path:
                delete_managed_skill_files(skill_id)
            store.upsert_skill(_pending_skill_inventory(
                package,
                filename,
                skill_id,
                status="error",
                error_code=exc.code,
                error_message=str(exc),
                diagnostics=exc.diagnostics,
            ))
            failures.append({
                "name": package["name"],
                "package_root": package["root"],
                "code": exc.code,
                "message": str(exc),
                "analysis": exc.diagnostics,
            })
            continue
        except Exception as exc:
            if managed_path:
                delete_managed_skill_files(skill_id)
            store.upsert_skill(_pending_skill_inventory(
                package,
                filename,
                skill_id,
                status="error",
                error_code="SKILL_SCAN_FAILED",
                error_message=str(exc)[:500] or type(exc).__name__,
            ))
            failures.append({
                "name": package["name"],
                "package_root": package["root"],
                "code": "SKILL_SCAN_FAILED",
                "message": str(exc)[:500] or type(exc).__name__,
            })
            continue

        skill = {
            "id": skill_id,
            "name": package["name"],
            "storage_mode": "managed_copy",
            "source_label": filename,
            "package_root": package["root"],
            "managed_path": str(managed_path),
            "created_at": result["scanned_at"],
            "fingerprint_hash": result["snapshot_hash"],
            "fingerprint_algorithm": result["fingerprint_algorithm"],
            "fingerprint_created_at": result["scanned_at"],
            "latest_scan": result,
        }
        store.upsert_skill(skill)
        for previous_inventory in previous_inventories:
            if previous_inventory.get("id") == skill_id:
                continue
            store.delete_skill(previous_inventory["id"])
            if previous_inventory.get("storage_mode") == "managed_copy":
                delete_managed_skill_files(previous_inventory["id"])
        public = _public_skill(skill)
        public["cache_hit"] = False
        results.append(public)
        cached[package["snapshot_hash"]] = skill
        scanned += 1

    return {
        "archive_name": filename,
        "package_count": len(prepared),
        "scanned": scanned,
        "cache_hits": cache_hits,
        "failed": len(failures),
        "failures": failures,
        "skills": results,
    }


@app.delete("/api/skills/{skill_id}", status_code=204, tags=["Skills"], summary="Remove an analyzed Skill")
async def delete_skill(skill_id: str) -> Response:
    skill = store.get_skill(skill_id)
    if not skill:
        raise HTTPException(status_code=404, detail="Skill does not exist")
    if not store.delete_skill(skill_id):
        raise HTTPException(status_code=404, detail="Skill 不存在")
    if skill.get("storage_mode") == "managed_copy":
        delete_managed_skill_files(skill_id)
    return Response(status_code=204)
