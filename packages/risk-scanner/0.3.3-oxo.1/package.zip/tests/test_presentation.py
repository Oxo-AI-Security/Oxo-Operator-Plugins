from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from risk_plugin.io import write,read
from risk_plugin.report import render,project
from risk_plugin.localization import resolve_language

def fixture(tmp_path):
    run=tmp_path/'run'
    write(run/'result.json',{'run_id':'display-only','kind':'skill','status':'partial','items':[
        {'name':'pdf','status':'succeeded','scan':{'effective_risk':100,'risk_label':'block','decision':'Block',
             'findings':[{'id':'CAP-006','title':'创建可恢复本地文件','evidence':[{'path':'SKILL.md','line':1,'quote':'Exact original evidence <script>alert(1)</script>'}]}]}},
        {'name':'incomplete','status':'failed','code':'LLM_SCORING_INCOMPLETE','error':'original diagnosis',
             'diagnostics':{'effective_risk':0,'risk_label':'low','partial_findings':[]}}
    ]})
    return run

class Document(HTMLParser):
    def __init__(self,source):
        super().__init__()
        self.nodes=[]
        self.feed(source)
    def handle_starttag(self,tag,attrs):
        self.nodes.append((tag,dict(attrs)))

def test_html_contains_all_real_content_before_javascript_runs(tmp_path):
    run=fixture(tmp_path)
    output=tmp_path/'report.html'
    render([run],output,language='en')
    html=output.read_text(encoding='utf-8')
    static=re.sub(r'<script>[\s\S]*?</script>','',html)
    nodes=Document(static).nodes
    assert len([n for tag,n in nodes if tag=='details' and 'data-sample' in n])==2
    assert any(n.get('data-rule')=='CAP-006' for _,n in nodes)
    assert 'Exact original evidence &lt;script&gt;' in static
    assert 'CAP-006' in static and 'Create recoverable local files' in static
    assert not any(tag=='script' for tag,_ in nodes)
    assert not any('open' in n for tag,n in nodes if tag=='details')
    assert 'JSON.parse' not in html and 'window.openai' not in html

def test_success_risk_and_failed_status_are_separate_even_with_stale_diagnostics(tmp_path):
    run=fixture(tmp_path)
    result=project(read(run/'result.json'))
    success,failed=result['items']
    assert success['risk_level']=='block' and success['score']==100
    assert failed['risk_level']=='unassessed' and failed['score'] is None

@pytest.mark.parametrize('lang,title,risk,title_rule',[
    ('en','Risk assessment','Critical risk','Create recoverable local files'),
    ('zh-CN','风险评估','极高风险','创建可恢复本地文件'),
])
def test_markdown_has_localized_labels_rule_titles_and_original_evidence(tmp_path,lang,title,risk,title_rule):
    output=tmp_path/(lang+'.html')
    receipt=render([fixture(tmp_path)],output,language=lang,presentation='markdown')
    markdown=Path(receipt['markdown']).read_text(encoding='utf-8')
    assert title in markdown and risk in markdown and title_rule in markdown
    assert 'Exact original evidence <script>alert(1)</script>' in markdown
    assert 'visualize' not in markdown and '<details' not in markdown
    assert receipt['preferred_output']==receipt['markdown']
    assert Path(receipt['standalone']).is_file()

def test_explicit_language_takes_precedence_over_environment(tmp_path,monkeypatch):
    monkeypatch.setenv('RISK_REPORT_LANGUAGE','zh-CN')
    assert resolve_language('en')==('en','explicit')
    assert resolve_language('auto')==('zh-CN','auto')

def test_invalid_schema_cannot_assign_a_risk_to_an_incomplete_result(tmp_path):
    from jsonschema import Draft202012Validator,ValidationError
    run=fixture(tmp_path)
    output=tmp_path/'report.html'
    render([run],output,language='en')
    data=read(output.with_suffix('.view.json'))
    data['runs'][0]['items'][1]['risk_level']='low'
    with pytest.raises(ValidationError):
        Draft202012Validator(read(ROOT/'ui/result.schema.json')).validate(data)

def test_unrecognized_risk_label_is_never_inferred_from_a_number():
    result=project({'kind':'skill','status':'succeeded','items':[{'name':'x','status':'succeeded','scan':{'effective_risk':10,'findings':[]}}]})
    assert result['items'][0]['risk_level']=='unassessed'

def test_markdown_preserves_backticks_without_closing_source_block():
    from risk_plugin.report_markdown import fenced
    source='```\n### Not a report heading\n```'
    assert fenced(source).startswith('````text\n')

def test_content_cannot_interpolate_template_tokens_or_add_markdown_images(tmp_path):
    run=fixture(tmp_path)
    payload=read(run/'result.json')
    payload['items'][0]['scan']['findings'][0]['evidence'][0]['quote']='__RISK_LANGUAGE__ __RISK_CONTENT__'
    payload['items'][0]['name']='![untrusted](https://example.com/image.png)'
    write(run/'result.json',payload)
    output=tmp_path/'result.html'
    render([run],output,language='en',presentation='markdown')
    assert '__RISK_LANGUAGE__ __RISK_CONTENT__' in output.read_text(encoding='utf-8')
    assert '![untrusted](' not in output.with_suffix('.md').read_text(encoding='utf-8')

def test_languages_share_the_same_versioned_presentation_bundle(tmp_path):
    run=fixture(tmp_path)
    a=render([run],tmp_path/'zh.html',language='zh-CN')
    b=render([run],tmp_path/'en.html',language='en')
    assert a['presentation_sha256']==b['presentation_sha256']
    assert a['template_sha256']==b['template_sha256']
    assert read(tmp_path/'zh.view.json')['runs']==read(tmp_path/'en.view.json')['runs']


@pytest.mark.parametrize('language,visible,absent',[('zh-CN','风险评估','Risk assessment'),('en','Risk assessment','风险评估')])
def test_report_has_only_selected_language_and_no_legend_switch_or_scripts(tmp_path,language,visible,absent):
    output=tmp_path/'report.html'
    render([fixture(tmp_path)],output,language=language)
    html=output.read_text(encoding='utf-8')
    nodes=Document(html).nodes
    assert visible in html and absent not in html
    assert 'risk-legend' not in html and 'data-language-choice' not in html
    assert not any(tag in {'script','button'} for tag,_ in nodes)
    assert any(attrs.get('data-risk')=='block' for _,attrs in nodes)


@pytest.mark.parametrize('presentation',['auto','inline','standalone'])
def test_html_delivery_never_defaults_to_markdown(tmp_path,presentation):
    output=tmp_path/'report.html'
    receipt=render([fixture(tmp_path)],output,language='zh-CN',presentation=presentation)
    assert receipt['markdown'] is None
    assert not list(tmp_path.glob('*.md'))
    assert Path(receipt['preferred_output']).suffix=='.html'
    standalone=Path(receipt['standalone']).read_text(encoding='utf-8')
    assert '<!doctype html>' in standalone and '创建可恢复本地文件' in standalone
    if presentation in {'auto','inline'}:
        assert receipt['delivery_order']==['inline','standalone']
        assert receipt['preferred_output']==str(output.resolve())
        assert receipt['fallback_output']==receipt['standalone']
    else:
        assert receipt['preferred_output']==receipt['standalone']
