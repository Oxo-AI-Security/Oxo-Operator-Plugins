"""Server-free HTML: content and native disclosure controls exist before JS runs."""
from html import escape
import json
from .localization import LANGUAGES, text, rule_titles

def raw(value):
    return '<pre><code>'+escape(json.dumps(value,ensure_ascii=False,indent=2))+'</code></pre>'

def localized(values,language):
    return '<span data-locale="'+language+'">'+escape(str(values[language]))+'</span>'

def label(key,language):
    return localized({lang:text(key,lang) for lang in LANGUAGES},language)

def badge(key,language,*,risk=False):
    return '<span class="risk-badge" data-'+('risk' if risk else 'state')+'="'+escape(key,quote=True)+'"><span class="risk-dot" aria-hidden="true"></span>'+label(key,language)+'</span>'

def details(summary,content,*,attributes=''):
    return '<details '+attributes+'><summary>'+summary+'</summary><div class="risk-disclosure">'+content+'</div></details>'

def evidence_blocks(value):
    """Expose exact quotations and locations; preserve other fields in raw details."""
    if isinstance(value,list):
        return ''.join(evidence_blocks(item) for item in value)
    if not isinstance(value,dict):
        return '<pre>'+escape(str(value))+'</pre>' if value is not None else ''
    quote=value.get('quote') or value.get('snippet') or value.get('text')
    location=' · '.join(str(x) for x in [value.get('path') or value.get('file') or value.get('field'),
                        value.get('line') or value.get('line_start') or value.get('start_line'),value.get('role')] if x is not None)
    if quote is not None:
        return '<div class="risk-evidence"><div class="text-small text-muted">'+escape(location)+'</div><pre>'+escape(str(quote))+'</pre></div>'
    return ''.join(evidence_blocks(child) for child in value.values() if isinstance(child,(dict,list)))

def render_content(data,language):
    samples=[(run,item) for run in data['runs'] for item in run['items']]
    complete=sum(item['status']=='succeeded' for _,item in samples)
    overview=localized({lang:f"{len(samples)} {text('samples',lang)} · {complete} {text('completed',lang)} · {len(samples)-complete} {text('incomplete',lang)}" for lang in LANGUAGES},language)
    header='<header class="risk-header"><div><h2 id="risk-report-title">'+label('title',language)+'</h2><div class="text-small text-muted">'+overview+'</div></div>'
    content=header+'</header><div class="risk-samples">'
    for index,(run,item) in enumerate(samples):
        completed=item['status']=='succeeded'
        risk=item.get('risk_level') or 'unassessed'
        name=label('plugin',language) if item.get('display_kind')=='inventory' else escape(item['name'])
        summary='<span class="risk-sample-summary"><span class="risk-sample-name">'+name+'</span><span class="risk-sample-labels">'
        summary+=badge(risk,language,risk=True)+badge('completed' if completed else item['status'] if item['status'] in {'partial','queued','running'} else 'incomplete',language)
        score=escape(str(item['score']))+' / 100' if completed and item['score'] is not None else label('no_score',language)
        summary+='<span class="risk-score tabular-nums">'+score+'</span></span></span>'
        body=''
        if completed:
            decision=str(item.get('decision') or '').lower()
            decision='decision_block' if decision=='block' else decision
            body+='<div class="risk-decision">'+label('decision',language)+' · '+label(decision or 'completed',language)+'</div>'
        else:
            reason='partial_reason' if item['status']=='partial' else 'incomplete_reason' if item.get('code') in {'LLM_SCORING_INCOMPLETE','LLM_SCORING_FAILED'} else 'error_reason'
            body+='<div class="risk-notice" role="status">'+label(reason,language)+'</div>'
            if item.get('code') or item.get('error'):
                body+=details(label('source_diagnostics',language),raw({'code':item.get('code'),'message':item.get('error')}))
        findings=item['findings']
        rule_heading='rules' if completed else 'partial_findings'
        body+='<h3>'+label(rule_heading,language)+' <span class="text-small tabular-nums">'+str(len(findings))+'</span></h3>'
        if not findings:
            body+='<p class="text-muted">'+label('no_findings' if completed else 'no_final_findings',language)+'</p>'
        for finding in findings:
            identifier=str(finding.get('rule_id') or finding.get('id') or '—')
            title=rule_titles(run['kind'],finding)
            rule_summary='<code>'+escape(identifier)+'</code> · '+localized(title,language)
            if not completed: rule_summary+=' · '+label('partial_findings',language)
            evidence=finding.get('evidence') or finding.get('evidence_chain') or finding
            body+=details(rule_summary,evidence_blocks(evidence)+details(label('raw',language),raw(finding)),attributes='class="risk-rule" data-rule="'+escape(identifier,quote=True)+'"')
        if item['unknowns']:
            body+=details(label('unknowns',language)+' · '+str(len(item['unknowns'])), '<div class="text-small text-muted">'+label('source_language',language)+'</div>'+''.join('<p>'+escape(str(x))+'</p>' for x in item['unknowns']))
        audit={key:item.get(key) for key in ('rule_version','fingerprint','risk_level','decision','stages')}
        audit.update(engine=run.get('engine'),coverage=run.get('coverage'))
        body+=details(label('audit',language),raw(audit))
        if run.get('package_inventory') is not None:
            body+=details(label('inventory',language),raw(run['package_inventory']))
        content+=details(summary,body,attributes='class="risk-sample" data-sample="'+str(index)+'"')
    content+='</div>'
    for run in data['runs']:
        if run.get('error'):
            content+=details(label('source_diagnostics',language),raw(run['error']))
    content+='<footer class="risk-footer text-small text-muted">'+label('scope',language)+'</footer>'
    content+=details('<span class="text-small text-muted">'+label('audit',language)+'</span>',raw({'template_version':data['template_version'],'template_sha256':data['template_sha256'],'presentation_sha256':data['presentation_sha256'],'schema_version':data['schema_version']}))
    return content

def standalone(fragment,language):
    title=escape(text('title',language))
    # These are local fallback theme tokens, not external assets or host APIs.
    style='''
:root { color-scheme:light dark; --background:light-dark(#ffffff,#15171c); --foreground:light-dark(#18212e,#edf0f5); --muted-foreground:light-dark(#566274,#aeb8c7); --border:light-dark(#dfe5ee,#343e4d); --primary:light-dark(#273c66,#b9cafa); --primary-foreground:light-dark(#ffffff,#14223e); --red:light-dark(#ba2643,#ff8b9d); --orange:light-dark(#b15416,#f6b576); --yellow:light-dark(#886900,#ead777); --green:light-dark(#28714d,#81d1a7); --blue:light-dark(#2755ad,#9abaff); }
body { margin:0 auto; padding:32px 24px; max-width:960px; background:var(--background); color:var(--foreground); font:15px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif; }
button { font:inherit; } .btn { color:var(--foreground); background:transparent; border:1px solid var(--border); border-radius:8px; padding:6px 12px; } .btn[aria-pressed="true"] { color:var(--primary-foreground); background:var(--primary); } .text-small { font-size:13px; } .text-muted { color:var(--muted-foreground); } .tabular-nums { font-variant-numeric:tabular-nums; }
@media(max-width:480px){body{padding:20px 16px;}}
'''
    return '<!doctype html><html lang="'+language+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; style-src &#39;unsafe-inline&#39;; base-uri &#39;none&#39;; form-action &#39;none&#39;"><title>'+title+'</title><style>'+style+'</style></head><body>'+fragment+'</body></html>'
