"""File-based model port; the calling host supplies each stage's answer.

This is a pipeline rendezvous, not a model/API client or autonomous agent loop.
Each request is answered once; invalid answers remain evidence of failure.
"""
import asyncio
import time
import uuid
from .io import read, write, sha

class HostModel:
    def __init__(self, run_dir, *, timeout=900):
        self.run_dir = run_dir
        self.timeout = timeout

    async def __call__(self, settings, messages, *, max_tokens=800):
        from backend.infrastructure.ai.qwen import QwenError
        from backend.infrastructure.ai.schema_validation import validation_errors
        request_id = uuid.uuid4().hex
        schema = settings.get('_response_schema')
        request = {'id':request_id, 'model_source':'calling-host-session',
                   'messages':messages, 'response_schema':schema,
                   'max_tokens_from_original_pipeline':max_tokens,
                   'request_sha256':sha({'messages':messages,'schema':schema}),
                   'timeout_seconds':self.timeout}
        write(self.run_dir / 'requests' / (request_id+'.json'), request)
        started = time.monotonic()
        response_path = self.run_dir / 'responses' / (request_id+'.json')
        while not response_path.exists():
            if time.monotonic()-started > self.timeout:
                raise QwenError('HOST_MODEL_TIMEOUT: no host answer; no score produced')
            await asyncio.sleep(.2)
        envelope = read(response_path)
        if envelope.get('request_sha256') != request['request_sha256']:
            raise QwenError('HOST_RESPONSE_IDENTITY_MISMATCH')
        if envelope.get('declined'):
            raise QwenError('HOST_MODEL_DECLINED: '+str(envelope.get('reason',''))[:500])
        response = envelope['response']
        errors = validation_errors(schema,response) if schema else []
        write(self.run_dir / 'receipts' / (request_id+'.json'), {
            'request_sha256':request['request_sha256'], 'response_sha256':sha(response),
            'schema_validation_errors':errors, 'model_source':'calling-host-session',
            'provider_schema_enforcement':'not_applicable_host_file_port',
            'network_calls_by_plugin':0})
        # Return the unchanged answer. Original schema/evidence/version gates
        # own acceptance, including the original bounded format-only repair.
        return response, round((time.monotonic()-started)*1000)

def install_host_port(port):
    """Use the explicit transport seam added to the provider adapter only."""
    from backend.infrastructure.ai import qwen
    qwen.HOST_MODEL_TRANSPORT = port
