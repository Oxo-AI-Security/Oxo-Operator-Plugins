"""Versioned deterministic result projection. Models never author UI."""
import hashlib
import json
from pathlib import Path
from .io import read,write
from .localization import resolve_language

ROOT=Path(__file__).resolve().parents[1]
TEMPLATE_PATH=ROOT/'ui/report-v3-fragment.html'

def project(result):
    items=[]
    for item in result.get('items',[]):
        succeeded=item.get('status')=='succeeded'
        scan=item.get('scan',{}) if succeeded else item.get('diagnostics',{})
        findings=list(scan.get('findings',[])) if succeeded else list(scan.get('partial_findings',[]))
        # MCP scoring stores Tool hits inside each Tool result.
        if succeeded and result.get('kind')=='mcp':
            findings=list(scan.get('matched_rules',[]))
            for tool in scan.get('tools',[]):
                for hit in tool.get('matched_rules',[]):
                    findings.append({**hit,'tool':tool.get('name')})
        items.append({'name':item.get('name','unnamed'),'status':item.get('status','failed'),
                      'score':scan.get('effective_risk',scan.get('effective_risk_score')) if succeeded else None,
                      'decision':scan.get('decision') if succeeded else None,
                      'risk_level':scan.get('risk_label') if succeeded and scan.get('risk_label') in {'informational','low','medium','high','critical','block'} else 'unassessed',
                      'rule_version':scan.get('rule_set_version'), 'fingerprint':scan.get('snapshot_hash',scan.get('source_snapshot_hash')),
                      'error':item.get('error'), 'code':item.get('code'),
                      'findings':findings,'unknowns':scan.get('unknowns',[]),
                      'stages':[{k:stage.get(k) for k in ('stage','family','status','error','error_type','request_sha256')}
                                for stage in (scan.get('llm_analysis') or {}).get('stages',[])]})
    if not items and result.get('package_inventory') is not None:
        items.append({'name':'Plugin inventory','display_kind':'inventory','status':'partial','score':None,
                      'decision':None,'risk_level':'unassessed','rule_version':None,'fingerprint':None,
                      'code':'PLUGIN_PARTIAL_COVERAGE',
                      'error':'清单、hooks、依赖和组件引用仅完成静态盘点；未形成完整插件评分。',
                      'findings':[],'unknowns':[x['area'] for x in result.get('coverage',[]) if x['status']!='semantic_scan_available'],
                      'stages':[]})
    return {'run_id':result.get('run_id'),'kind':result.get('kind'),'status':result.get('status'),
            'items':items,'error':result.get('error'),'coverage':result.get('coverage',[]),
            'package_inventory':result.get('package_inventory'), 'engine':result.get('engine')}

def render(run_dirs,output,*,language='auto',presentation='auto'):
    if presentation not in {'auto','inline','markdown','standalone'}:
        raise ValueError('Unsupported report presentation')
    output=Path(output)
    if output.suffix.lower()!='.html':
        raise ValueError('Report output must use an .html suffix')
    resolved,mode=resolve_language(language)
    template=TEMPLATE_PATH.read_bytes().decode('utf-8')
    presentation_files=['ui/report-v3-fragment.html','ui/result.schema.json','ui/rule-titles.json',
                        'risk_plugin/report.py','risk_plugin/report_html.py',
                        'risk_plugin/report_markdown.py','risk_plugin/localization.py']
    presentation_hashes={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in presentation_files}
    data={'schema_version':'risk-view-v3','template_version':'risk-ui-v3',
          'language':resolved,'language_mode':mode,
          'template_sha256':hashlib.sha256(template.encode()).hexdigest(),
          'presentation_sha256':hashlib.sha256(json.dumps(presentation_hashes,sort_keys=True).encode()).hexdigest(),
          'runs':[project(read(Path(p)/'result.json')) for p in run_dirs]}
    from jsonschema import Draft202012Validator
    Draft202012Validator(read(ROOT/'ui/result.schema.json')).validate(data)
    from .report_html import render_content,standalone
    # Content is escaped and present as native HTML before optional JS runs.
    # No JSON script block, runtime parsing, remote assets or host bridge.
    rendered=template.replace('__RISK_LANGUAGE__',resolved).replace('__RISK_LANGUAGE_MODE__',mode).replace('__RISK_CONTENT__',render_content(data,resolved))
    if len(rendered.encode())>=1_000_000:
        raise ValueError('REPORT_TOO_LARGE: preserve raw JSON and narrow the selected runs')
    output=output.resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(rendered,encoding='utf-8')
    write(output.with_suffix('.view.json'),data)
    standalone_path=output.with_suffix('.standalone.html')
    standalone_path.write_text(standalone(rendered,resolved),encoding='utf-8')
    markdown_path=None
    if presentation=='markdown':
        from .report_markdown import render_markdown
        markdown_path=output.with_suffix('.md')
        markdown_path.write_text(render_markdown(data,resolved),encoding='utf-8')
        for lang in ('zh-CN','en'):
            output.with_suffix('.'+lang+'.md').write_text(render_markdown(data,lang),encoding='utf-8')
    preferred=markdown_path if presentation=='markdown' else standalone_path if presentation=='standalone' else output
    receipt={'path':str(output),'markdown':str(markdown_path) if markdown_path else None,'standalone':str(standalone_path),
             'preferred_output':str(preferred),'presentation':presentation,'language':resolved,
             'delivery_order':['inline','standalone'] if presentation in {'auto','inline'} else [presentation],
             'fallback_output':str(standalone_path) if presentation in {'auto','inline'} else None,
             'template_version':data['template_version'],'template_sha256':data['template_sha256'],
             'presentation_sha256':data['presentation_sha256']}
    print(json.dumps(receipt))
    return receipt
