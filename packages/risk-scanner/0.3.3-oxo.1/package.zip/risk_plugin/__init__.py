"""Local-only adapters. No MCP runtime or network provider is installed."""
