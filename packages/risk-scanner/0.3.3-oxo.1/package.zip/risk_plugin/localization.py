"""Fixed UI vocabulary, independent of model-generated evidence."""
import locale
import os
from pathlib import Path
from .io import read

LANGUAGES=('zh-CN','en')
WORDS={
 'title':('风险评估','Risk assessment'),
 'samples':('样本','Samples'), 'completed':('已完成','Completed'),
 'status':('状态','Status'),
 'incomplete':('未完成','Incomplete'), 'partial':('部分完成','Partial'),
 'running':('分析中','Analyzing'), 'queued':('等待分析','Queued'),
 'risk':('风险等级','Risk level'), 'score':('风险分','Risk score'),
 'decision':('处理建议','Decision'), 'rules':('命中规则','Matched rules'),
 'no_score':('未形成完整评分','No complete score'),
 'partial_notice':('以下仅为部分诊断，不构成完整评分。','The following are partial diagnostics, not a complete assessment.'),
 'no_findings':('没有已确认的规则命中。','No confirmed rule matches.'),
 'no_final_findings':('没有可作为完整结论的规则命中。','No rule matches establish a complete result.'),
 'partial_findings':('部分诊断','Partial diagnostics'),
 'evidence':('原文证据','Source evidence'),
 'raw':('原始字段','Raw fields'),
 'source_diagnostics':('原始诊断（保留源语言）','Original diagnostics (source language retained)'),
 'unknowns':('未验证项','Unverified items'),
 'audit':('分析阶段与来源','Analysis and provenance'),
 'inventory':('插件组件与声明关系','Plugin components and declared relations'),
 'plugin':('插件结构盘点','Plugin inventory'),
 'scope':('分数反映声明能力与暴露面，不代表恶意判定。','Scores reflect declared capabilities and exposure, not malicious intent.'),
 'source_language':('证据与诊断保留原文，界面语言不会改变扫描结论。','Evidence and diagnostics retain their source text; display language does not change the assessment.'),
 'incomplete_reason':('语义分类未完整完成，无法给出最终风险分。','Semantic classification is incomplete; no final risk score is available.'),
 'partial_reason':('仅完成结构或部分组件分析，未形成完整插件评分。','Only inventory or some components were assessed; no complete plugin score is available.'),
 'error_reason':('分析未完成，原因见原始诊断。','Analysis did not complete; see the original diagnostics.'),
 'informational':('提示','Informational'), 'low':('低风险','Low risk'),
 'medium':('中风险','Medium risk'), 'high':('高风险','High risk'),
 'critical':('极高风险','Critical risk'), 'block':('极高风险','Critical risk'),
 'unassessed':('未评定','Not assessed'),
 'allow':('允许','Allow'), 'log':('记录审计','Log'),
 'review':('人工复核','Review'), 'confirm':('确认后执行','Confirm'),
 'restrict':('限制使用','Restrict'), 'quarantine':('隔离','Quarantine'),
 'decision_block':('阻断','Block'),
 'language':('界面语言','Display language'),
 'open':('展开证据','Expand evidence'),
}

def text(key, language):
    return WORDS.get(key,(key,key))[0 if language=='zh-CN' else 1]

def resolve_language(language='auto'):
    if language!='auto':
        if language not in LANGUAGES: raise ValueError('Unsupported report language')
        return language,'explicit'
    hint=os.getenv('RISK_REPORT_LANGUAGE') or (locale.getlocale()[0] or 'en')
    return ('zh-CN' if str(hint).lower().startswith('zh') else 'en'),'auto'

def rule_titles(kind, finding):
    catalog=read(Path(__file__).resolve().parents[1]/'ui/rule-titles.json')
    rule_id=finding.get('rule_id') or finding.get('id') or ''
    entry=catalog.get('mcp' if kind=='mcp' else 'skill',{}).get(rule_id,{})
    original=str(finding.get('title') or finding.get('name') or rule_id)
    return {'zh-CN':entry.get('zh-CN') or original,'en':entry.get('en') or original}
