"""Plain Markdown fallback with no HTML, scripts or host-specific directives."""
import re
import json
from .localization import text,rule_titles

def plain(value):
    return re.sub(r'([\\`*{}\[\]()#+.!_|<>~\-])',r'\\\1',str(value).replace('\r',' ').replace('\n',' '))

def fenced(value):
    value=str(value)
    longest=max([len(x) for x in re.findall(r'`+',value)]+[2])
    fence='`'*(longest+1)
    return fence+'text\n'+value+'\n'+fence

def evidence(value):
    if isinstance(value,list): return '\n\n'.join(filter(None,(evidence(x) for x in value)))
    if not isinstance(value,dict): return fenced(value) if value is not None else ''
    quote=value.get('quote') or value.get('snippet') or value.get('text')
    if quote is not None:
        location=' · '.join(str(x) for x in [value.get('path') or value.get('file') or value.get('field'), value.get('line') or value.get('line_start') or value.get('start_line'),value.get('role')] if x is not None)
        return plain(location)+'\n\n'+fenced(quote)
    return '\n\n'.join(filter(None,(evidence(x) for x in value.values() if isinstance(x,(dict,list)))))

def render_markdown(data,language):
    samples=[(run,item) for run in data['runs'] for item in run['items']]
    lines=['# '+text('title',language),'',text('scope',language),'',
           '| '+ ' | '.join(text(k,language) for k in ['samples','status','risk','score','decision'])+' |',
           '| --- | --- | --- | --- | --- |']
    for run,item in samples:
        succeeded=item['status']=='succeeded'
        status='completed' if succeeded else item['status'] if item['status'] in {'partial','queued','running'} else 'incomplete'
        decision=str(item.get('decision') or '').lower()
        decision='decision_block' if decision=='block' else decision
        name=text('plugin',language) if item.get('display_kind')=='inventory' else plain(item['name'])
        lines.append('| '+ ' | '.join([name,text(status,language),text(item['risk_level'],language),str(item['score']) if succeeded else '—',text(decision,language) if decision else text('no_score',language)])+' |')
    for run,item in samples:
        lines+=['','## '+plain(item['name']),'']
        if item.get('code') or item.get('error'):
            lines+=[text('source_diagnostics',language),'',fenced(str(item.get('code') or '')+'\n'+str(item.get('error') or '')),'']
        if item['status']!='succeeded': lines+=[text('partial_notice',language),'']
        for finding in item['findings']:
            rule_id=finding.get('rule_id') or finding.get('id') or '—'
            lines+=['### '+plain(rule_id)+' · '+plain(rule_titles(run['kind'],finding)[language]),'',evidence(finding.get('evidence') or finding.get('evidence_chain') or finding),'']
        if not item['findings']: lines+=[text('no_findings' if item['status']=='succeeded' else 'no_final_findings',language),'']
        if item['unknowns']:
            lines+=['### '+text('unknowns',language),'',text('source_language',language),'']
            lines+=['- '+plain(x) for x in item['unknowns']]
        if run.get('package_inventory'):
            lines+=['','### '+text('inventory',language),'',fenced(json.dumps(run['package_inventory'],ensure_ascii=False,indent=2))]
        if run.get('coverage'):
            lines+=['','### '+text('audit',language),'',fenced(json.dumps(run['coverage'],ensure_ascii=False,indent=2))]
    lines+=['','---','',data['template_version']+' · '+data['template_sha256']]
    return '\n'.join(lines)+'\n'
