"""Task-owned append-only artifacts and offline process guard."""
import hashlib
import json
from pathlib import Path
import sys
import asyncio
import selectors
import time

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    temporary.replace(path)

def sha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def offline_guard():
    def audit(event, args):
        if event in {'socket.connect','socket.connect_ex','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system'}:
            raise PermissionError('PLUGIN_OFFLINE_BOUNDARY: ' + event)
    sys.addaudithook(audit)

class _TimerSelector(selectors.SelectSelector):
    def register(self, *args, **kwargs):
        raise PermissionError('PLUGIN_OFFLINE_BOUNDARY: file-descriptor polling is not supported')

    def select(self, timeout=None):
        time.sleep(min(timeout if timeout is not None else .2, .2))
        return []

class FileOnlyEventLoop(asyncio.SelectorEventLoop):
    """Timer/tasks only: Windows' normal asyncio socketpair binds a TCP socket.

    This pipeline needs local files and cooperative timers, so omit that waker
    instead of permitting a transient listener or weakening the offline guard.
    """
    def __init__(self):
        super().__init__(_TimerSelector())

    def _make_self_pipe(self):
        pass

    def _close_self_pipe(self):
        pass

    def _write_to_self(self):
        pass
