"""Run the preserved pipeline with a host-supplied local model port."""
import asyncio
import os
from pathlib import Path
import sys
from datetime import datetime, timezone
from .io import read, write, offline_guard, FileOnlyEventLoop
from .host_model import HostModel, install_host_port

def now():
    return datetime.now(timezone.utc).isoformat()

async def scan(run_dir):
    from backend.api.external_payloads import parse_skill_archive, parse_mcp_tools_payload
    from backend.application.skill_scanner import scan_skill, SKILL_RULE_SET_VERSION, SKILL_PROMPT_VERSION
    from backend.application.mcp_scoring import score_mcp_tools_snapshot
    from backend.infrastructure.ai.qwen import extract_tool,extract_server_flows,QwenError
    from backend.domain.mcp.scoring import score_server
    from backend.main import _require_completed_skill_llm, _require_completed_mcp_llm
    spec=read(run_dir/'input.json')
    install_host_port(HostModel(run_dir))
    settings={'execution_mode':'host_session','model':'calling-host-session','provider':'openai_compatible','base_url':'host://local'}
    status={'schema_version':'risk-report-v1','run_id':run_dir.name,'kind':spec['kind'],
            'status':'running','started_at':now(),'model_source':'calling-host-session',
            'plugin_network_calls':0,'items':[], 'coverage':[],
            'engine':{'skill_rules':SKILL_RULE_SET_VERSION,'skill_prompt':SKILL_PROMPT_VERSION,
                      'baseline':'versioned-plugin-contract-fork-requires-real-validation',
                      'model_adapter':'host-file-port-v1','independent_model_contexts':False}}
    write(run_dir/'result.json',status)
    path=Path(spec['path'])
    if spec['kind']=='mcp':
        payload=read(path)
        tools=parse_mcp_tools_payload(__import__('json').dumps(payload))
        server={'id':'snapshot','name':path.stem,'description':'Caller captured metadata snapshot',
                'server_info':spec.get('server_info',{}),'tools':tools,'transport':'external_snapshot'}
        result=await score_mcp_tools_snapshot(server,use_llm=True,previous_score=None,model_settings=settings,
            model_is_configured=True,extract_tool=extract_tool,extract_server_flows=extract_server_flows,
            score_server=score_server,semantic_error_type=QwenError)
        result['status']='external_snapshot'
        result['acquisition']={'method':'caller-supplied-tools-list','connection_performed':False}
        try:
            _require_completed_mcp_llm(result)
            status['items'].append({'name':server['name'],'status':'succeeded','scan':result})
        except Exception as error:
            status['items'].append({'name':server['name'],'status':'failed','code':getattr(error,'code','MCP_SCORING_FAILED'),
                                    'error':str(error),'diagnostics':result,'score':None})
    else:
        raw=path.read_bytes()
        if spec['kind']=='plugin':
            from .packages import inventory
            package=inventory(raw)
            packages=package.pop('packages')
            status.update(package_inventory=package,coverage=package['coverage'])
        else:
            packages=parse_skill_archive(raw,path.name)
        for package in packages:
            result=await scan_skill(package['name'],package['files'],settings,use_llm=True,trigger='host_plugin')
            try:
                _require_completed_skill_llm(result)
                item={'name':package['name'],'status':'succeeded','scan':result}
            except Exception as error:
                item={'name':package['name'],'status':'failed','score':None,
                      'code':getattr(error,'code','SKILL_SCORING_FAILED'),'error':str(error),
                      'diagnostics':getattr(error,'diagnostics',{})}
            status['items'].append(item)
            write(run_dir/'result.json',status)
    statuses=[item['status'] for item in status['items']]
    status['status']='succeeded' if statuses and all(s=='succeeded' for s in statuses) else 'partial' if 'succeeded' in statuses else 'failed'
    if spec['kind']=='plugin':
        # No aggregate safe/low score for inventory-only components.
        status['status']='partial' if any(s=='succeeded' for s in statuses) or not statuses else 'failed'
        status['aggregate_score']=None
    status['completed_at']=now()
    write(run_dir/'result.json',status)

def main(run_dir):
    run_dir=Path(run_dir).resolve()
    os.environ['MCP_RISK_DATA_DIR']=str(run_dir/'engine-state')
    offline_guard()
    try:
        with asyncio.Runner(loop_factory=FileOnlyEventLoop) as runner:
            runner.run(scan(run_dir))
    except BaseException as error:
        current=read(run_dir/'result.json') if (run_dir/'result.json').exists() else {'schema_version':'risk-report-v1','run_id':run_dir.name,'kind':read(run_dir/'input.json')['kind'],'items':[]}
        current.update(status='failed',completed_at=now(),error={'code':type(error).__name__,'message':str(error)[:1500]})
        write(run_dir/'result.json',current)
        raise
