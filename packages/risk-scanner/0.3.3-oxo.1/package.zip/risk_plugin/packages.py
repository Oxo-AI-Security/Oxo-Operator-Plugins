"""Non-executing package inventory and explicit component reachability limits."""
import base64
import io
import json
import stat
import re
import zipfile
from pathlib import PurePosixPath
from .io import sha

MANIFESTS = {'plugin.json','.codex-plugin/plugin.json','.claude-plugin/plugin.json'}
DEPENDENCIES = {'package.json','package-lock.json','requirements.txt','pyproject.toml','uv.lock','Cargo.toml'}

def public_inventory(value, *, private=False):
    if isinstance(value,dict):
        return {key:public_inventory(child,private=private or key.lower() in {'env','headers'} or bool(re.search(r'key|token|password|secret|authorization',key,re.I))) for key,child in value.items()}
    if isinstance(value,list):
        return [public_inventory(child,private=private) for child in value]
    return '[redacted]' if private else value

def inventory(raw):
    from backend.api.external_payloads import (
        _validate_archive_entry, MAX_SKILL_FILES, MAX_SKILL_TOTAL_BYTES,
        MAX_PAYLOAD_CHARS, _skill_packages,
    )
    if len(raw)>MAX_PAYLOAD_CHARS:
        raise ValueError('PLUGIN_ARCHIVE_TOO_LARGE')
    files=[]
    seen=set()
    total=0
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries=[item for item in archive.infolist() if not item.is_dir()]
        if len(entries)>MAX_SKILL_FILES:
            raise ValueError('PLUGIN_FILE_LIMIT_EXCEEDED')
        for index,item in enumerate(entries):
            mode=(item.external_attr>>16)&0xffff
            if item.flag_bits&1 or (mode and stat.S_ISLNK(mode)):
                raise ValueError('PLUGIN_LINK_OR_ENCRYPTION_UNSUPPORTED')
            path=_validate_archive_entry(item.filename,item.file_size,index,seen)
            total+=item.file_size
            if total>MAX_SKILL_TOTAL_BYTES:
                raise ValueError('PLUGIN_UNPACKED_LIMIT_EXCEEDED')
            content=archive.read(item)
            files.append({'path':path,'content_base64':base64.b64encode(content).decode(), 'size':len(content)})
    # One unambiguous package root. Do not treat a nested dependency's manifest
    # as the plugin manifest if the caller selected a parent directory archive.
    roots={str(PurePosixPath(f['path']).parent) for f in files if PurePosixPath(f['path']).name=='plugin.json'
           and PurePosixPath(f['path']).parent.name not in {'.codex-plugin','.claude-plugin'}}
    if len(roots)>1:
        raise ValueError('AMBIGUOUS_PLUGIN_ROOTS')
    root=next(iter(roots),'.')
    prefix='' if root=='.' else root+'/'
    scoped=[{**f,'path':f['path'][len(prefix):]} for f in files if f['path'].startswith(prefix)]
    if not any(f['path'] in MANIFESTS for f in scoped):
        raise ValueError('PLUGIN_MANIFEST_NOT_FOUND')
    components=[]
    edges=[]
    for f in scoped:
        path=f['path']
        basename=PurePosixPath(path).name
        if path in MANIFESTS or basename in DEPENDENCIES or basename in {'mcp.json','.mcp.json','.app.json'} or 'hooks' in PurePosixPath(path).parts:
            kind=('manifest' if path in MANIFESTS else 'dependency' if basename in DEPENDENCIES else 'hook' if 'hooks' in PurePosixPath(path).parts else 'mcp-declaration')
            text=base64.b64decode(f['content_base64']).decode('utf-8',errors='replace')
            parsed=None
            if path.endswith('.json'):
                try: parsed=json.loads(text)
                except ValueError: pass
            components.append({'path':path,'kind':kind,'content':public_inventory(parsed) if parsed is not None else '[non-JSON content inventoried; inspect input locally]',
                               'assessment':'inventory_only','sha256':sha(text)})
            if isinstance(parsed,dict):
                def references(value,location):
                    if isinstance(value,dict):
                        for key,child in value.items(): references(child,location+'.'+key)
                    elif isinstance(value,list):
                        for index,child in enumerate(value): references(child,location+f'[{index}]')
                    elif isinstance(value,str) and (value.startswith('./') or '${' in value):
                        edges.append({'from':path,'field':location,'declared_reference':value,
                                      'reachability':'declared_only_not_execution_verified'})
                references(parsed,'$')
    packages=_skill_packages(scoped,'plugin.zip') if any(PurePosixPath(f['path']).name=='SKILL.md' for f in scoped) else []
    return {'root':root, 'file_count':len(scoped), 'components':components, 'relations':edges,
            'packages':packages, 'coverage':[
                {'area':'anchored-skills','status':'semantic_scan_available'},
                {'area':'manifests-hooks-dependencies-and-component-relations','status':'inventory_only'},
                {'area':'unanchored-scripts-and-binaries','status':'unsupported_semantic_analysis'},
                {'area':'mcp-declarations','status':'static_inventory_only_no_server_connection'},
                {'area':'dependency-vulnerabilities-and-runtime-hook-reachability','status':'not_verified'}]}
