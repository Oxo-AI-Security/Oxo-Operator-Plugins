# MCP declaration review

Input is a captured JSON-RPC tools/list response, never a live MCP connection. Use `catalog mcp` for all 38 public rules and the semantic/flow catalogs, and `schema` for the final record. Review every declared Tool, every Tool-level rule and every Server-level FLOW rule. Preserve exact Tool identities.

For each Tool, record matched/excluded/unknown decisions, actual confidence, source rationale, exclusions and review. Positive evidence is a verbatim quotation from the named original metadata field: name, description, inputSchema, outputSchema or annotations. For structured fields, use the same JSON representation exposed by the source. Do not confuse a pagination token with a credential, logging with security-control modification, authenticated private records with public content, or a dangerous noun with a dangerous action.

Record whether untrusted content enters processing and the declared data classes independently of the capability classification. The local scorer retains annotation-derived exposure checks and metadata checks; agent decisions must agree with those observed deterministic facts. Do not synthesize annotations, verified controls, runtime permissions or prior-version history.

Server FLOW requires actual named participant Tools, original evidence for every role and a concrete semantic transfer path supported by current declarations. Same-server presence is not proof of compatibility or runtime reachability. The original scorer validates prerequisites, roles, evidence and completion; an ineligible or rejected flow cannot create a floor. Unknown analysis stays unassessed.

This scan assesses current Tool declarations. Implementation flaws, CVEs, authentication at runtime and actual deployment controls require separate evidence. Do not claim those were tested.
# Interpretation

The scorer assigns impact and scope points directly at Tool scope. Ordinary effects reach at most 59. For CAP-008, cite exact descriptions or schema with `edit_scope` to establish a new artifact, a recoverable ordinary file, selected ordinary content in one document or a scoped project edit. Review the declared target and scope. Annotations alone cannot establish the tier. The server uses the highest applied Tool component or confirmed FLOW score.

FLOW-003 has a bounded verification tier when the execution Tool declares validation of one selected external change and requires the maintainer's action-level approval. In the matched `flow.verification_gate`, cite that Tool's exact metadata and review the relationship to the source and execution sink. Batch execution, free-form commands or destinations, privileged scope, unclear scope and conflicting declarations are incompatible with this tier. It records a control concern and leaves implementation and runtime isolation unverified. Validated META-001–004 and confirmed dangerous FLOW paths keep their established floors and produce a Dangerous badge in a complete metadata review. META-005 contributes 44.

