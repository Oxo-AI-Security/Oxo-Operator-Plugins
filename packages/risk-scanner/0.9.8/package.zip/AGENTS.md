# Risk Scanner presentation decisions

- Keep all scoring rules, evidence, completion gates and persisted scan outcomes unchanged when changing presentation.
- Ship one versioned template and structured result contract. Render data deterministically; never ask the model to redesign HTML per scan.
- Show the score badge on a 0–10 scale by dividing the stored 0–100 score by ten and rounding half up. Use the original score's risk-level color and leading dot. Use red and green with the separate Dangerous and Safe verdict. Incomplete, failed and inventory-only rows use a neutral status and omit the score.
- Show the static review scope, actual finding outcome, decision and populated evidence groups in the expanded details. Use a capability and exposure score label for capability-only items. Show the exact score and rounding inside Score calculation. Close the HTML report with the applicable rule catalog grouped by dimension and omit per-item unverified lists from the presentation.
- Support Chinese and English. Prefer the user's explicit language, then conversation/host language; never infer language from nationality or location. Preserve evidence in its original language and identify untranslated source diagnostics.
- The full report must be readable and evidence expandable without JavaScript or host bridge APIs. Do not display a language switch or a top risk legend. Select report language from the user's explicit request, then the current conversation.
- Prefer HTML in the response using the host's available native rendering mechanism. Always generate a standalone HTML fallback; absent, unknown or failed inline support must fall back to that HTML, not Markdown. Generate and deliver Markdown only on explicit request. Do not infer unsupported inline merely because another app cannot render it, and never treat a local report as proof of inline interaction.
- No server, MCP runtime, external assets, target execution or additional model API calls for rendering. Keep diagnostics and raw fields collapsed.

- Publisher/author is Quinn Zhang. Plugin listing text is English and describes security risk review of Skills, MCP tools and plugins; do not use implementation wording as the subtitle. Branding uses purple and white.

## Harness ownership

- Default analysis belongs to the calling Harness Agent. Ship clear canonical rule/evidence contracts and the fixed report; do not introduce a second model loop, mandatory question sequence, global merged-source prompt or background answer timer.
- Local helpers freeze inputs, expose bounded original sources, record coverage, validate agent judgments and calculate existing policy scores. They do not infer missing judgments, change source citations, increase confidence or claim semantic independence.
- Preserve archived worker runs for reproducibility; route new Skill/MCP/plugin reviews through the agent-led workflow.
