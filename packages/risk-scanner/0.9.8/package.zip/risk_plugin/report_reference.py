"""Render the scanner's rule catalog with descriptions and no scoring fields."""

from html import escape
from pathlib import Path

from .catalog import catalog
from .io import read
from .localization import rule_titles, text


DIMENSIONS = {
    'skill': ('CAP', 'EXP', 'SEM', 'MAL', 'FLOW'),
    'mcp': ('CAP', 'EXP', 'META', 'FLOW'),
}
CONDITIONS = Path(__file__).resolve().parents[1] / 'ui' / 'rule-conditions.json'


def review_statement(kind, status, language):
    dimensions = DIMENSIONS['mcp' if kind == 'mcp' else 'skill']
    names = [text('dimension_' + code, language) for code in dimensions]
    scope = '、'.join(names) if language == 'zh-CN' else ', '.join(names[:-1]).lower() + ' and ' + names[-1].lower()
    outcome = {
        'capabilities_reviewed': 'review_clean',
        'security_concern': 'review_security_findings',
        'control_review': 'review_control_findings',
    }[status]
    return text('review_coverage', language).format(dimensions=scope) + ' ' + text(outcome, language)


def rule_condition(kind, rule, language, translations):
    identity = rule['id']
    translated = translations.get(kind, {}).get(language, {}).get(identity)
    if translated:
        condition = translated
    elif kind == 'skill':
        condition = rule['definition']
    else:
        criteria = rule.get('required_facts') or rule.get('include_when') or []
        condition = '。'.join(criteria) + '。' if criteria else ''
    if identity == 'FLOW-003':
        condition = ' '.join(filter(None, (condition, text('reference_bounded_flow', language))))
    return condition


def render_dimension(kind, code, rules, language, translations):
    rows = []
    for rule in rules:
        identity = rule['id']
        if identity.split('-', 1)[0] != code:
            continue
        title = rule_titles(kind, rule)[language]
        condition = rule_condition(kind, rule, language, translations)
        description = f'<p>{escape(condition)}</p>' if condition and condition != title else ''
        rows.append(f'<tr data-reference-rule="{escape(identity, quote=True)}">'
                    f'<th scope="row"><code>{escape(identity)}</code></th>'
                    f'<td><strong>{escape(title)}</strong>{description}</td></tr>')
    name = escape(text('dimension_' + code, language))
    detail = escape(text('dimension_detail_' + code, language))
    count = escape(text('reference_count', language).format(count=len(rows)))
    code_title = escape(text('reference_id', language))
    rule_title = escape(text('reference_condition', language))
    return (f'<details class="risk-rule-dimension" data-dimension="{code}">'
            f'<summary><span class="risk-dimension-heading"><code>{code}</code>'
            f'<strong>{name}</strong><span class="risk-reference-count">{count}</span></span></summary>'
            f'<div class="risk-dimension-body"><p>{detail}</p>'
            f'<table class="risk-reference-table" aria-label="{name}">'
            f'<thead><tr><th scope="col">{code_title}</th><th scope="col">{rule_title}</th></tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table></div></details>')


def render_reference(runs, language):
    kinds = {'skill' if run['kind'] == 'plugin' else run['kind'] for run in runs}
    translations = read(CONDITIONS)
    sections = []
    for kind, dimensions in DIMENSIONS.items():
        if kind not in kinds:
            continue
        rules = catalog(kind)['rules']
        heading = escape(text('reference_' + kind, language))
        groups = ''.join(render_dimension(kind, code, rules, language, translations) for code in dimensions)
        sections.append(f'<section class="risk-rule-family" data-rule-family="{kind}"><h3>{heading}</h3>'
                        f'{groups}</section>')
    if not sections:
        return ''
    title = escape(text('rule_reference', language))
    return (f'<details class="risk-rule-reference"><summary>{title}</summary>'
            f'<div class="risk-reference-body">{"".join(sections)}</div></details>')
