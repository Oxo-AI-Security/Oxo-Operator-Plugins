"""Final agent-authored evidence contract; it prescribes outcomes, not a loop."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

from backend.application.skill_profile_types import Operation
from backend.application.skill_authority import AuthorityDecision


class Record(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True, allow_inf_nan=False)


class Review(Record):
    confidence: float = Field(ge=0, le=1)
    source_reason: str = Field(min_length=1)


class Participant(Record):
    role: str = Field(min_length=1)
    evidence_id: str = Field(min_length=1)


class Flow(Record):
    data_path: str = Field(min_length=1)
    participants: list[Participant] = Field(min_length=1)


class Decision(Record):
    status: Literal['matched', 'excluded', 'unknown']
    confidence: float = Field(ge=0, le=1)
    rationale: str = Field(min_length=1)
    exclusion_analysis: str = Field(min_length=1)
    evidence_ids: list[str]
    operation_ids: list[str]
    review: Review
    flow: Flow | None = None
    integrity_effect: Literal['sensitive_boundary_crossing', 'concealed_dangerous_action',
                              'embedded_credential_material'] | None = Field(
        default=None, description='Only for matched MAL-004, MAL-005 or MAL-006. The match evidence and its review must establish the specific effect; omit it when unproven.')


class ReferenceDecision(Record):
    reference_id: str
    status: Literal['active', 'inert', 'unknown']
    confidence: float = Field(ge=0, le=1)
    rationale: str = Field(min_length=1)
    evidence_ids: list[str] = Field(min_length=1)


class ResourceAuthority(AuthorityDecision):
    control_boundary: Literal['identity', 'resource_access', 'platform_security', 'artifact_editing', 'none', 'unknown'] = Field(
        description='Boundary actually controlled by this effect. Artifact editing/formatting flags are distinct from identity, resource access and platform security policy. Cite original source and explain the scope.')


class ScoringFact(Record):
    operation_id: str = Field(min_length=1)
    scope: Literal['bounded_project', 'specified_credential'] | None = None
    authorized: bool | None = None
    recoverable: bool | None = None
    edit_target: Literal['ordinary_file', 'task_artifact', 'selected_content', 'project_patch'] | None = Field(
        default=None, description='Selected content means one ordinary document. A project patch affects only ordinary project files in the authorized task. Cleanup additionally requires original proof of recovery.')
    artifact_creation_operation_id: str | None = Field(default=None,
        description='Required for a task_artifact edit. Identify its separate in-task create operation and cite both action blocks.')
    configuration: Literal['project_guidance'] | None = None
    destination: Literal['approved_project_service'] | None = None
    data: Literal['ordinary'] | None = None
    trigger: Literal['within_request', 'independent_bounded'] | None = None
    execution_source: Literal['fixed_dependency', 'project_test', 'selected_external_verification'] | None = None
    verification_gate_evidence_id: str | None = Field(default=None,
        description='For selected external verification, cite a distinct original block showing the maintainer must approve this particular change before verification.')
    evidence_ids: list[str] = Field(min_length=1)
    review: Review


class SkillDescription(Record):
    text: str = Field(min_length=1, max_length=650,
        description='One plain-text paragraph in the report language describing the Skill’s trigger, actions, outputs and applicable prerequisites.')
    evidence_ids: list[str] = Field(min_length=1,
        description='Original source blocks that support the description.')


class SkillAssessment(Record):
    contract_version: Literal['agent-review-v2']
    source_sha256: str
    policy_sha256: str
    operations: list[Operation]
    authority_reviews: list[ResourceAuthority]
    scoring_facts: list[ScoringFact] = Field(default_factory=list,
        description='Optional source-backed scope, authorization and control facts for an individual operation. Omit unproven facts; code applies the conservative tier.')
    decisions: dict[str, Decision]
    behavior_facts: dict[str, Decision]
    reference_decisions: list[ReferenceDecision]
    unresolved: list[str]
    limitations: list[str]
    skill_description: SkillDescription | None = None


def schema(kind):
    from .catalog import catalog
    policy = catalog(kind)
    def keyed(identities, definition):
        return {'type':'object','properties':{key:{'$ref':'#/$defs/'+definition} for key in identities},
                'required':identities,'additionalProperties':False}
    if kind == 'skill':
        result = SkillAssessment.model_json_schema()
        result['properties']['decisions'] = keyed([r['id'] for r in policy['rules']], 'Decision')
        result['properties']['behavior_facts'] = keyed(list(policy['behavior_facts']), 'Decision')
        return result
    from .mcp_assessment import McpAssessment
    from backend.domain.mcp.rules import SECURITY_ISSUE_TYPES
    result = McpAssessment.model_json_schema()
    result['$defs']['ToolReview']['properties']['decisions'] = keyed([r['id'] for r in policy['rules'] if r['kind']!='flow'], 'ToolDecision')
    result['properties']['flows'] = keyed([r['id'] for r in policy['rules'] if r['kind']=='flow'], 'McpFlowDecision')
    result['$defs']['ToolDecision']['properties']['issue_type'] = {'anyOf':[{'type':'string','enum':list(SECURITY_ISSUE_TYPES)},{'type':'null'}]}
    return result
