"""Versioned deterministic result projection. Models never author UI."""
import hashlib
import json
from pathlib import Path
from .assessment_policy import mcp_danger_rules
from .io import read,write
from .localization import resolve_language
from .skill_scoring import matched_mal_rules
from .static_scoring import risk_level

ROOT=Path(__file__).resolve().parents[1]
TEMPLATE_VERSION='risk-ui-v9'
TEMPLATE_PATH=ROOT/'ui/report-v9-fragment.html'

def project(result):
    items=[]
    kind = result.get('kind')
    for item in result.get('items',[]):
        succeeded=item.get('status')=='succeeded'
        scan=item.get('scan',{}) if succeeded else item.get('diagnostics',{})
        findings=list(scan.get('findings',[])) if succeeded else list(scan.get('partial_findings',[]))
        # MCP scoring stores Tool hits inside each Tool result.
        if succeeded and kind=='mcp':
            findings=list(scan.get('matched_rules',[]))
            for tool in scan.get('tools',[]):
                for hit in tool.get('matched_rules',[]):
                    findings.append({**hit,'tool':tool.get('name')})
        summary = scan.get('assessment_summary') if succeeded else None
        if summary and (scan.get('effective_risk',scan.get('effective_risk_score')) != summary['overall_risk_score']
                        or summary['scoring']['score'] != summary['overall_risk_score']
                        or scan.get('risk_label') != summary['risk_level']
                        or summary['scoring']['level'] != summary['risk_level']
                        or risk_level(summary['overall_risk_score'], policy_version=summary['scoring']['policy_version']) != summary['risk_level']):
            raise ValueError('Stored static score, grade and scoring trace disagree')
        verdict = None
        if summary and kind in {'skill', 'plugin'}:
            mal_rules = matched_mal_rules(findings)
            if summary.get('mal_rule_ids', mal_rules) != mal_rules:
                raise ValueError('Stored MAL rule IDs and validated findings disagree')
            verdict = 'dangerous' if mal_rules else 'safe'
        if summary and kind == 'mcp' and scan.get('classification_status') == 'classified':
            danger_rules = mcp_danger_rules(findings)
            if summary.get('danger_rule_ids', danger_rules) != danger_rules:
                raise ValueError('Stored MCP danger rules and validated findings disagree')
            verdict = 'dangerous' if danger_rules else 'safe'
        items.append({'name':item.get('name','unnamed'),'status':item.get('status','failed'),
                      'score':scan.get('effective_risk',scan.get('effective_risk_score')) if succeeded else None,
                      'decision':scan.get('decision') if succeeded else None,
                      'risk_level':summary['risk_level'] if summary else scan.get('risk_label') if succeeded and scan.get('risk_label') in {'informational','low','medium','high','critical','block'} else 'unassessed',
                      'assessment_summary':summary, 'legacy_scoring':scan.get('legacy_scoring'),
                      'verdict':verdict,
                      'skill_description':scan.get('skill_description') if summary and kind in {'skill', 'plugin'} else None,
                      'rule_version':scan.get('rule_set_version'), 'fingerprint':scan.get('snapshot_hash',scan.get('source_snapshot_hash')),
                      'error':item.get('error'), 'code':item.get('code'),
                      'findings':findings,'unknowns':scan.get('unknowns',[]),
                      'stages':[{k:stage.get(k) for k in ('stage','family','status','error','error_type','request_sha256')}
                                for stage in (scan.get('llm_analysis') or {}).get('stages',[])]})
    if not items and result.get('package_inventory') is not None:
        items.append({'name':'Plugin inventory','display_kind':'inventory','status':'partial','score':None,
                      'decision':None,'risk_level':'unassessed','rule_version':None,'fingerprint':None,
                      'code':'PLUGIN_PARTIAL_COVERAGE',
                      'error':'清单、hooks、依赖和组件引用仅完成静态盘点；未形成完整插件评分。',
                      'findings':[],'unknowns':[x['area'] for x in result.get('coverage',[]) if x['status']!='semantic_scan_available'],
                      'stages':[]})
    return {'run_id':result.get('run_id'),'kind':result.get('kind'),'status':result.get('status'),
            'items':items,'error':result.get('error'),'coverage':result.get('coverage',[]),
            'package_inventory':result.get('package_inventory'), 'engine':result.get('engine')}

def render(run_dirs,output,*,language='auto',presentation='auto',description=None):
    if presentation not in {'auto','inline','markdown','standalone'}:
        raise ValueError('Unsupported report presentation')
    output=Path(output)
    if output.suffix.lower()!='.html':
        raise ValueError('Report output must use an .html suffix')
    if description is not None:
        description = ' '.join(description.split())
        if not 1 <= len(description) < 300:
            raise ValueError('Report description must contain 1–299 characters')
    resolved,mode=resolve_language(language)
    template=TEMPLATE_PATH.read_bytes().decode('utf-8')
    presentation_files=[TEMPLATE_PATH.relative_to(ROOT).as_posix(),'ui/result.schema.json','ui/rule-titles.json','ui/rule-conditions.json',
                        'risk_plugin/report.py','risk_plugin/report_html.py',
                        'risk_plugin/report_markdown.py','risk_plugin/localization.py','risk_plugin/report_reference.py',
                        'risk_plugin/catalog.py','engine/backend/application/skill_scanner.py',
                        'engine/backend/domain/mcp/rules.py']
    presentation_hashes={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in presentation_files}
    data={'schema_version':'risk-view-v6','template_version':TEMPLATE_VERSION,
          'language':resolved,'language_mode':mode,
          'template_sha256':hashlib.sha256(template.encode()).hexdigest(),
          'presentation_sha256':hashlib.sha256(json.dumps(presentation_hashes,sort_keys=True).encode()).hexdigest(),
          'runs':[project(read(Path(p)/'result.json')) for p in run_dirs]}
    if description is not None:
        data['description'] = description
    from jsonschema import Draft202012Validator
    Draft202012Validator(read(ROOT/'ui/result.schema.json')).validate(data)
    from .report_html import render_content,standalone
    # Content is escaped and present as native HTML before optional JS runs.
    # No JSON script block, runtime parsing, remote assets or host bridge.
    rendered=template.replace('__RISK_LANGUAGE__',resolved).replace('__RISK_LANGUAGE_MODE__',mode).replace('__RISK_CONTENT__',render_content(data,resolved))
    if len(rendered.encode())>=1_000_000:
        raise ValueError('REPORT_TOO_LARGE: preserve raw JSON and narrow the selected runs')
    output=output.resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(rendered,encoding='utf-8')
    write(output.with_suffix('.view.json'),data)
    standalone_path=output.with_suffix('.standalone.html')
    standalone_path.write_text(standalone(rendered,resolved),encoding='utf-8')
    markdown_path=None
    if presentation=='markdown':
        from .report_markdown import render_markdown
        markdown_path=output.with_suffix('.md')
        markdown_path.write_text(render_markdown(data,resolved),encoding='utf-8')
        for lang in ('zh-CN','en'):
            output.with_suffix('.'+lang+'.md').write_text(render_markdown(data,lang),encoding='utf-8')
    preferred=markdown_path if presentation=='markdown' else standalone_path if presentation=='standalone' else output
    receipt={'path':str(output),'markdown':str(markdown_path) if markdown_path else None,'standalone':str(standalone_path),
             'preferred_output':str(preferred),'presentation':presentation,'language':resolved,
             'delivery_order':['inline','standalone'] if presentation in {'auto','inline'} else [presentation],
             'fallback_output':str(standalone_path) if presentation in {'auto','inline'} else None,
             'template_version':data['template_version'],'template_sha256':data['template_sha256'],
             'presentation_sha256':data['presentation_sha256']}
    print(json.dumps(receipt))
    return receipt
