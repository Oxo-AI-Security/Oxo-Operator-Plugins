"""Fixed UI vocabulary, independent of model-generated evidence."""
import locale
import os
from pathlib import Path
from .io import read

LANGUAGES=('zh-CN','en')
WORDS={
 'title':("静态分析报告","Static analysis report"),
 'target_description':('对象简介','Target description'),
 'samples':('样本','Samples'), 'completed':('已完成','Completed'),
 'status':('状态','Status'),
 'safe':('安全','Safe'),
 'dangerous':('危险','Dangerous'),
 'mal_verdict_scope':("Skill 的「危险」表示命中 MAL，「安全」表示未命中 MAL。","Skill verdicts show whether a validated MAL rule matched."),
 'mcp_verdict_scope':("MCP 的「危险」表示命中 META-001 至 META-004 或确认危险 FLOW，「安全」表示未确认这些命中。","MCP verdicts show whether META-001–004 or a dangerous FLOW matched."),
 'incomplete':('未完成','Incomplete'), 'partial':('部分完成','Partial'),
 'running':('分析中','Analyzing'), 'queued':('等待分析','Queued'),
 'risk':('风险等级','Risk level'), 'score':('评分','Score'),
 'decision':('处理建议','Decision'), 'rules':('命中规则','Matched rules'),
 'partial_notice':('以下仅为部分诊断，不构成完整评分。','The following are partial diagnostics, not a complete assessment.'),
 'no_findings':('没有已确认的规则命中。','No confirmed rule matches.'),
 'no_final_findings':('没有可作为完整结论的规则命中。','No rule matches establish a complete result.'),
 'partial_findings':('部分诊断','Partial diagnostics'),
 'evidence':('原文证据','Source evidence'),
 'raw':('原始字段','Raw fields'),
 'source_diagnostics':('原始诊断（保留源语言）','Original diagnostics (source language retained)'),
 'audit':('分析阶段与来源','Analysis and provenance'),
 'inventory':('插件组件与声明关系','Plugin components and declared relations'),
 'plugin':('插件结构盘点','Plugin inventory'),
 'capabilities_reviewed':('能力已核对','Capabilities reviewed'),
 'control_review':('控制项需复核','Control review needed'),
 'security_concern':('已确认安全问题或危险路径','Validated concern or dangerous path'),
 'no_aggregate_score':('不合成总体风险分','No aggregate risk score'),
 'review_coverage':("静态审查覆盖{dimensions}。","Static analysis covered {dimensions}."),
 'review_clean':("本次审查未发现安全问题。","This review found no security issues."),
 'review_security_findings':("发现安全相关规则命中，证据见下文。","Security-related rules matched. See the evidence below."),
 'review_control_findings':("有控制项或声明问题需要复核。","Some controls or declarations need review."),
 'capability_exposure_score':("能力与暴露评分","Capability and exposure score"),
 'review_score':("规则审查评分","Rule review score"),
 'badge_score':("徽标显示分数","Displayed badge score"),
 'score_conversion':("原始分数除以 10 后四舍五入。","Divide the original score by 10 and round half up."),
 'score_calculation':('分数怎么算','Score calculation'),
 'score_components':('依次为能力、完整性问题、危险路径、控制问题、声明质量；取最高值，不叠加重复事实。','Components: capability, integrity, dangerous path, control concern and metadata; take the maximum without adding duplicate facts.'),
 'site_score_components':('基础分 = min(100, 13 × Impact + 7 × Exposure)。有效分取基础分与适用下限的最高值。','Base = min(100, 13 × Impact + 7 × Exposure). Effective risk is the maximum of the base and applicable floors.'),
 'skill_score_components':('在同一项操作内计算 13 × Impact + 7 × Exposure。取各操作最高基础分与已验证规则下限中的最大值。','Compute 13 × Impact + 7 × Exposure within each operation. Take the maximum of the highest operation base and validated rule floors.'),
 'bounded_skill_score_components':('同一操作的基础分、能力下限、宽泛触发及未固定依赖的控制项分数映射至 0–59。有效分取各项中的最高值。确认命中的 MAL 与其他安全问题按各自下限计分。','Operation bases, capability floors, broad triggering and unpinned dependency controls are mapped into 0–59. The effective score is the highest applied component. Validated MAL and other security findings use their own floors.'),
 'bounded_mcp_score_components':('工具基础分、能力下限与未固定依赖控制项映射至 0–59。已验证的危险元数据和确认的 FLOW 保留各自规则分。','Tool bases, capability floors and unpinned dependency controls are mapped into 0–59. Validated dangerous metadata and confirmed FLOW use their own rule scores.'),
 'operation_score_components':('按单项操作的影响和作用范围定分，常规操作最高 59。确认的独立安全发现仍按各自下限计分。','Effect and scope determine each operation’s score, up to 59. Independently validated security findings use their own floors.'),
 'verification_gate':('逐次确认的原文证据','Evidence of per-change approval'),
 'operation_scores':('逐项操作分数','Operation scores'),
 'unscaled_score':('原始分','Unscaled score'),
 'rule_floor':('下限','Floor'),
 'malicious_implementation':('已确认的恶意实现行为','Confirmed malicious implementation behavior'),
 'mcp_aggregation':('MCP Server 按各工具分别取最高基础分、能力下限和元数据下限，再纳入已确认的 FLOW。','MCP servers take the highest tool base, capability and metadata values, then include confirmed FLOW.'),
 'component_base':('基础分','Base score'),
 'component_capability_floor':('能力下限','Capability floor'),
 'component_integrity_floor':('完整性下限','Integrity floor'),
 'component_metadata_floor':('元数据下限','Metadata floor'),
 'component_flow_floor':('已确认 FLOW','Confirmed FLOW'),
 'capability_impact':('能力影响等级','Capability impact'),
 'exposure_scope':('暴露范围等级','Exposure scope'),
 'rule_reference':("规则目录","Rule reference"),
 'reference_skill':("Skill 规则","Skill rules"),
 'reference_mcp':("MCP 规则","MCP rules"),
 'reference_id':("规则编号","Rule ID"),
 'reference_condition':("规则与判定条件","Rule and matching criteria"),
 'reference_count':("{count} 条规则","{count} rules"),
 'reference_bounded_flow':("经维护者逐次批准的限域变更验证可作为复核项。","Bounded verification with per-change maintainer approval can qualify for control review."),
 'dimension_CAP':("能力","Capabilities"),
 'dimension_EXP':("暴露面","Exposure"),
 'dimension_SEM':("指令与完整性","Instructions and integrity"),
 'dimension_MAL':("恶意行为迹象","Malicious behavior indicators"),
 'dimension_FLOW':("危险路径","Dangerous paths"),
 'dimension_META':("元数据","Metadata"),
 'dimension_detail_CAP':("审查能读取、修改、传输或执行哪些内容。","Covers the data and resources the Skill or Tool can read, change, send or execute."),
 'dimension_detail_EXP':("审查操作范围、输入来源、权限及触发条件。","Covers reach, input sources, permissions and activation."),
 'dimension_detail_SEM':("识别操控指令优先级、触发、确认或审查的行为。","Covers attempts to alter instruction priority, activation, approval or review."),
 'dimension_detail_MAL':("识别隐蔽持久化、越界、破坏及凭证暴露等行为。","Covers covert persistence, boundary violations, destructive behavior and exposed credentials."),
 'dimension_detail_FLOW':("检查输入到执行、外发或权限变更之间是否存在实际路径。","Checks for a path from input to execution, external delivery or a privileged action."),
 'dimension_detail_META':("审查工具声明中的注入、矛盾、隐藏内容和依赖。","Covers injection, conflicts, hidden content and dependencies in tool declarations."),
 'group_capabilities':('声明能力','Declared capabilities'),
 'group_exposure':('暴露面','Exposure indicators'),
 'group_control_gaps':('需要复核的控制项','Controls to review'),
 'group_security_paths':('危险数据或执行路径','Dangerous data or execution paths'),
 'group_integrity':('完整性与安全行为问题','Integrity and security behavior concerns'),
 'group_metadata':('声明质量问题','Metadata quality concerns'),
 'scoring_provenance':('判定依据与历史评分对照','Disposition and historical scoring comparison'),
 'site_scoring_provenance':('计分与处置依据','Score and disposition evidence'),
 'concern_severity':('静态问题严重性（既有政策）','Static concern severity (existing policy)'),
 'incomplete_reason':('语义分类未完整完成，无法给出最终风险分。','Semantic classification is incomplete; no final risk score is available.'),
 'partial_reason':('仅完成结构或部分组件分析，未形成完整插件评分。','Only inventory or some components were assessed; no complete plugin score is available.'),
 'error_reason':('分析未完成，原因见原始诊断。','Analysis did not complete; see the original diagnostics.'),
 'informational':('提示','Informational'), 'low':('低','Low'),
 'medium':('中','Medium'), 'high':('高','High'),
 'critical':('极高','Critical'), 'block':('极高','Critical'),
 'unassessed':('未评定','Not assessed'),
 'allow':('允许','Allow'), 'log':('记录审计','Log'),
 'review':('人工复核','Review'), 'confirm':('确认后执行','Confirm'),
 'restrict':('限制使用','Restrict'), 'quarantine':('隔离','Quarantine'),
 'decision_block':('阻断','Block'),
 'language':('界面语言','Display language'),
 'open':('展开证据','Expand evidence'),
}

def text(key, language):
    return WORDS.get(key,(key,key))[0 if language=='zh-CN' else 1]


def sample_state(item):
    if item['status'] == 'succeeded':
        return item.get('verdict') or 'unassessed'
    return item['status'] if item['status'] in {'partial', 'queued', 'running'} else 'incomplete'

def resolve_language(language='auto'):
    if language!='auto':
        if language not in LANGUAGES: raise ValueError('Unsupported report language')
        return language,'explicit'
    hint=os.getenv('RISK_REPORT_LANGUAGE') or (locale.getlocale()[0] or 'en')
    return ('zh-CN' if str(hint).lower().startswith('zh') else 'en'),'auto'

def rule_titles(kind, finding):
    catalog=read(Path(__file__).resolve().parents[1]/'ui/rule-titles.json')
    rule_id=finding.get('rule_id') or finding.get('id') or ''
    entry=catalog.get('mcp' if kind=='mcp' else 'skill',{}).get(rule_id,{})
    original=str(finding.get('title') or finding.get('name') or rule_id)
    return {'zh-CN':entry.get('zh-CN') or original,'en':entry.get('en') or original}
