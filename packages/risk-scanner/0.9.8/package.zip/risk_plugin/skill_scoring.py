"""Price accepted Skill findings against the operations they actually affect."""
import json
from collections import defaultdict
from pathlib import Path


POLICY = json.loads(Path(__file__).with_name('skill-scoring-policy.json').read_text(encoding='utf-8'))
OPERATION_SCORING = POLICY['operation_scoring']
MAL_RULE_IDS = frozenset(rule for rule in POLICY['rules'] if rule.startswith('MAL-'))
SELECTED_VERIFICATION = POLICY['rules']['FLOW-003']['variants'][0]


def confirmed_malicious(finding):
    return finding['id'] in {'MAL-001', 'MAL-002', 'MAL-003'}


def matched_mal_rules(findings):
    ids = {finding.get('id') or finding.get('rule_id') for finding in findings
           if finding.get('validated') is True}
    return sorted(ids & MAL_RULE_IDS)


def operation_points(impact, exposure):
    """Return effect and scope points for one operation on the common 0–59 scale."""
    return min(OPERATION_SCORING['maximum'],
               OPERATION_SCORING['impact_points'][impact] + OPERATION_SCORING['exposure_points'][exposure])


def apply_rule_floor(finding):
    if finding['dimension'] != 'CAP':
        return finding
    floor = operation_points(finding['impact'], 0)
    return {**finding, 'floor': floor, 'score': floor}


def _variant_applies(variant, operation, facts, confirmed_sinks):
    if not all(facts.get(key) == value for key, value in variant['facts'].items()):
        return False
    if operation is None:
        return bool({'integrity_effect', 'flow_control'} & variant['facts'].keys())
    if 'actions' in variant and operation['action'] not in variant['actions']:
        return False
    if 'origins' in variant and operation['origin'] not in variant['origins']:
        return False
    if set(operation['reach']).intersection(variant.get('exclude_reach', ())):
        return False
    required_flow = variant.get('requires_flow')
    if required_flow:
        return (operation['origin'] in {'public_content', 'service_content'}
                and operation.get('action_evidence_id') in confirmed_sinks.get(required_flow, set()))
    return True


def _rate(finding, operation, facts, sinks):
    rule = POLICY['rules'].get(finding['id'])
    if rule is None:
        return apply_rule_floor(finding)
    values = rule['default']
    tier = 'default'
    for variant in rule.get('variants', ()):
        if _variant_applies(variant, operation, facts, sinks):
            tier = variant['id']
            values = {key: variant[key] for key in values if key in variant}
            break
    if finding['dimension'] == 'CAP':
        score = operation_points(values['impact'], 0)
    else:
        score = values.get('floor', 20 * values['exposure'] if 'exposure' in values else finding['score'])
    return apply_rule_floor({**finding, **values, 'score': score, 'scoring_tier': tier})


def _value(finding):
    return (finding.get('impact') or 0, finding.get('exposure') or 0, finding['floor'])


def calculate(findings, operations, scoring_facts=()):
    """Use the strongest floor and the highest base of a single reviewed operation."""
    from backend.application.skill_scanner import _score_components

    active = {op['operation_id']: op for op in operations if op['actor'] == 'runtime_agent'}
    facts = {record['operation_id']: record for record in scoring_facts}
    confirmed_sinks = defaultdict(set)
    for finding in findings:
        for participant in finding.get('participants', ()):
            if participant['role'] == 'execution_sink' and participant.get('evidence_id'):
                confirmed_sinks[finding['id']].add(participant['evidence_id'])

    by_operation = defaultdict(list)
    rated = []
    for finding in findings:
        identifiers = finding.get('operation_ids', ())
        if finding['dimension'] not in {'CAP', 'EXP'}:
            rated.append(_rate(finding, None, finding, confirmed_sinks))
            continue
        if not identifiers or any(identity not in active for identity in identifiers):
            raise ValueError('Scored rule is not bound to an active reviewed operation')
        variants = []
        for identity in identifiers:
            variant = _rate(finding, active[identity], facts.get(identity, {}), confirmed_sinks)
            variants.append(variant)
            by_operation[identity].append(variant)
        highest = max(variants, key=_value)
        if highest.get('scoring_tier'):
            highest = {**highest, 'scoring_operations': [
                {'operation_id': identity, 'tier': variant['scoring_tier'],
                 'impact': variant.get('impact'), 'exposure': variant.get('exposure'), 'floor': variant['floor']}
                for identity, variant in zip(identifiers, variants)
            ]}
        rated.append(highest)

    score = _score_components(rated)
    score['dimension_scores']['CAP'] = score['capability_floor']
    candidates = []
    for identity, matches in sorted(by_operation.items()):
        impact = max(f.get('impact') or 0 for f in matches)
        exposure = max(f.get('exposure') or 0 for f in matches)
        operation = active[identity]
        candidates.append({'score': operation_points(impact, exposure), 'operation_id': identity, 'impact': impact,
                           'exposure': exposure, 'rule_ids': sorted(f['id'] for f in matches),
                           'resource': operation.get('resource'), 'condition': operation.get('condition'),
                           'action_evidence_id': operation.get('action_evidence_id')})
    strongest = max(candidates, key=lambda row: row['score'], default={
        'score': 0, 'operation_id': None, 'impact': 0, 'exposure': 0, 'rule_ids': [],
    })
    highest_base = strongest['score']
    score.update(base_risk=highest_base,
                 operation_base=strongest, operation_scores=sorted(candidates, key=lambda row: -row['score']),
                 scoring_policy_version=POLICY['version'])
    score['effective_risk'] = max(highest_base, score['rule_floor'], score['flow_floor'], score['hard_gate_floor'])
    return rated, score
