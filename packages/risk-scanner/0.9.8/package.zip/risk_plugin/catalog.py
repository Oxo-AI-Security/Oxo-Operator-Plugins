"""One policy source for agent references, validation and deterministic scoring."""
from .io import sha
from .assessment_policy import MCP_DANGER_METADATA, POLICY, OPERATION_ASSESSMENT_VERSION
from .static_scoring import MCP_FORMULA, MCP_POLICY_VERSION, OPERATION_FORMULA, SCORE_TYPE, SKILL_FORMULA
from .skill_scoring import (OPERATION_SCORING, POLICY as SKILL_SCORING_POLICY, SELECTED_VERIFICATION,
                            apply_rule_floor, operation_points)


def catalog(kind):
    if kind == 'skill':
        from backend.application.skill_scanner import public_skill_rules, BEHAVIOR_FACT_GUIDANCE
        from backend.domain.skill.profile_policy import PREREQUISITES, OPERATION_SEMANTICS
        value = public_skill_rules()
        result = {'kind': kind, 'version': value['rule_set_version'], 'rules': value['rules'],
                  'behavior_facts': BEHAVIOR_FACT_GUIDANCE, 'formula': value['effective_formula'],
                  'operational_prerequisites':PREREQUISITES, 'operation_semantics':OPERATION_SEMANTICS}
    elif kind == 'mcp':
        from backend.domain.mcp.rules import public_rules, RULE_SET_VERSION, llm_rule_catalog, llm_flow_catalog
        result = {'kind': kind, 'version': RULE_SET_VERSION, 'rules': public_rules(),
                  'semantic_catalog': llm_rule_catalog(), 'flow_catalog': llm_flow_catalog()}
    else:
        raise ValueError('Catalog kind must be skill or mcp')
    result['formula'] = POLICY['scoring']['formulas'][kind]
    result['score_type'] = SCORE_TYPE
    result['assessment_policy'] = POLICY
    if kind == 'skill':
        result['formula'] = SKILL_FORMULA
        result['assessment_policy'] = {**POLICY, 'version': OPERATION_ASSESSMENT_VERSION,
                                       'skill_control_gaps': ['FLOW-004'],
                                       'bounded_verification_tier': SELECTED_VERIFICATION['id'],
                                       'scoring': {**SKILL_SCORING_POLICY, 'formula': SKILL_FORMULA, 'base_formula': OPERATION_FORMULA, 'bands': POLICY['scoring']['bands']}}
        for index, rule in enumerate(result['rules']):
            pricing = SKILL_SCORING_POLICY['rules'].get(rule['id'])
            if pricing:
                rule.update(pricing['default'])
                if 'floor' in pricing['default']:
                    rule['score'] = pricing['default']['floor']
                if 'exposure' in pricing['default']:
                    rule['score'] = 20 * pricing['default']['exposure']
                rule['scoring_tiers'] = pricing
            applied = apply_rule_floor(rule)
            if rule['dimension'] == 'CAP':
                applied['scoring_effect'] = f"Impact {applied['impact']} · {applied['floor']} points before scope"
                if pricing:
                    applied['scoring_tiers'] = {**pricing, 'default': {**pricing['default'], 'floor': applied['floor']},
                        'variants': [{**tier, 'floor': operation_points(tier['impact'], 0)} for tier in pricing.get('variants', ())]}
            elif pricing and 'floor' in pricing['default']:
                applied['scoring_effect'] = f"Evidence-backed floor {applied['floor']}"
            result['rules'][index] = applied
    else:
        from backend.domain.mcp.rules import RULE_BY_ID
        result['formula'] = MCP_FORMULA
        result['assessment_policy'] = {**POLICY, 'version': OPERATION_ASSESSMENT_VERSION,
                                       'mcp_danger_metadata': sorted(MCP_DANGER_METADATA),
                                       'bounded_verification_tier': SELECTED_VERIFICATION['id'],
                                       'scoring': {**POLICY['scoring'], 'version': MCP_POLICY_VERSION,
                                                   'formula': MCP_FORMULA, 'base_formula': OPERATION_FORMULA,
                                                   'formulas': {'mcp': MCP_FORMULA},
                                                   'operation_scoring': OPERATION_SCORING}}
        for rule in result['rules']:
            identity = rule['id']
            if identity.startswith('CAP-'):
                impact = RULE_BY_ID[identity]['impact']
                floor = operation_points(impact, 0)
                rule.update(floor=floor, effect=f"Impact {impact} · {floor} points before scope")
            elif identity in OPERATION_SCORING['mcp_control_floors']:
                floor = OPERATION_SCORING['mcp_control_floors'][identity]
                rule.update(floor=floor, effect=f"Supply-chain control floor {floor}")
            elif identity == 'FLOW-003':
                rule['scoring_tiers'] = SKILL_SCORING_POLICY['rules'][identity]
    return {**result, 'policy_sha256': sha(result)}
