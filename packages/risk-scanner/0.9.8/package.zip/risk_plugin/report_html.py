"""Server-free HTML: content and native disclosure controls exist before JS runs."""
from html import escape
import json
from .localization import LANGUAGES, text, rule_titles, sample_state
from .static_scoring import (ARCHIVED_POLICY, MCP_POLICY_V2, MCP_POLICY_V3, MCP_POLICY_VERSION, SKILL_POLICIES,
                             SKILL_POLICY_V2, SKILL_POLICY_V3, SKILL_POLICY_V4, SKILL_POLICY_VERSION)
from .skill_scoring import POLICY as SKILL_SCORING_POLICY
from .report_reference import render_reference, review_statement

BADGE_DOT = '<span class="risk-dot" aria-hidden="true"></span>'


def display_score(points):
    return (points + 5) // 10


def score_conversion(summary, language):
    points = summary['overall_risk_score']
    shown = display_score(points)
    title = 'capability_exposure_score' if summary['status'] == 'capabilities_reviewed' else 'review_score'
    return ('<div class="risk-score-conversion"><div class="risk-conversion-values">'
            '<div>' + label(title, language) + f'<strong>{points} / 100</strong></div>'
            '<div>' + label('badge_score', language) + f'<strong>{shown}</strong></div></div>'
            '<p>' + label('score_conversion', language) + f' <code>{points} ÷ 10 = {points / 10:g} → {shown}</code></p></div>')

def raw(value):
    return '<pre><code>'+escape(json.dumps(value,ensure_ascii=False,indent=2))+'</code></pre>'

def localized(values,language):
    return '<span data-locale="'+language+'">'+escape(str(values[language]))+'</span>'

def label(key,language):
    return localized({lang:text(key,lang) for lang in LANGUAGES},language)

def badge(key,language,*,verdict_scope=None):
    context = ' aria-describedby="' + verdict_scope + '"' if verdict_scope else ''
    return '<span class="risk-badge" data-state="'+escape(key,quote=True)+'"'+context+'>'+BADGE_DOT+label(key,language)+'</span>'

def details(summary,content,*,attributes=''):
    return '<details '+attributes+'><summary>'+summary+'</summary><div class="risk-disclosure">'+content+'</div></details>'

def evidence_blocks(value):
    """Expose exact quotations and locations; preserve other fields in raw details."""
    if isinstance(value,list):
        return ''.join(evidence_blocks(item) for item in value)
    if not isinstance(value,dict):
        return '<pre>'+escape(str(value))+'</pre>' if value is not None else ''
    quote=value.get('quote') or value.get('snippet') or value.get('text')
    location=' · '.join(str(x) for x in [value.get('path') or value.get('file') or value.get('field'),
                        value.get('line') or value.get('line_start') or value.get('start_line'),value.get('role')] if x is not None)
    if quote is not None:
        return '<div class="risk-evidence"><div class="text-small text-muted">'+escape(location)+'</div><pre>'+escape(str(quote))+'</pre></div>'
    return ''.join(evidence_blocks(child) for child in value.values() if isinstance(child,(dict,list)))


def finding_details(finding, kind, language, *, completed=True):
    identifier = str(finding.get('rule_id') or finding.get('id') or '—')
    summary = '<code>' + escape(identifier) + '</code> · ' + localized(rule_titles(kind, finding), language)
    if not completed:
        summary += ' · ' + label('partial_findings', language)
    evidence = finding.get('evidence') or finding.get('evidence_chain') or finding
    rationale = finding.get('llm_rationale') or finding.get('rationale')
    context = '<p>' + escape(str(rationale)) + '</p>' if rationale else ''
    if 'scoring_tier' in finding:
        policy = SKILL_SCORING_POLICY['rules'].get(identifier, {})
        tier = next((v for v in policy.get('variants', ()) if v['id'] == finding['scoring_tier']), policy)
        description = tier.get('label', {}).get('zh' if language == 'zh-CN' else 'en')
        values = ['Impact ' + str(finding['impact'])] if finding.get('impact') is not None else []
        if finding.get('exposure') is not None:
            values.append('Exposure ' + str(finding['exposure']))
        else:
            values.append(text('rule_floor', language) + ' ' + str(finding['floor']))
        context += '<p>' + escape(' · '.join(filter(None, [description, *values]))) + '</p>'
    elif 'unscaled_floor' in finding and finding['unscaled_floor'] != finding['floor']:
        context += '<p>' + label('rule_floor', language) + ' ' + str(finding['floor']) + '</p>'
    if finding.get('verification_evidence'):
        context += '<p>' + label('verification_gate', language) + '</p>' + evidence_blocks(finding['verification_evidence'])
    return details(summary, context + evidence_blocks(evidence) + details(label('raw', language), raw(finding)),
                   attributes='class="risk-rule" data-rule="' + escape(identifier, quote=True) + '"')


def assessment_sections(item, kind, language):
    summary = item['assessment_summary']
    body = ''
    if item.get('verdict'):
        body += '<p class="risk-review-summary">' + escape(review_statement(kind, summary['status'], language)) + '</p>'
    scoring = summary['scoring']
    operations = scoring.get('operation_scores', [])
    formula = 'max(' + ', '.join(str(part['score']) for part in scoring['components'].values()) + ') = ' + str(scoring['score'])
    archived = scoring['policy_version'] == ARCHIVED_POLICY
    if archived:
        explanation = '<p>' + label('score_components',language) + '</p>'
    else:
        formula_key = {
            SKILL_POLICY_VERSION: 'operation_score_components',
            MCP_POLICY_VERSION: 'operation_score_components',
            SKILL_POLICY_V4: 'operation_score_components',
            MCP_POLICY_V3: 'operation_score_components',
            SKILL_POLICY_V3: 'bounded_skill_score_components',
            SKILL_POLICY_V2: 'skill_score_components',
            MCP_POLICY_V2: 'bounded_mcp_score_components',
        }.get(scoring['policy_version'], 'site_score_components')
        explanation = '<p>' + label(formula_key, language) + '</p>'
        if kind == 'mcp':
            explanation += '<p>' + label('mcp_aggregation',language) + '</p>'
        explanation += '<ul>'
        for key, component in scoring['components'].items():
            source = ''
            if key == 'base' and component.get('operation_id'):
                source = ' · ' + escape(component['operation_id']) + ' · Impact ' + str(component['impact']) + ' · Exposure ' + str(component['exposure'])
                if component.get('rule_ids'):
                    source += ' · ' + escape(', '.join(component['rule_ids']))
            if component.get('unscaled_score', component['score']) != component['score']:
                source += ' · ' + label('unscaled_score', language) + ' ' + str(component['unscaled_score'])
            explanation += '<li>' + label('component_' + key,language) + ' · ' + str(component['score']) + source + '</li>'
        explanation += '</ul>'
    if scoring['policy_version'] not in SKILL_POLICIES:
        explanation += '<p>' + label('capability_impact', language) + ' · ' + escape(str(summary['impact'])) + ' / 5<br>'
        explanation += label('exposure_scope', language) + ' · ' + escape(str(summary['exposure'])) + ' / 5</p>'
    if operations:
        rows = []
        for op in operations:
            resource = op.get('resource') or op.get('operation_id') or ''
            condition = ' · ' + escape(op['condition']) if op.get('condition') else ''
            rules = ', '.join(op.get('rule_ids', ()))
            rows.append('<li>' + escape(resource) + ' · ' + str(op['score']) + ' / 59' +
                        (' · ' + escape(rules) if rules else '') + condition + '</li>')
        explanation += details(label('operation_scores', language), '<ul>' + ''.join(rows) + '</ul>')
    if summary['confirmed_concern_severity'] is not None:
        explanation += '<p>' + label('concern_severity', language) + ' · ' + str(summary['confirmed_concern_severity']) + ' / 100</p>'
    if summary.get('confirmed_malicious_implementation'):
        body += '<p>' + label('malicious_implementation', language) + ' · ' + escape(', '.join(summary['confirmed_malicious_implementation'])) + '</p>'
    for group in ('capabilities', 'exposure', 'control_gaps', 'security_paths', 'integrity', 'metadata'):
        identities = set(summary['groups'][group])
        if not identities:
            continue
        body += '<h3>' + label('group_' + group, language) + ' <span class="text-small tabular-nums">' + str(len(identities)) + '</span></h3>'
        for finding in item['findings']:
            if (finding.get('id') or finding.get('rule_id')) in identities:
                body += finding_details(finding, kind, language)
    calculation = score_conversion(summary, language) + explanation + '<pre>' + escape(formula) + '</pre>'
    body += details(label('score_calculation', language), calculation, attributes='class="risk-score-calculation"')
    audit = {'assessment': summary}
    if archived:
        audit['legacy_scoring'] = item.get('legacy_scoring')
    body += details(label('scoring_provenance' if archived else 'site_scoring_provenance', language), raw(audit))
    return body


def render_content(data,language):
    samples=[(run,item) for run in data['runs'] for item in run['items']]
    complete=sum(item['status']=='succeeded' for _,item in samples)
    overview=localized({lang:f"{len(samples)} {text('samples',lang)} · {complete} {text('completed',lang)} · {len(samples)-complete} {text('incomplete',lang)}" for lang in LANGUAGES},language)
    header='<header class="risk-header"><div><h2 id="risk-report-title">'+label('title',language)+'</h2><div class="text-small text-muted">'+overview+'</div></div>'
    content=header+'</header>'
    if data.get('description'):
        content += '<section class="risk-target" aria-labelledby="risk-target-title"><h3 id="risk-target-title">'+label('target_description',language)+'</h3><p>'+escape(data['description'])+'</p></section>'
    content += '<div class="risk-samples">'
    verdict_scopes = set()
    for index,(run,item) in enumerate(samples):
        completed=item['status']=='succeeded'
        name=label('plugin',language) if item.get('display_kind')=='inventory' else escape(item['name'])
        summary='<span class="risk-sample-summary"><span class="risk-sample-name">'+name+'</span><span class="risk-sample-labels">'
        scope = None
        if item.get('verdict'):
            scope = 'mcp_verdict_scope' if run['kind'] == 'mcp' else 'mal_verdict_scope'
            verdict_scopes.add(scope)
        if completed and item['score'] is not None:
            level = escape(item['risk_level'], quote=True)
            badge_score = display_score(item['score'])
            summary += ('<span class="risk-badge risk-score tabular-nums" data-risk="' + level + '">'
                        + BADGE_DOT + str(badge_score) + '</span>')
        summary+=badge(sample_state(item),language,verdict_scope=scope)+'</span></span>'
        assessment = item.get('assessment_summary')
        body=''
        description = item.get('skill_description')
        if description:
            body += '<p class="risk-skill-description">' + escape(description['text']) + '</p>'
        if completed:
            decision=str(item.get('decision') or '').lower()
            decision='decision_block' if decision=='block' else decision
            body+='<div class="risk-decision">'+label('decision',language)+' · '+label(decision or 'completed',language)+'</div>'
        else:
            reason='partial_reason' if item['status']=='partial' else 'incomplete_reason' if item.get('code') in {'LLM_SCORING_INCOMPLETE','LLM_SCORING_FAILED'} else 'error_reason'
            body+='<div class="risk-notice" role="status">'+label(reason,language)+'</div>'
            if item.get('code') or item.get('error'):
                body+=details(label('source_diagnostics',language),raw({'code':item.get('code'),'message':item.get('error')}))
        findings=item['findings']
        if assessment:
            body += assessment_sections(item, run['kind'], language)
        elif findings:
            rule_heading='rules' if completed else 'partial_findings'
            body+='<h3>'+label(rule_heading,language)+' <span class="text-small tabular-nums">'+str(len(findings))+'</span></h3>'
            for finding in findings:
                body += finding_details(finding, run['kind'], language, completed=completed)
        audit={key:item.get(key) for key in ('rule_version','fingerprint','risk_level','decision','stages')}
        if description:
            audit['skill_description_evidence'] = description['evidence']
        audit.update(engine=run.get('engine'),coverage=run.get('coverage'))
        body+=details(label('audit',language),raw(audit))
        if run.get('package_inventory') is not None:
            body+=details(label('inventory',language),raw(run['package_inventory']))
        content+=details(summary,body,attributes='class="risk-sample" data-sample="'+str(index)+'"')
    content+='</div>'
    for run in data['runs']:
        if run.get('error'):
            content+=details(label('source_diagnostics',language),raw(run['error']))
    if verdict_scopes:
        content+='<footer class="risk-footer text-small text-muted">'
        for scope in sorted(verdict_scopes):
            content+='<p id="'+scope+'">'+label(scope, language)+'</p>'
        content+='</footer>'
    content += render_reference(data['runs'], language)
    return content

def standalone(fragment,language):
    title=escape(text('title',language))
    # These are local fallback theme tokens, not external assets or host APIs.
    style='''
:root { color-scheme:light dark; --background:light-dark(#ffffff,#15171c); --foreground:light-dark(#18212e,#edf0f5); --muted-foreground:light-dark(#566274,#aeb8c7); --border:light-dark(#dfe5ee,#343e4d); --primary:light-dark(#273c66,#b9cafa); --primary-foreground:light-dark(#ffffff,#14223e); --red:light-dark(#ba2643,#ff8b9d); --orange:light-dark(#b15416,#f6b576); --yellow:light-dark(#886900,#ead777); --green:light-dark(#28714d,#81d1a7); --blue:light-dark(#2755ad,#9abaff); }
body { margin:0 auto; padding:32px 24px; max-width:960px; background:var(--background); color:var(--foreground); font:15px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif; }
button { font:inherit; } .btn { color:var(--foreground); background:transparent; border:1px solid var(--border); border-radius:8px; padding:6px 12px; } .btn[aria-pressed="true"] { color:var(--primary-foreground); background:var(--primary); } .text-small { font-size:13px; } .text-muted { color:var(--muted-foreground); } .tabular-nums { font-variant-numeric:tabular-nums; }
@media(max-width:480px){body{padding:20px 16px;}}
'''
    return '<!doctype html><html lang="'+language+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; style-src &#39;unsafe-inline&#39;; base-uri &#39;none&#39;; form-action &#39;none&#39;"><title>'+title+'</title><style>'+style+'</style></head><body>'+fragment+'</body></html>'
