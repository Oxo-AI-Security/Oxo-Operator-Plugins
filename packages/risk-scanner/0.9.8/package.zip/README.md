# Risk Scanner 0.9.8

A local rule/evidence/report toolkit for Harness Agents. The calling harness owns analysis and source review. The plugin freezes inputs, supplies original-source identities and complete-delivery accounting, validates exhaustive typed assessments, interprets accepted facts deterministically and renders one fixed interactive report. No default model worker, extra model API, MCP server, listening port or target execution.

## Responsibilities

- `skills/risk-scan`: shared workflow and mode-specific evidence/report references.
- `workspace.py`: frozen inputs, stable source identities, bounded original reads and auditable delivery coverage.
- `assessment_contract.py`, `skill_assessment.py`, `mcp_assessment.py`: strict v2 judgments, original evidence, all rules/facts/references, confidence, operational prerequisites, authority boundaries and FLOW validation.
- `catalog.py`: original rules plus a separately versioned interpretation policy.
- `assessment_policy.py`: separate capabilities, exposure, supply-chain controls, integrity concerns and validated dangerous paths; disposition based on relevant evidence.
- `agent_cli.py`: local tools, immutable draft receipts, explained corrections and terminal publication.
- `report*` and `ui/report-v9-fragment.html` show a static review summary, findings and a collapsible rule reference. The score details explain how the original score converts to the 0–10 badge.

## Interpretation

Skill uses `skill-rule-scoring-v5`. The highest operation contributes at most 59. Original evidence distinguishes selected document edits, bounded project patches, recoverable cleanup and the selected project's tests from broader and more sensitive effects. A FLOW-003 verification path with source-backed maintainer approval of one external change has a floor of 59 and remains a control concern. Unbounded external influence on execution retains the 100-point floor. SEM-003 contributes 36 and the supply-chain rule FLOW-004 contributes 44. Validated MAL floors start at 60.

Completed Skill rows show red **Dangerous** for a validated MAL match or green **Safe** when the MAL review has no validated matches. Other confirmed findings remain visible independently. Each Skill's expanded row starts with its source-backed description in the report language. CAP-013 requires a reviewed identity, authorization or platform security boundary.

MCP uses `mcp-rule-scoring-v4`. Each Tool receives the same impact and scope points from validated declarations. Original metadata can establish a bounded edit or selected external verification tier. META-005 contributes 44. Validated META-001–004 and confirmed dangerous FLOW trigger the red badge in a complete metadata review. Incomplete classification retains a neutral verdict.

## Commands and limits

`scan.py --help` lists prepare, catalog, manifest, read, coverage, schema, validate and finalize. `scan.py render` uses the fixed v6 view. Skills use all 58 rules and MCP metadata all 38 public rules. Source and policy hashes, exact evidence, full catalog and reference coverage, confidence thresholds and FLOW prerequisites still govern validation. The calling harness performs the semantic review.

Plugin package inspection retains unsupported areas and no aggregate package score. No runtime exploitation, dependency CVE discovery or deployment assurance is implied. Dependencies are listed in `engine/requirements.txt`; use a trusted host interpreter and never install target dependencies. Historical worker commands remain only for reproduction. Old packages/results are not rewritten or silently relabeled as v2 judgments.

0.6.1 makes the local JSON output encoding explicitly UTF-8 on non-UTF8 hosts and documents report rendering in CLI help. Assessment policy and evidence gates are identical to 0.6.0.

Archived reports retain their recorded policy. Compiled and opaque files are recorded in the inventory.
