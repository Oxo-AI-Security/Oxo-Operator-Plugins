"""Review every source partition, then reconcile cross-file operational facts."""
import hashlib
import json

from .skill_context import SOURCE_SCOPE
from .skill_profile_types import Review
from .skill_profile_wire import profile_wire_schema, decode_operations
from .identity_contract import keyed_records, identity_records
from ..domain.semantic import supported_confidence


async def partitioned_profile(profile_call, call, settings, files, plan, *, prompt_version, rule_version, error_type):
    # Import the shared grounding/compiler, not another policy implementation.
    from .skill_profile import _ground, _compile_operations
    from .skill_authority import reviewed_authority
    versions = {'prompt_version': prompt_version, 'rule_set_version': rule_version}
    operations, parts, unknowns, coverage = [], [], [], {}
    latency = 0
    for segment in plan.segments:
        identity = segment['segment_id']
        token = SOURCE_SCOPE.set([identity])
        try:
            excerpts = plan.excerpts([identity])
            part_files = [{'path': row['path'], 'text': row['content']} for row in excerpts]
            part = await profile_call(call, settings, part_files, source_index=plan.sources,
                coverage_paths=[row['path'] for row in excerpts], prompt_version=prompt_version,
                rule_version=rule_version, error_type=error_type)
        finally:
            SOURCE_SCOPE.reset(token)
        if not part['coverage_complete']:
            raise error_type(f'SKILL_SOURCE_COVERAGE_INCOMPLETE: unresolved profile partition {identity}')
        for operation in part['operations']:
            operation = dict(operation)
            operation['operation_id'] = identity + '/' + operation['operation_id']
            if operation.get('parent_operation_id'):
                operation['parent_operation_id'] = identity + '/' + operation['parent_operation_id']
            operations.append(operation)
        for row in part['coverage']:
            coverage.setdefault(row['path'], set()).add(row['role'])
        unknowns.extend(part['unknowns'])
        parts.append({'segment_id': identity, 'source_sha256': segment['sha256'], 'profile': part})
        latency += part['latency_ms']
        plan.record('operation_profile_review', [identity])
    plan.require(['operation_profile_review'])
    ids = [o['operation_id'] for o in operations]
    schema = profile_wire_schema(Review.model_json_schema())
    schema['properties']['decisions'] = keyed_records(schema['$defs']['ReviewDecision'], ids, 'operation_id')
    edge_row = {'type': 'object', 'properties': {
        'resolved': {'type': 'boolean'}, 'confidence': {'type': 'number', 'minimum': 0, 'maximum': 1},
        'source_reason': {'type': 'string', 'minLength': 1},
        'evidence_ids': {'type': 'array', 'minItems': 1, 'items': {'type': 'string'}}},
        'required': ['resolved', 'confidence', 'source_reason', 'evidence_ids'], 'additionalProperties': False}
    edge_ids = [e['edge_id'] for e in plan.edges]
    schema['properties']['reference_decisions'] = {'type': 'object',
        'properties': {key: edge_row for key in edge_ids}, 'required': edge_ids, 'additionalProperties': False}
    schema['required'].append('reference_decisions')
    raw, extra = await call(settings, [
        {'role': 'system', 'content':
            'Reconcile the independently reviewed source partitions of one Skill. Review every operation and package reference against original cited evidence and the complete partition coverage ledger. '
            'Check cross-file activation, argument/value flow, guards, omitted effects and conflicting facts. A reference alone is not runtime activation. '
            'Reject incorrect operations; add source-grounded missing operations. Resolve every reference, including inert references, with exact source evidence. '
            'If context or a relationship is insufficient, return unresolved/unknown rather than declaring complete. Do not classify rules or calculate scores. Return response_schema JSON.'},
        {'role': 'user', 'content': json.dumps({**versions, 'operation_reconciliation': True,
            'operations': [{key: value for key, value in o.items()
                            if key not in {'source_evidence', 'entry_reference_chain', 'review', 'authority_review'}} for o in operations],
            'partition_coverage': plan.partition_manifest(),
            'reviewed_partitions': sorted(plan.completed['operation_profile_review']),
            'package_references': plan.edges, 'response_schema': schema}, ensure_ascii=False)}], max_tokens=6500)
    if any(raw.get(key) != value for key, value in versions.items()):
        raise error_type('Skill cross-file profile version mismatch')
    review = Review.model_validate({key: value for key, value in {
        **raw, 'decisions': identity_records(raw['decisions'], 'operation_id'),
        'additional_operations': decode_operations(raw['additional_operations'])}.items() if key != 'reference_decisions'})
    decisions = {row.operation_id: row for row in review.decisions}
    if set(decisions) != set(ids) or len(decisions) != len(review.decisions):
        raise error_type('Skill cross-file operation identities incomplete')
    if set(raw['reference_decisions']) != set(edge_ids):
        raise error_type('Skill cross-file reference coverage incomplete')
    for edge in plan.edges:
        decision = raw['reference_decisions'][edge['edge_id']]
        citations = [plan.sources.by_id.get(key) for key in decision['evidence_ids']]
        if (not decision['resolved'] or not supported_confidence(decision['confidence'])
                or not citations or any(row is None or not row['text'].strip() for row in citations)
                or not any(row['path'] == edge['path'] and edge['quote'] in plan.sources.texts[row['path']]
                           and row['start_line'] <= edge['line'] < row['start_line'] + max(1, row['text'].count('\n'))
                           for row in citations)):
            raise error_type('SKILL_CROSS_FILE_REVIEW_INCOMPLETE: unresolved reference or invalid original citation')
    if not review.coverage_complete or any(not supported_confidence(d.confidence) for d in decisions.values()):
        raise error_type('SKILL_CROSS_FILE_REVIEW_INCOMPLETE: unresolved operational facts')
    accepted = [{**o, 'confidence': min(o['confidence'], decisions[o['operation_id']].confidence),
                 'cross_file_review': decisions[o['operation_id']].model_dump()}
                for o in operations if decisions[o['operation_id']].valid]
    additions = []
    for index, operation in enumerate(review.additional_operations):
        if not supported_confidence(operation.confidence):
            raise error_type('SKILL_CROSS_FILE_REVIEW_INCOMPLETE: uncertain additional operation')
        additions.append(_ground({**operation.model_dump(), 'operation_id': f'cross-file-{index}'}, plan.sources))
    accepted.extend(_compile_operations(additions, plan.sources))
    accepted, authority, authority_latency = await reviewed_authority(call, settings, accepted, plan.sources, versions, error_type)
    plan.profile_complete = True
    plan.cross_file_review = raw
    return {'operations': accepted, 'coverage_complete': True, 'unresolved_operations': [],
        'contract_version': 'skill-operation-profile-segmented-v1',
        'assessment_subject': parts[0]['profile']['assessment_subject'],
        'operations_sha256': hashlib.sha256(json.dumps(accepted, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
        'coverage': [{'path': path, 'role': next(iter(roles)) if len(roles) == 1 else 'mixed', 'partition_roles': sorted(roles)} for path, roles in coverage.items()],
        'unknowns': [*unknowns, *review.unknowns], 'partitions': parts, 'cross_file_review': raw,
        'source_coverage': plan.audit(), 'authority_review': authority,
        'latency_ms': latency + extra + authority_latency}
