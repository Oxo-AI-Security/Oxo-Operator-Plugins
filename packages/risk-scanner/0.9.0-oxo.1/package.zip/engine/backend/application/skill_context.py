"""Lossless source partitions and bounded evidence packets for large Skills.

The source index is package-global. Partitions change transport, never source
identities, rule policy or scores. Missing work cannot become a safe verdict.
"""
import ast
from contextvars import ContextVar
import hashlib
import json

from .package_references import references
from .skill_evidence import SourceIndex

SOURCE_PLAN = ContextVar('skill_source_plan', default=None)
SOURCE_SCOPE = ContextVar('skill_source_scope', default=None)
COMPLETE_SOURCE_LIMIT = 120_000
SEGMENT_CHARACTERS = 24_000
PACKET_CHARACTERS = 120_000


def encoded_size(value):
    return len(json.dumps(value, ensure_ascii=False, separators=(',', ':')))


class SourcePlan:
    def __init__(self, files):
        self.sources = SourceIndex(files)
        self.manifest = [{'path': p, 'characters': len(t),
                          'sha256': hashlib.sha256(t.encode()).hexdigest()}
                         for p, t in sorted(self.sources.texts.items())]
        self.edges = [dict(edge_id=f'R{i}', **edge) for i, edge in enumerate(
            edge for path, text in sorted(self.sources.texts.items())
            for edge in references(path, text, set(self.sources.texts)))]
        self.segments = self._partition()
        self.segment_by_id = {s['segment_id']: s for s in self.segments}
        self.block_segment = {key: s['segment_id'] for s in self.segments for key in s['evidence_ids']}
        self.observed = set()
        self.completed = {}
        self.profile_complete = False
        self.cross_file_review = None
        self.check_partition()

    def _partition(self):
        """Prefer complete Python declarations; split oversized units on source blocks."""
        units = []
        for document in self.sources.documents:
            path = document['path']
            blocks = [b for b in self.sources.catalog if b['path'] == path]
            ends = set()
            if path.endswith('.py'):
                try:
                    tree = ast.parse(self.sources.texts[path])
                    ends = {node.end_lineno for node in tree.body if hasattr(node, 'end_lineno')}
                except (SyntaxError, ValueError):
                    pass  # Syntax availability is not permission to omit source.
            current, size = [], 0
            for block in blocks:
                cost = encoded_size([block['evidence_id'], block['text']]) + 2
                if current and size + cost > SEGMENT_CHARACTERS:
                    units.append(current)
                    current, size = [], 0
                current.append(block)
                size += cost
                if block['start_line'] + block['text'].count('\n') - 1 in ends:
                    units.append(current)
                    current, size = [], 0
            if current:
                units.append(current)
        batches, current, size = [], [], 0
        for unit in units:
            cost = sum(encoded_size([b['evidence_id'], b['text']]) + 2 for b in unit)
            if current and size + cost > SEGMENT_CHARACTERS:
                batches.append(current)
                current, size = [], 0
            current.extend(unit)
            size += cost
        if current:
            batches.append(current)
        return [{'segment_id': f'S{i}', 'evidence_ids': [b['evidence_id'] for b in batch],
                 'sha256': hashlib.sha256(json.dumps(batch, ensure_ascii=False, sort_keys=True).encode()).hexdigest()}
                for i, batch in enumerate(batches)]

    def check_partition(self):
        expected = [b['evidence_id'] for b in self.sources.catalog]
        actual = [key for segment in self.segments for key in segment['evidence_ids']]
        if len(actual) != len(set(actual)) or set(actual) != set(expected):
            raise ValueError('SKILL_SOURCE_COVERAGE_INVALID: missing or duplicate source blocks')
        for path, text in self.sources.texts.items():
            if [k for k in actual if self.sources.by_id[k]['path'] == path] != [b['evidence_id'] for b in self.sources.catalog if b['path'] == path]:
                raise ValueError('SKILL_SOURCE_COVERAGE_INVALID: original block positions changed')
            rebuilt = ''.join(self.sources.by_id[k]['text'] for k in actual if self.sources.by_id[k]['path'] == path)
            if rebuilt != text:
                raise ValueError('SKILL_SOURCE_COVERAGE_INVALID: source bytes or order changed')

    def excerpts(self, identities):
        selected = {key for identity in identities for key in self.segment_by_id[identity]['evidence_ids']}
        return [{'path': path, 'content': ''.join(b['text'] for b in self.sources.catalog
                 if b['path'] == path and b['evidence_id'] in selected)}
                for path in self.sources.texts if any(self.sources.by_id[k]['path'] == path for k in selected)]

    def _citations(self, value):
        found = set()
        if isinstance(value, str) and value in self.sources.by_id:
            found.add(value)
        elif isinstance(value, dict):
            path, quote = value.get('path'), value.get('quote') or value.get('evidence')
            if isinstance(quote, str) and quote and path in self.sources.texts:
                text = self.sources.texts[path]
                start = text.find(quote)
                if start >= 0:
                    offset = 0
                    for block in self.sources.catalog:
                        if block['path'] == path:
                            if offset < start + len(quote) and offset + len(block['text']) > start:
                                found.add(block['evidence_id'])
                            offset += len(block['text'])
            for child in value.values():
                found.update(self._citations(child))
        elif isinstance(value, list):
            for child in value:
                found.update(self._citations(child))
        return found

    def observe(self, response, coverage=None):
        citations = self._citations(response)
        if coverage is not None and not citations <= set(coverage['included_evidence_ids']):
            raise ValueError('SKILL_SOURCE_SCOPE_INVALID: response cites original blocks absent from this request')
        self.observed.update(citations)

    def packet(self, request):
        scopes = request.get('source_segments') or SOURCE_SCOPE.get()
        if scopes is not None:
            if not scopes or any(s not in self.segment_by_id for s in scopes):
                raise ValueError('SKILL_SOURCE_SCOPE_INVALID')
            selected = {k for s in scopes for k in self.segment_by_id[s]['evidence_ids']}
            mode = 'source_partition'
        else:
            selected = self.observed | self._citations(request)
            # Include adjacent original blocks. Every other block was already
            # independently processed, not truncated or summarized away.
            for key in list(selected):
                prefix, number = key.rsplit('-', 1)
                for neighbor in (int(number)-1, int(number)+1):
                    other = f'{prefix}-{neighbor}'
                    if other in self.sources.by_id:
                        selected.add(other)
            mode = 'reviewed_evidence_closure'
        roots = {p for p in self.sources.texts if p.rsplit('/', 1)[-1] == 'SKILL.md'}
        for path in roots:
            blocks = [b for b in self.sources.catalog if b['path'] == path]
            if len(self.sources.texts[path]) <= SEGMENT_CHARACTERS:
                selected.update(b['evidence_id'] for b in blocks)
        # Reference edges are source facts, not executable reachability claims.
        for edge in self.edges:
            selected.update(b['evidence_id'] for b in self.sources.catalog
                            if b['path'] == edge['path'] and b['start_line'] <= edge['line']
                            < b['start_line'] + max(1, b['text'].count('\n')))
        documents = [dict(path=d['path'], id_prefix=d['id_prefix'],
                     blocks=[b for b in d['blocks'] if d['id_prefix']+str(b[0]) in selected])
                     for d in self.sources.documents]
        documents = [d for d in documents if d['blocks']]
        return documents, {'strategy': mode, 'source_plan_sha256': self.fingerprint,
            'source_segments': list(scopes) if scopes else [],
            'included_evidence_ids': sorted(selected),
            'coverage_manifest': self.manifest, 'partitions': self.partition_manifest(),
            'package_references': self.edges, 'profile_coverage_complete': self.profile_complete}

    @property
    def fingerprint(self):
        return hashlib.sha256(json.dumps([self.manifest, self.segments, self.edges], sort_keys=True).encode()).hexdigest()

    def record(self, stage, scopes):
        self.completed.setdefault(stage, set()).update(scopes)

    def require(self, stages):
        expected = set(self.segment_by_id)
        if any(self.completed.get(stage, set()) != expected for stage in stages):
            raise ValueError('SKILL_SOURCE_COVERAGE_INCOMPLETE: a required source partition was not reviewed')

    def audit(self):
        return {'strategy': 'partitioned_source_with_cross_file_review', 'plan_sha256': self.fingerprint,
                'manifest': self.manifest, 'segments': self.segments,
                'completed': {k: sorted(v) for k, v in self.completed.items()},
                'profile_complete': self.profile_complete, 'cross_file_review': self.cross_file_review}

    def partition_manifest(self):
        return [{'segment_id': s['segment_id'], 'sha256': s['sha256'],
                 'block_count': len(s['evidence_ids']), 'first': s['evidence_ids'][0], 'last': s['evidence_ids'][-1]}
                for s in self.segments]


def for_large_package(files):
    excerpts = [{'path': f['path'], 'start_line': 1, 'content': f.get('text', '')} for f in files if f.get('text')]
    return SourcePlan(files) if len(json.dumps(excerpts, ensure_ascii=False)) > COMPLETE_SOURCE_LIMIT else None
