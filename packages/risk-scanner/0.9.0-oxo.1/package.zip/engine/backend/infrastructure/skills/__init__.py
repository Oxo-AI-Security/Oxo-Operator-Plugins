"""Skill package storage adapters."""
