"""MCP protocol adapters."""
