# MCP declaration review

Input is a captured JSON-RPC tools/list response, never a live MCP connection. Use `catalog mcp` for all 38 public rules and the semantic/flow catalogs, and `schema` for the final record. Review every declared Tool, every Tool-level rule and every Server-level FLOW rule. Preserve exact Tool identities.

For each Tool, record matched/excluded/unknown decisions, actual confidence, source rationale, exclusions and review. Positive evidence is a verbatim quotation from the named original metadata field: name, description, inputSchema, outputSchema or annotations. For structured fields, use the same JSON representation exposed by the source. Do not confuse a pagination token with a credential, logging with security-control modification, authenticated private records with public content, or a dangerous noun with a dangerous action.

Record whether untrusted content enters processing and the declared data classes independently of the capability classification. The local scorer retains annotation-derived exposure checks and metadata checks; agent decisions must agree with those observed deterministic facts. Do not synthesize annotations, verified controls, runtime permissions or prior-version history.

Server FLOW requires actual named participant Tools, original evidence for every role and a concrete semantic transfer path supported by current declarations. Same-server presence is not proof of compatibility or runtime reachability. The original scorer validates prerequisites, roles, evidence and completion; an ineligible or rejected flow cannot create a floor. Unknown analysis stays unassessed.

This scan assesses current Tool declarations. Implementation flaws, CVEs, authentication at runtime and actual deployment controls require separate evidence. Do not claim those were tested.
# Interpretation

The scorer uses `min(100, 13 × Impact + 7 × Exposure)` and takes the maximum with CAP and META floors at Tool scope. Server risk is the maximum across Tool scores and confirmed FLOW. Disposition bands are allow, log, confirm, restrict and block, with quarantine for applicable META findings. A complete review that explicitly excludes all CAP rules can apply the verified META-007 floor and still require approval. Missing, uncertain or unreviewed decisions leave the review unassessed. The report keeps declared effects separate from implementation verification and malicious intent.

