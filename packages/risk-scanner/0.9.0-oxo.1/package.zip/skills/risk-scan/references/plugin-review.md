# Plugin package boundaries

Prepare a local plugin ZIP. The helper inventories the manifest, anchored Skills, declared MCP configurations, scripts, hooks, dependencies and component references. Review anchored Skills with the complete Skill policy. Never execute hooks, install dependencies or connect to declared MCP endpoints as a side effect of inspection.

Unanchored executable code, dependency vulnerabilities, runtime component wiring and arbitrary server implementation are not completely assessed by these Skill/MCP declaration policies. Describe concrete observations and unsupported coverage explicitly. Declared MCP configuration is not captured tools/list metadata and cannot be relabeled as an MCP Tool scan. A separate captured metadata input can be assessed with the MCP policy.

The fixed report retains partial package coverage and no aggregate plugin risk score. A successful anchored Skill review does not make the entire plugin safe or fully assessed. Preserve all component records and evidence rather than adding Skill/MCP scores together.
