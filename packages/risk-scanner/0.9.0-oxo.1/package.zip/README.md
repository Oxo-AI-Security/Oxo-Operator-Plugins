# Risk Scanner 0.9.0

A local rule/evidence/report toolkit for Harness Agents. The calling harness owns analysis and source review. The plugin freezes inputs, supplies original-source identities and complete-delivery accounting, validates exhaustive typed assessments, interprets accepted facts deterministically and renders one fixed interactive report. No default model worker, extra model API, MCP server, listening port or target execution.

## Responsibilities

- `skills/risk-scan`: shared workflow and mode-specific evidence/report references.
- `workspace.py`: frozen inputs, stable source identities, bounded original reads and auditable delivery coverage.
- `assessment_contract.py`, `skill_assessment.py`, `mcp_assessment.py`: strict v2 judgments, original evidence, all rules/facts/references, confidence, operational prerequisites, authority boundaries and FLOW validation.
- `catalog.py`: original rules plus a separately versioned interpretation policy.
- `assessment_policy.py`: separate capabilities, exposure, supply-chain controls, integrity concerns and validated dangerous paths; disposition based on relevant evidence.
- `agent_cli.py`: local tools, immutable draft receipts, explained corrections and terminal publication.
- `report*`, `ui/report-v5-fragment.html`: one fixed, escaped, server-free report with native expandable source evidence.

## Interpretation

Skill uses `skill-rule-scoring-v2`. Code prices reviewed findings from `risk_plugin/skill-scoring-policy.json`, including evidence-based tiers for local edits, credential access, external delivery, agent configuration, scope and triggers. The scorer computes `min(100, 13*Impact + 7*Exposure)` within each operation. The final score is the maximum of the operation bases and verified floors. FLOW-004 contributes a 75-point supply-chain floor. Skill scores 80–94 recommend quarantine and 95–100 recommend blocking.

Current results show capability impact/exposure scope (0-5) and separate source-backed concern sections. An unpinned dependency execution path remains a supply-chain concern; it does not alone prove compromise. Validated integrity violations and other dangerous paths retain their original severity and disposition. CAP-013 requires an actual reviewed identity, authorization or platform security boundary; ordinary artifact editing restrictions do not establish that boundary. Unknowns still prevent a complete assessment.

## Commands and limits

`scan.py --help`: prepare, catalog, manifest, read, coverage, schema, validate, finalize. `scan.py render` uses the fixed v5 view. Skills use all 58 rules and MCP metadata all 38 public rules. Source/policy hashes, exact nonblank evidence, full catalog/reference coverage and existing confidence/FLOW prerequisites remain mandatory. Read receipts prove delivery, not semantic correctness; reviews do not claim independent model sessions.

Plugin package inspection retains unsupported areas and no aggregate package score. No runtime exploitation, dependency CVE discovery or deployment assurance is implied. Dependencies are listed in `engine/requirements.txt`; use a trusted host interpreter and never install target dependencies. Historical worker commands remain only for reproduction. Old packages/results are not rewritten or silently relabeled as v2 judgments.

0.6.1 makes the local JSON output encoding explicitly UTF-8 on non-UTF8 hosts and documents report rendering in CLI help. Assessment policy and evidence gates are identical to 0.6.0.

MCP uses `site-impact-exposure-v1`. Archived reports use their recorded policy. Compiled and opaque files are recorded in the inventory.
