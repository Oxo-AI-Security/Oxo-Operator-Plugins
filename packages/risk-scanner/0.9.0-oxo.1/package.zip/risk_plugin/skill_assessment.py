"""Validate a Harness Agent's Skill assessment and apply the scoring engine."""
from .assessment_contract import SkillAssessment
from .workspace import sources_for, references_for
from .io import sha
from .catalog import catalog
from .assessment_policy import summarize, POLICY
from .static_scoring import SCORE_TYPE
from .skill_scoring import POLICY as SKILL_SCORING_POLICY, calculate


def evidence(index, identities):
    if len(identities) != len(set(identities)):
        raise ValueError('Duplicate evidence identities')
    rows = [index.by_id.get(key) for key in identities]
    if any(row is None or not row['text'].strip() for row in rows):
        raise ValueError('Evidence must identify nonblank original source; no substitution was made')
    return [{'path': row['path'], 'line': row['start_line'], 'quote': row['text']} for row in rows]


def source_references(index, decisions):
    edges = {e['reference_id']: e for e in references_for(index)}
    if len(decisions) != len({d.reference_id for d in decisions}) or {d.reference_id for d in decisions} != set(edges):
        raise ValueError('Cross-file reference decisions are missing, duplicated or unknown')
    for decision in decisions:
        edge = edges[decision.reference_id]
        quotes = evidence(index, decision.evidence_ids)
        if decision.status == 'unknown' or decision.confidence < .6:
            raise ValueError('Unresolved cross-file relationship')
        if not any(q['path'] == edge['path'] and q['line'] <= edge['line'] < q['line']+max(1, q['quote'].count('\n')) for q in quotes):
            raise ValueError('Reference decision lacks its original source location')
        if decision.status == 'active' and not any(q['path'] == edge['target_path'] for q in quotes):
            raise ValueError('Active reference needs original evidence from both endpoints')


def validate(item, raw):
    from backend.application import skill_scanner as engine
    from backend.application.skill_profile import _ground, _compile_operations
    from backend.domain.skill.profile_policy import validate_mapping
    from backend.application.skill_authority import _validate_authority_evidence
    record = SkillAssessment.model_validate(raw)
    index, files = sources_for(item)
    if record.source_sha256 != sha(index.texts) or record.policy_sha256 != catalog('skill')['policy_sha256']:
        raise ValueError('Assessment is not bound to this frozen source and policy')
    if record.unresolved:
        raise ValueError('Critical unresolved facts prevent a complete score')
    source_references(index, record.reference_decisions)
    for label, received, expected in [('rules', set(record.decisions), set(engine.RULE_BY_ID)),
                                      ('facts', set(record.behavior_facts), set(engine.BEHAVIOR_FACT_GUIDANCE))]:
        if received != expected:
            raise ValueError(f'Incomplete {label}: missing={sorted(expected-received)}, unknown={sorted(received-expected)}; missing is not excluded')
    operations = []
    for operation in record.operations:
        if operation.confidence < .6:
            raise ValueError('Uncertain operational fact')
        original = operation.model_dump()
        evidence(index, list(dict.fromkeys(original[k] for k in ('entry_evidence_id','action_evidence_id','input_evidence_id') if original.get(k))))
        if original['invocation']:
            evidence(index, list(dict.fromkeys([original['invocation']['evidence_id'], original['invocation']['input_evidence_id']])))
        operations.append(_ground(original, index))
    operations = _compile_operations(operations, index)
    authority = {d.operation_id: d for d in record.authority_reviews}
    selected = {o['operation_id'] for o in operations if o['actor']=='runtime_agent' and o['action'] in {'interface','permissions','production'}}
    if len(authority)!=len(record.authority_reviews) or set(authority)!=selected:
        raise ValueError('Controlled resources need exactly one authentication/authority decision each')
    _validate_authority_evidence(authority, index, ValueError)
    for o in operations:
        if o['operation_id'] in authority:
            d = authority[o['operation_id']]
            if d.confidence < .6:
                raise ValueError('Uncertain authority decision')
            evidence(index, d.evidence_ids)
            if not d.evidence_ids or d.control_boundary == 'unknown':
                raise ValueError('Controlled resource boundary needs explicit original-source review')
            o['authenticated_session_proven'] = d.authentication=='established'
            o['control_boundary'] = d.control_boundary
    profile = {'operations': operations, 'coverage_complete': True}
    active = {o['operation_id']: o for o in operations if o['actor'] == 'runtime_agent'}
    scoring_facts = {}
    for fact in record.scoring_facts:
        key = fact.operation_id
        if key in scoring_facts or key not in active:
            raise ValueError('Scoring facts must identify distinct active operations')
        evidence(index, fact.evidence_ids)
        operation = active[key]
        linked = {operation['action_evidence_id'], operation['input_evidence_id']}
        if fact.review.confidence < .6 or not linked.intersection(fact.evidence_ids):
            raise ValueError('Scoring facts need a reviewed original action or input reference')
        scoring_facts[key] = fact.model_dump(exclude_none=True)
    findings, facts = [], []

    def confirm(identity, decision, fact=False):
        if decision.status=='unknown' or min(decision.confidence, decision.review.confidence)<.6:
            raise ValueError(f'{identity}: uncertain rule decision/review')
        quotes = evidence(index, decision.evidence_ids)
        if decision.integrity_effect is not None:
            variants = SKILL_SCORING_POLICY['rules'].get(identity, {}).get('variants', ())
            if decision.status != 'matched' or not any(
                variant['facts'].get('integrity_effect') == decision.integrity_effect for variant in variants
            ):
                raise ValueError('Integrity effect does not apply to this matched rule')
        if len(decision.operation_ids)!=len(set(decision.operation_ids)) or any(key not in {o['operation_id'] for o in operations} for key in decision.operation_ids):
            raise ValueError('Operation references are duplicated or do not exist')
        if decision.status=='excluded':
            if decision.flow is not None:
                raise ValueError('Excluded decision cannot carry a positive FLOW path')
            return None
        if not quotes:
            raise ValueError(f'{identity}: matched rule/fact needs exact original evidence')
        scope = POLICY['rule_scope_constraints'].get(identity)
        if scope and not any(o['operation_id'] in decision.operation_ids and all(
            o.get(field) in permitted for field, permitted in scope.items()) for o in operations):
            raise ValueError(f'{identity}: reviewed resource does not meet the declared security-boundary predicate')
        error, ceiling = validate_mapping(identity, decision.operation_ids, profile)
        if error:
            raise ValueError(f'{identity}: {error}')
        if identity.startswith('FLOW-'):
            return quotes
        if decision.flow is not None:
            raise ValueError('Only a FLOW rule can carry a FLOW path')
        if fact:
            return {'id':identity, 'dimension':'FACT', 'score':0, 'floor':0, 'evidence':quotes,
                    'llm_confidence':min(decision.confidence, decision.review.confidence, ceiling),
                    'operation_ids':decision.operation_ids, 'source':'host_agent', 'validated':True}
        finding = engine._finding(identity, quotes[0], 'host_agent')
        finding.update(evidence=quotes, operation_ids=decision.operation_ids,
                       llm_confidence=min(decision.confidence, decision.review.confidence, ceiling),
                       llm_rationale=decision.rationale, semantic_adjudication=decision.review.model_dump())
        if decision.integrity_effect:
            finding['integrity_effect'] = decision.integrity_effect
        return finding

    for key, decision in record.behavior_facts.items():
        finding = confirm(key, decision, True)
        if finding:
            facts.append(finding)
    for key, decision in record.decisions.items():
        if not key.startswith('FLOW-'):
            finding = confirm(key, decision)
            if finding:
                findings.append(finding)
    cap = [f for f in findings if f['dimension']=='CAP']
    if not cap or not any(f['dimension']=='EXP' for f in findings):
        raise ValueError('Both CAP and EXP axes require grounded classifications')
    if any(f['id']=='CAP-001' for f in cap) and len(cap)>1:
        raise ValueError('Pure baseline conflicts with a nonzero capability')
    eligible = set(engine._flow_candidate_ids(findings, facts))
    flows = []
    for key, decision in record.decisions.items():
        if not key.startswith('FLOW-'):
            continue
        quotes = confirm(key, decision)
        if decision.status=='excluded':
            continue
        if key not in eligible or decision.flow is None:
            raise ValueError('FLOW lacks validated prerequisites or an actual path')
        participants = []
        for participant in decision.flow.participants:
            quote = evidence(index, [participant.evidence_id])[0]
            if not engine._skill_role_supported(key, participant.role, quote['path'], findings, facts):
                raise ValueError('FLOW participant role is not supported by validated facts')
            participants.append({**quote, 'role': participant.role, 'evidence': quote['quote'],
                                 'evidence_id': participant.evidence_id})
        if {p['role'] for p in participants} != set(engine.FLOW_GUIDANCE[key]['roles']):
            raise ValueError('FLOW required roles incomplete or unrecognized')
        finding = engine._finding(key, quotes[0], 'host_agent_flow')
        finding.update(evidence=quotes, participants=participants, data_path=decision.flow.data_path,
                       llm_confidence=min(decision.confidence, decision.review.confidence),
                       llm_rationale=decision.rationale, semantic_adjudication=decision.review.model_dump())
        flows.append(finding)
    findings, score = calculate(engine._dedupe(findings + flows), operations, scoring_facts.values())
    _, decision, action = engine._level(score['effective_risk'])
    assessment_summary = summarize(findings, score, kind='skill', decision=decision)
    ignored = [f for f in files if not f['is_text']]
    limitations = list(record.limitations)
    if ignored:
        limitations.append(f'{len(ignored)} unsupported binary/opaque files retained in inventory; not semantically assessed or used to assign risk.')
    return {**score, 'score_type':SCORE_TYPE,
        'assessment_summary':assessment_summary,
        'name':item['name'], 'findings':findings, 'behavior_facts':facts,
        'rule_set_version':engine.SKILL_RULE_SET_VERSION, 'prompt_version':'host-agent-review-v1',
        'snapshot_hash':engine.skill_snapshot_hash(item['files']), 'risk_label':assessment_summary['risk_level'],
        'decision':decision, 'default_action':action,
        'classification_status':'classified', 'unknowns':limitations,
        'file_count':len(files), 'analyzable_file_count':len(files)-len(ignored), 'ignored_file_count':len(ignored),
        'files':[{k:f[k] for k in ('path','size','sha256','is_text','analysis_status')} for f in files],
        'flow_classification_status':'completed', 'flow_candidates':sorted(eligible),
        'llm_analysis':{'status':'completed', 'axis_coverage':{'capability':True,'exposure':True},
            'operation_profile':profile, 'scoring_facts':list(scoring_facts.values()), 'analysis_owner':'calling-harness-agent',
            'review_context':'agent_source_review_not_independent_model_sessions', 'stages':[]},
        'flow_llm_analysis':{'status':'completed','candidate_rule_ids':sorted(eligible), 'accepted':len(flows)},
        'source_coverage':{'references_reviewed':len(record.reference_decisions)}}
