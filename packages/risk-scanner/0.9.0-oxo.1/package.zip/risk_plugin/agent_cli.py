"""Local tools for a harness-led review; no background analysis orchestration."""
import argparse
from pathlib import Path
import json
import hashlib
import uuid
import os
import tempfile
from datetime import datetime, timezone

from .io import read, write, offline_guard
from . import workspace
from .assessment_policy import CONTRACT_VERSION


def check(run, identity, assessment_path, *, reason=None):
    item = workspace.unit(run, identity)
    raw_bytes = Path(assessment_path).read_bytes()
    attempt = Path(run) / 'attempts' / identity / (uuid.uuid4().hex + '.json')
    attempt.parent.mkdir(parents=True, exist_ok=True)
    attempt.write_bytes(raw_bytes)
    receipt = {'assessment_sha256': hashlib.sha256(raw_bytes).hexdigest(), 'artifact': str(attempt),
               'analysis_owner': 'calling-harness-agent', 'semantic_independence': False, 'revision_reason':reason}
    try:
        previous = sorted(attempt.parent.glob('*.receipt.json'), key=lambda p:p.stat().st_mtime_ns)
        explained = {read(p)['assessment_sha256'] for p in previous if read(p).get('revision_explained')}
        receipt['revision_explained'] = not previous or receipt['assessment_sha256'] in explained or bool(reason and reason.strip())
        if not receipt['revision_explained']:
            raise ValueError('Changed assessment requires --reason explaining the identified correction; earlier drafts are retained')
        progress = workspace.coverage(run, identity)
        receipt['source_coverage'] = progress
        if not progress['complete']:
            raise ValueError(f"Source coverage incomplete: {progress['delivered_blocks']}/{progress['total_blocks']} original blocks delivered")
        def unique_keys(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('Duplicate assessment JSON key: ' + key)
                result[key] = value
            return result
        raw = json.loads(raw_bytes.decode('utf-8-sig'), object_pairs_hook=unique_keys)
        if item['kind'] == 'skill':
            from .skill_assessment import validate
        else:
            from .mcp_assessment import validate
        scan = validate(item, raw)
        scan['source_coverage'] = {**scan.get('source_coverage', {}), **progress}
        outcome = {'unit':identity, 'name':item['name'], 'status':'succeeded', 'scan':scan}
        receipt.update(status='valid', source_coverage=progress)
    except (ValueError, TypeError, KeyError) as error:
        # Invalid drafts remain reviewable. No default exclusion, source ID,
        # confidence or number is supplied by the helper.
        from pydantic import ValidationError
        issues = error.errors(include_input=False, include_url=False) if isinstance(error, ValidationError) else []
        detail = 'Assessment schema invalid; see field-level issues' if issues else str(error)
        outcome = {'unit':identity, 'name':item['name'], 'status':'failed', 'score':None,
                   'code':'AGENT_REVIEW_INCOMPLETE', 'error':detail,
                   'diagnostics':{'unknowns':[detail]}}
        receipt.update(status='invalid', error=detail, issues=issues)
    write(attempt.with_suffix('.receipt.json'), receipt)
    return outcome, receipt


def finalize(run, identity, assessment_path, *, reason=None):
    run = Path(run)
    target = run / 'assessments' / (identity + '.json')
    workspace.unit(run, identity)  # Validate identity before constructing writes.
    if target.exists():
        raise ValueError('This unit already has a terminal assessment; prior outcomes are immutable')
    outcome, receipt = check(run, identity, assessment_path, reason=reason)
    write(target, {'outcome':outcome, 'receipt':receipt})
    state = workspace.load(run)
    items = []
    for item in state['units']:
        path = run / 'assessments' / (item['id'] + '.json')
        items.append(read(path)['outcome'] if path.exists() else {
            'unit':item['id'],'name':item['name'],'status':'partial','score':None,
            'error':'Agent review not finalized','code':'REVIEW_PENDING'})
    complete = items and all(item['status']=='succeeded' for item in items)
    result = {'schema_version':'risk-report-v1', 'run_id':run.name, 'kind':state['kind'],
        'status':'succeeded' if complete else 'partial' if any(i['status']=='succeeded' for i in items) else 'failed',
        'items':items, 'plugin_network_calls':0,
        'completed_at':datetime.now(timezone.utc).isoformat(),
        'coverage':[{'unit':i['unit'],'status':i['status'],
            'source_delivery':read(run/'assessments'/(i['unit']+'.json'))['receipt'].get('source_coverage')}
            for i in items if (run/'assessments'/(i['unit']+'.json')).exists()],
        'engine':{'analysis_owner':'calling-harness-agent','execution':'local-validation-only',
                  'assessment_contract':CONTRACT_VERSION,'independent_model_contexts':False,
                  'plugin_version':read(Path(__file__).resolve().parents[1]/'plugin.json')['version']}}
    if 'package_inventory' in state:
        result.update(package_inventory=state['package_inventory'],coverage=state['package_inventory'].get('coverage',[]),
                      status='partial', aggregate_score=None)
    write(run / 'result.json', result)
    return {'unit':identity,'status':outcome['status'],'error':outcome.get('error'),
            'result':str(run / 'result.json'),'validation_receipt':receipt}


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__,
        epilog='Fixed report: scan.py render WORKSPACE --output REPORT.html --language zh-CN --presentation auto')
    commands = parser.add_subparsers(dest='command', required=True)
    prep = commands.add_parser('prepare')
    prep.add_argument('kind', choices=['skill','mcp','plugin'])
    prep.add_argument('input'); prep.add_argument('--output',required=True)
    cat = commands.add_parser('catalog'); cat.add_argument('kind',choices=['skill','mcp'])
    cat.add_argument('--prefix')
    for name in ('manifest','coverage','schema'):
        sub = commands.add_parser(name); sub.add_argument('workspace'); sub.add_argument('--unit',required=True)
    source = commands.add_parser('read')
    source.add_argument('workspace'); source.add_argument('--unit',required=True); source.add_argument('--path',required=True)
    source.add_argument('--after'); source.add_argument('--characters',type=int,default=16000)
    for name in ('validate','finalize'):
        sub=commands.add_parser(name);sub.add_argument('workspace');sub.add_argument('--unit',required=True);sub.add_argument('--assessment',required=True)
        sub.add_argument('--reason',help='Explain a correction when the submitted assessment differs from the previous draft')
    args=parser.parse_args(argv)
    state_root = getattr(args, 'workspace', None) or getattr(args, 'output', None)
    os.environ['MCP_RISK_DATA_DIR'] = str(Path(state_root) / 'validator-state' if state_root else Path(tempfile.gettempdir()) / 'risk-scanner-metadata')
    offline_guard()
    if args.command=='prepare':
        value=workspace.prepare(args.kind,args.input,args.output)
    elif args.command=='catalog':
        from .catalog import catalog
        value=catalog(args.kind)
        if args.prefix:
            value={**value,'rules':[r for r in value['rules'] if r['id'].startswith(args.prefix)]}
    elif args.command=='manifest':
        value=workspace.unit_manifest(args.workspace,args.unit)
    elif args.command=='coverage':
        value=workspace.coverage(args.workspace,args.unit)
    elif args.command=='read':
        value=workspace.read_source(args.workspace,args.unit,args.path,after=args.after,characters=args.characters)
    elif args.command=='schema':
        from .assessment_contract import schema
        value=schema(workspace.unit(args.workspace,args.unit)['kind'])
    elif args.command=='validate':
        outcome, receipt=check(args.workspace,args.unit,args.assessment,reason=args.reason)
        value={'valid':outcome['status']=='succeeded','error':outcome.get('error'),'receipt':receipt}
    else:
        value=finalize(args.workspace,args.unit,args.assessment,reason=args.reason)
    print(json.dumps(value,ensure_ascii=False,indent=2))
