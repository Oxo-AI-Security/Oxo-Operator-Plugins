"""Immutable inputs, bounded original-source access and auditable read coverage.

No worker, timer, model calls or agent loop. The calling harness owns analysis.
"""
from pathlib import Path
import hashlib
import json
import uuid
from datetime import datetime, timezone

from .io import read, write, sha
from .catalog import catalog
from .assessment_policy import CONTRACT_VERSION


def prepare(kind, input_path, output):
    source = Path(input_path).resolve(strict=True)
    if not source.is_file() or source.stat().st_size > 8_000_000:
        raise ValueError('Input must be a regular archive/JSON file of at most 8 MB')
    data = source.read_bytes()
    run = Path(output).resolve() / ('review-' + uuid.uuid4().hex[:12])
    run.mkdir(parents=True)
    frozen = run / 'input.bin'
    frozen.write_bytes(data)
    state = {'contract_version': CONTRACT_VERSION, 'kind': kind, 'source_path': str(source),
             'created_at':datetime.now(timezone.utc).isoformat(),
             'input_sha256': hashlib.sha256(data).hexdigest(), 'units': [],
             'analysis_owner': 'calling-harness-agent', 'plugin_network_calls': 0}
    from backend.api.external_payloads import parse_skill_archive, parse_mcp_tools_payload
    if kind == 'mcp':
        tools = parse_mcp_tools_payload(data.decode('utf-8-sig'))
        if len({t['name'] for t in tools}) != len(tools):
            raise ValueError('Duplicate Tool names are ambiguous')
        state['units'] = [{'id': 'U0', 'name': source.stem, 'kind': 'mcp', 'tools': tools,
                           'source_text': data.decode('utf-8-sig')}]
    else:
        if kind == 'plugin':
            from .packages import inventory
            package = inventory(data)
            packages = package.pop('packages')
            state['package_inventory'] = package
        elif kind == 'skill':
            packages = parse_skill_archive(data, source.name)
        else:
            raise ValueError('Unknown input kind')
        state['units'] = [{'id': f'U{i}', 'name': p['name'], 'kind': 'skill', 'files': p['files']}
                          for i, p in enumerate(packages)]
    state['policies'] = {k: catalog(k)['policy_sha256'] for k in {u['kind'] for u in state['units']}}
    write(run / 'input.json', state)
    # A second digest catches accidental edits to workspace metadata as well.
    write(run / 'freeze.json', {'state_sha256': sha(state), 'input_sha256': state['input_sha256']})
    if kind=='plugin' and not state['units']:
        write(run/'result.json', {'schema_version':'risk-report-v1','run_id':run.name,'kind':kind,
            'status':'partial','items':[],'aggregate_score':None,'plugin_network_calls':0,
            'package_inventory':state['package_inventory'], 'coverage':state['package_inventory'].get('coverage',[])})
    return {'workspace': str(run), 'units': [unit_manifest(run, u['id']) for u in state['units']],
            'kind': kind, 'analysis_owner': state['analysis_owner'], 'pending_model_requests': 0}


def load(run):
    run = Path(run).resolve(strict=True)
    state = read(run / 'input.json')
    freeze = read(run / 'freeze.json')
    if sha(state) != freeze['state_sha256'] or hashlib.sha256((run / 'input.bin').read_bytes()).hexdigest() != freeze['input_sha256']:
        raise ValueError('Frozen input or manifest changed')
    if any(catalog(k)['policy_sha256'] != v for k, v in state['policies'].items()):
        raise ValueError('Policy version/hash changed within this review')
    return state


def unit(run, identity):
    return next(u for u in load(run)['units'] if u['id'] == identity)


def sources_for(item):
    from backend.application.skill_evidence import SourceIndex
    if item['kind'] == 'mcp':
        return SourceIndex([{'path': 'tools-list.json', 'text': item['source_text']}]), []
    from backend.application.skill_scanner import _snapshot
    _, files, _ = _snapshot(item['files'])
    return SourceIndex(files), files


def references_for(index):
    from backend.application.package_references import references
    return [dict(reference_id=f'R{i}', **edge) for i, edge in enumerate(
        e for p, t in sorted(index.texts.items()) for e in references(p, t, set(index.texts)))]


def unit_manifest(run, identity):
    item = unit(run, identity)
    index, files = sources_for(item)
    return {'unit': identity, 'name': item['name'], 'kind': item['kind'],
            'source_sha256': sha(index.texts), 'policy_sha256': catalog(item['kind'])['policy_sha256'],
            'files': [{'path': path, 'characters': len(text), 'text_sha256': hashlib.sha256(text.encode()).hexdigest(),
                       'blocks': len([b for b in index.catalog if b['path'] == path])} for path, text in index.texts.items()],
            'ignored_files': [{k: f[k] for k in ('path', 'size', 'sha256')} for f in files if not f['is_text']],
            'references': references_for(index),
            'tools': [t['name'] for t in item.get('tools', [])]}


def read_source(run, identity, path, *, after=None, characters=16000):
    if not 1000 <= characters <= 40000:
        raise ValueError('Source read budget must be between 1,000 and 40,000 characters')
    item = unit(run, identity)
    index, _ = sources_for(item)
    blocks = [b for b in index.catalog if b['path'] == path]
    if not blocks:
        raise ValueError('Original analyzable source path not found')
    if after is not None:
        offset = next((i+1 for i, b in enumerate(blocks) if b['evidence_id'] == after), None)
        if offset is None:
            raise ValueError('Cursor does not belong to this file')
        blocks = blocks[offset:]
    selected, size = [], 0
    for block in blocks:
        cost = len(json.dumps(block, ensure_ascii=False))
        if selected and size + cost > characters:
            break
        selected.append(block)
        size += cost
    receipt = {'unit': identity, 'source_sha256': sha(index.texts),
               'blocks': selected, 'next_after': selected[-1]['evidence_id'] if selected and len(selected) < len(blocks) else None,
               'blank_evidence_ids': [b['evidence_id'] for b in selected if not b['text'].strip()]}
    folder = Path(run) / 'reads' / identity
    write(folder / (uuid.uuid4().hex + '.json'), receipt)
    return receipt


def coverage(run, identity):
    item = unit(run, identity)
    index, _ = sources_for(item)
    expected = set(index.by_id)
    seen = set()
    for path in (Path(run) / 'reads' / identity).glob('*.json'):
        record = read(path)
        if record['unit'] != identity or record['source_sha256'] != sha(index.texts):
            raise ValueError('Read receipt does not belong to this frozen source')
        for block in record['blocks']:
            if index.by_id.get(block['evidence_id']) != block:
                raise ValueError('Read receipt source was changed')
            seen.add(block['evidence_id'])
    return {'complete': seen == expected, 'delivered_blocks': len(seen), 'total_blocks': len(expected),
            'remaining': [{'path': b['path'], 'evidence_id': b['evidence_id']} for b in index.catalog if b['evidence_id'] not in seen]}
