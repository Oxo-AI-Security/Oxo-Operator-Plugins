"""Describe validated findings alongside the engine's risk and disposition."""
from .static_scoring import SCORING_POLICY, calculation
from .skill_scoring import POLICY as SKILL_SCORING_POLICY, confirmed_malicious

CONTRACT_VERSION = 'agent-review-v2'
POLICY = {
    'version': 'assessment-context-v3',
    'scoring': SCORING_POLICY,
    'capability_and_exposure': 'Describe declared effects and reach; do not establish malicious intent or a vulnerability.',
    'skill_control_gaps': [],
    'mcp_control_gaps': ['META-005'],
    'control_gap_meaning': 'Mutable dependency/code consumption is a supply-chain control concern; mutability alone is not proof of compromise.',
    'security_paths': 'Confirmed FLOW paths contribute the rule floor; coexistence is insufficient.',
    'security_boundaries': ['identity', 'resource_access', 'platform_security'],
    'control_boundary_definitions': {
        'identity': 'Accounts, roles, authentication identities or credentials.',
        'resource_access': 'Enforced authorization, ACLs or access scopes for principals and protected resources.',
        'platform_security': 'Host/service security controls such as audit, sandbox, firewall or execution policy.',
        'artifact_editing': 'Content formatting, form modes and editor restriction flags without an authorization boundary.',
        'none': 'No identity, resource authorization, security platform or artifact edit-control effect.',
        'unknown': 'Insufficient original-source evidence; cannot complete the controlled-resource review.',
    },
    'rule_scope_constraints': {
        'CAP-013': {'action': ['permissions'], 'control_boundary': ['identity', 'resource_access', 'platform_security']},
    },
}


def summarize(findings, score, *, kind, decision):
    """Group accepted facts and expose the engine's scoring and disposition."""
    groups = {key: [] for key in ('capabilities', 'exposure', 'integrity', 'security_paths', 'control_gaps', 'metadata')}
    scoring = calculation(score, kind=kind)
    new_skill_policy = scoring['policy_version'] == SKILL_SCORING_POLICY['version']
    control_gaps = ['FLOW-004'] if new_skill_policy else POLICY[kind + '_control_gaps']
    for finding in findings:
        identity = finding.get('id') or finding.get('rule_id')
        family = identity.split('-')[0]
        if identity in control_gaps:
            group = 'control_gaps'
        elif family == 'CAP':
            group = 'capabilities'
        elif family == 'EXP':
            group = 'exposure'
        elif family in {'SEM', 'MAL'} or kind == 'mcp' and identity in {'META-001', 'META-002', 'META-003', 'META-004'}:
            group = 'integrity'
        elif family == 'FLOW':
            group = 'security_paths'
        else:
            group = 'metadata'
        groups[group].append(finding)

    concerns = groups['integrity'] + groups['security_paths']
    severity = None
    if concerns:
        if kind == 'mcp':
            from backend.domain.mcp.rules import RULE_BY_ID
            concern_rules = [RULE_BY_ID[hit.get('id') or hit['rule_id']] for hit in concerns]
            severity = max(rule.get('floor', rule.get('score', 0)) for rule in concern_rules)
        else:
            severity = max(hit['floor'] for hit in concerns)
        status = 'security_concern'
    elif groups['control_gaps'] or groups['metadata']:
        status = 'control_review'
    else:
        status = 'capabilities_reviewed'

    return {
        'policy_version': 'assessment-context-v4' if new_skill_policy else POLICY['version'],
        'status': status,
        'overall_risk_score': scoring['score'], 'risk_level':scoring['level'],
        'score_reason': SCORING_POLICY['meaning'], 'scoring':scoring,
        'decision': decision, 'decision_rule_ids': sorted({f.get('id') or f['rule_id'] for f in findings}),
        'confirmed_concern_severity': severity,
        'impact': score['impact'], 'exposure': score['exposure'],
        'groups': {key: sorted({f.get('id') or f['rule_id'] for f in rows}) for key, rows in groups.items()},
        'malicious_intent': 'not_determined',
        **({'confirmed_malicious_implementation': sorted({hit['id'] for hit in findings if confirmed_malicious(hit)})}
           if new_skill_policy else {}),
    }
