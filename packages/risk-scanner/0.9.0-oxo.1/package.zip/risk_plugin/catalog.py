"""One policy source for agent references, validation and deterministic scoring."""
from .io import sha
from .assessment_policy import POLICY
from .static_scoring import SCORE_TYPE, SKILL_FORMULA
from .skill_scoring import POLICY as SKILL_SCORING_POLICY


def catalog(kind):
    if kind == 'skill':
        from backend.application.skill_scanner import public_skill_rules, BEHAVIOR_FACT_GUIDANCE
        from backend.domain.skill.profile_policy import PREREQUISITES, OPERATION_SEMANTICS
        value = public_skill_rules()
        result = {'kind': kind, 'version': value['rule_set_version'], 'rules': value['rules'],
                  'behavior_facts': BEHAVIOR_FACT_GUIDANCE, 'formula': value['effective_formula'],
                  'operational_prerequisites':PREREQUISITES, 'operation_semantics':OPERATION_SEMANTICS}
    elif kind == 'mcp':
        from backend.domain.mcp.rules import public_rules, RULE_SET_VERSION, llm_rule_catalog, llm_flow_catalog
        result = {'kind': kind, 'version': RULE_SET_VERSION, 'rules': public_rules(),
                  'semantic_catalog': llm_rule_catalog(), 'flow_catalog': llm_flow_catalog()}
    else:
        raise ValueError('Catalog kind must be skill or mcp')
    result['formula'] = POLICY['scoring']['formulas'][kind]
    result['score_type'] = SCORE_TYPE
    result['assessment_policy'] = POLICY
    if kind == 'skill':
        result['formula'] = SKILL_FORMULA
        result['assessment_policy'] = {**POLICY, 'version': 'assessment-context-v4',
                                       'skill_control_gaps': ['FLOW-004'],
                                       'scoring': {**SKILL_SCORING_POLICY, 'formula': SKILL_FORMULA, 'bands': POLICY['scoring']['bands']}}
        for rule in result['rules']:
            pricing = SKILL_SCORING_POLICY['rules'].get(rule['id'])
            if pricing:
                rule.update(pricing['default'])
                if 'floor' in pricing['default']:
                    rule['score'] = pricing['default']['floor']
                if 'exposure' in pricing['default']:
                    rule['score'] = 20 * pricing['default']['exposure']
                rule['scoring_tiers'] = pricing
    return {**result, 'policy_sha256': sha(result)}
