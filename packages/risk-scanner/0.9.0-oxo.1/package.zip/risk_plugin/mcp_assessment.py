"""Agent-authored MCP declaration reviews; original scorer owns all numbers."""
import json
from pydantic import Field
from typing import Literal
from .assessment_contract import Record, Review
from .catalog import catalog
from .workspace import sources_for
from .io import sha
from .assessment_policy import summarize
from .static_scoring import SCORE_TYPE


class Quote(Record):
    field: Literal['name','description','inputSchema','outputSchema','annotations']
    text: str = Field(min_length=1)


class ToolDecision(Record):
    status: Literal['matched','excluded','unknown']
    confidence: float = Field(ge=0, le=1)
    rationale: str = Field(min_length=1)
    exclusion_analysis: str = Field(min_length=1)
    evidence: list[Quote]
    review: Review
    issue_type: str | None = None


class UntrustedContent(Record):
    detected: bool
    confidence: float = Field(ge=0, le=1)
    evidence: list[Quote]


class ToolReview(Record):
    tool_name: str
    decisions: dict[str, ToolDecision]
    untrusted_content: UntrustedContent
    data_classes: list[Literal['public','internal','pii','regulated','financial','health','credential','secret','unknown']] = Field(min_length=1)


class McpParticipant(Record):
    tool_name: str
    role: str
    evidence: list[Quote] = Field(min_length=1)


class McpFlow(Record):
    data_path: str = Field(min_length=1)
    participants: list[McpParticipant] = Field(min_length=1)


class McpFlowDecision(Record):
    status: Literal['matched','excluded','unknown']
    confidence: float = Field(ge=0, le=1)
    rationale: str = Field(min_length=1)
    exclusion_analysis: str = Field(min_length=1)
    review: Review
    flow: McpFlow | None = None


class McpAssessment(Record):
    contract_version: Literal['agent-review-v2']
    source_sha256: str
    policy_sha256: str
    tools: list[ToolReview]
    flows: dict[str, McpFlowDecision]
    unresolved: list[str]
    limitations: list[str]


def validate(item, raw):
    from backend.domain.mcp import rules
    from backend.domain.mcp.scoring import score_server
    record = McpAssessment.model_validate(raw)
    index, _ = sources_for(item)
    if record.source_sha256 != sha(index.texts) or record.policy_sha256 != catalog('mcp')['policy_sha256']:
        raise ValueError('MCP assessment source/policy identity mismatch')
    if record.unresolved:
        raise ValueError('Unresolved MCP declaration facts')
    metadata = {t['name']:t for t in item['tools']}
    if not metadata:
        raise ValueError('MCP snapshot has no Tool declarations to review')
    if len(record.tools) != len(metadata) or {t.tool_name for t in record.tools} != set(metadata):
        raise ValueError('MCP Tool coverage incomplete or duplicated')
    tool_ids = {r['id'] for r in rules.public_rules() if r['kind']!='flow'}
    flow_ids = {r['id'] for r in rules.FLOW_RULES}
    if set(record.flows) != flow_ids:
        raise ValueError('All MCP FLOW rules require explicit decisions')

    def exact(tool, quotes):
        for quote in quotes:
            field = tool.get(quote.field, '')
            original = field if isinstance(field, str) else json.dumps(field,ensure_ascii=False)
            if quote.text not in original:
                raise ValueError('MCP evidence is not an exact original metadata quotation')
        return [q.model_dump() for q in quotes]

    extractions = {}
    for reviewed in record.tools:
        if set(reviewed.decisions) != tool_ids:
            raise ValueError('All MCP Tool rules require explicit decisions')
        tool = metadata[reviewed.tool_name]
        groups = {'CAP':[], 'EXP':[], 'META':[]}
        for key, d in sorted(reviewed.decisions.items()):
            if d.status=='unknown' or min(d.confidence,d.review.confidence)<.6:
                raise ValueError(f'{key}: uncertain MCP decision')
            quotes = exact(tool,d.evidence)
            if d.status=='matched':
                if not quotes:
                    raise ValueError('Matched MCP decision needs exact evidence')
                hit={'rule_id':key,'confidence':min(d.confidence,d.review.confidence),
                     'rationale':d.rationale,'evidence':quotes}
                if key.startswith('META-'):
                    if key in rules.SEMANTIC_META_RULE_IDS and d.issue_type not in rules.SECURITY_ISSUE_TYPES:
                        raise ValueError('Positive semantic META decision needs a permitted issue_type from catalog mcp')
                    hit['issue_type']=d.issue_type
                groups[key.split('-')[0]].append(hit)
        untrusted=reviewed.untrusted_content
        exact(tool,untrusted.evidence)
        if untrusted.confidence<.6 or untrusted.detected and not untrusted.evidence:
            raise ValueError('Untrusted-content classification needs certainty and positive source evidence')
        security=[h for h in groups['META'] if h['rule_id'] in rules.SEMANTIC_META_RULE_IDS]
        extractions[reviewed.tool_name]={
            'prompt_version':rules.LLM_PROMPT_VERSION,'rule_set_version':rules.RULE_SET_VERSION,
            'capability_rule_matches':groups['CAP'],
            'exposure_rule_matches':[h for h in groups['EXP'] if h['rule_id'] in rules.SEMANTIC_EXPOSURE_RULE_IDS],
            'security_rule_matches':security,'has_security_issue':bool(security),
            'security_issue_types':sorted({h['issue_type'] for h in security if h['issue_type']}),
            'untrusted_content':untrusted.model_dump(),'data_classes':reviewed.data_classes,
            'rejected_candidates':[],'unknowns':record.limitations}
    flows=[]
    rejected=[]
    for key,d in sorted(record.flows.items()):
        if d.status=='unknown' or min(d.confidence,d.review.confidence)<.6:
            raise ValueError('Uncertain MCP FLOW decision')
        if d.status=='excluded':
            if d.flow is not None:
                raise ValueError('Excluded FLOW cannot carry a positive path')
            rejected.append({'rule_id':key,'rationale':d.exclusion_analysis})
            continue
        if d.flow is None:
            raise ValueError('MCP FLOW requires actual participants and data path')
        participants=[]
        for p in d.flow.participants:
            if p.tool_name not in metadata:
                raise ValueError('FLOW participant Tool does not exist')
            participants.append({'tool_name':p.tool_name,'role':p.role,'evidence':exact(metadata[p.tool_name],p.evidence)})
        flows.append({'rule_id':key,'confidence':min(d.confidence,d.review.confidence),
                      'rationale':d.rationale,'data_path':d.flow.data_path,'participants':participants})
    result=score_server({'id':'snapshot','name':item['name'],'tools':item['tools']},extractions,
        flow_extraction={'prompt_version':rules.FLOW_PROMPT_VERSION,'rule_set_version':rules.RULE_SET_VERSION,
                         'flow_rule_matches':flows,'rejected_candidates':rejected,'unknowns':record.limitations})
    if result.get('flow_candidates') and result['flow_classification_status'] != 'classified':
        raise ValueError('Original MCP FLOW gates did not complete')
    if result.get('flow_validation_rejections'):
        raise ValueError('Original MCP scorer rejected a proposed FLOW')
    if {f['id'] for f in result['toxic_combinations']} != {key for key,d in record.flows.items() if d.status=='matched'}:
        raise ValueError('Agent FLOW declarations do not match source-validated paths')
    for scored in result['tools']:
        actual={h['id'] for h in scored['matched_rules']}
        declared={key for key,d in next(r for r in record.tools if r.tool_name==scored['name']).decisions.items() if d.status=='matched'}
        if actual != declared:
            raise ValueError('Agent MCP decisions conflict with deterministic or source-validated rule results')
        if scored['classification_status'] != 'classified' and 'META-007' not in actual:
            raise ValueError('MCP Tool classification has no verified fallback')
    result['analysis_owner']='calling-harness-agent'
    result['review_context']='agent_source_review_not_independent_model_sessions'
    result['status']='external_snapshot'
    result['acquisition']={'method':'caller-supplied-tools-list','connection_performed':False}
    findings = list(result.get('matched_rules', [])) + list(result.get('toxic_combinations', []))
    for tool in result['tools']:
        findings.extend(tool['matched_rules'])
    def contextualize(value, accepted, tools, confirmed_flows):
        # Different tools can supply the server's maximum base and floors.
        score = {
            'impact': value['impact'],
            'exposure': value['exposure'],
            'base_risk': max((tool['base_score'] for tool in tools), default=0),
            'capability_floor': max((tool['capability_floor'] for tool in tools), default=0),
            'metadata_floor': value['metadata_floor'],
            'flow_floor': max((hit['score'] for hit in confirmed_flows), default=0),
            'effective_risk': value['effective_risk_score'],
        }
        summary = summarize(accepted, score, kind='mcp', decision=value['decision'])
        value.update(assessment_summary=summary, risk_level=summary['risk_level'], score_type=SCORE_TYPE)

    contextualize(result, findings, result['tools'], result['toxic_combinations'])
    for tool in result['tools']:
        contextualize(tool, tool['matched_rules'], [tool], [])
    return result
