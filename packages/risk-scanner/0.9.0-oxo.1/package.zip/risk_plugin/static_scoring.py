"""Project the scoring engines' effective risk and preserve archived grades."""
from .skill_scoring import POLICY as SKILL_SCORING_POLICY

ARCHIVED_POLICY = 'static-rule-risk-v1'
SCORE_TYPE = 'site_aligned_risk'
SCORING_POLICY = {
    'version': 'site-impact-exposure-v1',
    'base_formula': 'min(100, 13 × Impact + 7 × Exposure)',
    'formulas': {
        'skill': 'max(base, capability floor, integrity floor, confirmed FLOW floor)',
        'mcp': 'max(base, capability floor, metadata floor, confirmed FLOW score)',
    },
    'mcp_aggregation': 'At server scope, take the maximum base, capability and metadata contributions across tools before applying confirmed FLOW.',
    'bands': [
        {'minimum': 0, 'level': 'informational', 'mcp_decision': 'allow', 'skill_decision': 'Allow'},
        {'minimum': 20, 'level': 'low', 'mcp_decision': 'log', 'skill_decision': 'Log'},
        {'minimum': 40, 'level': 'medium', 'mcp_decision': 'confirm', 'skill_decision': 'Review'},
        {'minimum': 60, 'level': 'high', 'mcp_decision': 'restrict', 'skill_decision': 'Restrict'},
        {'minimum': 80, 'level': 'critical', 'mcp_decision': 'block', 'skill_decision': 'Quarantine'},
        {'minimum': 95, 'level': 'critical', 'mcp_decision': 'block', 'skill_decision': 'Block'},
    ],
    'meaning': 'Effective risk from the reviewed declarations, evidence and confirmed paths. Disposition is a policy recommendation.',
}

SKILL_POLICY_VERSION = SKILL_SCORING_POLICY['version']
SKILL_FORMULA = 'max(highest same-operation base, CAP floor, SEM/MAL floor, confirmed FLOW floor)'


def risk_level(score, *, policy_version=SCORING_POLICY['version']):
    if not isinstance(score, int) or isinstance(score, bool) or not 0 <= score <= 100:
        raise ValueError('Risk score must be an integer in 0..100')
    if policy_version == ARCHIVED_POLICY and score < 40:
        return 'low'
    if policy_version not in {ARCHIVED_POLICY, SCORING_POLICY['version'], SKILL_POLICY_VERSION}:
        raise ValueError('Unknown risk scoring policy')
    return next(band['level'] for band in reversed(SCORING_POLICY['bands']) if score >= band['minimum'])


def calculation(score, *, kind):
    """Trace the actual engine result without replaying rule matching."""
    integrity_key = 'metadata_floor' if kind == 'mcp' else 'integrity_floor'
    components = {
        'base': score['base_risk'],
        'capability_floor': score['capability_floor'],
        integrity_key: score[integrity_key],
        'flow_floor': score['flow_floor'],
    }
    effective = score['effective_risk']
    if effective != max(components.values()):
        raise ValueError('Engine score and site-aligned scoring trace disagree')
    is_skill_policy = kind == 'skill' and 'operation_base' in score
    policy_version = SKILL_POLICY_VERSION if is_skill_policy else SCORING_POLICY['version']
    result = {
        'policy_version': policy_version, 'score': effective,
        'level': risk_level(effective), 'formula': SKILL_FORMULA if is_skill_policy else SCORING_POLICY['formulas'][kind],
        'components': {key: {'score': value} for key, value in components.items()},
        'drivers': [key for key, value in components.items() if value == effective],
        'runtime_risk': 'not_assessed',
    }
    if is_skill_policy:
        result['components']['base'].update(score['operation_base'])
    return result
